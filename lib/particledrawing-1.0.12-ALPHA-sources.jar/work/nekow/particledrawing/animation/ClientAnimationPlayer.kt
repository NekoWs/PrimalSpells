package work.nekow.particledrawing.animation

import net.minecraft.world.phys.Vec3
import work.nekow.particledrawing.animation.script.AudioValue
import work.nekow.particledrawing.animation.script.ParticleHost
import work.nekow.particledrawing.animation.script.ScriptException
import work.nekow.particledrawing.animation.script.ScriptProgram
import work.nekow.particledrawing.animation.script.ScriptRuntime
import work.nekow.particledrawing.animation.script.TextValue
import work.nekow.particledrawing.animation.script.ViewTransform
import work.nekow.particledrawing.animation.script.parseProgram
import work.nekow.particledrawing.api.Color
import work.nekow.particledrawing.util.rotateAround
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.roundToInt

@Suppress("unused")
class ClientAnimationPlayer(
    private val animation: ParticleAnimation,
    private val origin: Vec3,
    // 服务端权威进度起点（维度 gameTime）；进度 = wrap/clamp(currentGameTick - startGameTick)
    private val startGameTick: Long = 0L,
    currentGameTick: Long = 0L,
    // 显式起始毫秒（特效 API 使用；<0 时按 gameTime 时钟定位）
    initialMs: Int = -1,
) {

    data class ParticleState(
        val id: String,
        var pos: Vec3,
        var color: Color,
        var scale: FloatArray,
        var glowing: Boolean,
        var lightLevel: Int,
        var uv: UvData?,
        /** t ≥ st 才为 true；隐藏门控在同步层生效（未出场粒子不生成/已回收）。 */
        var visible: Boolean = true,
        /** 是否为函数对象派生粒子（id = fxId:p<serial>）。 */
        val derived: Boolean = false,
        /** v17：广告牌模式（false=固定朝向，按 spin 旋转）。 */
        var billboard: Boolean = true,
        /** v17：自转（XYZ 度）；billboard=true 时渲染端忽略。 */
        var spin: DoubleArray = DoubleArray(3),
        /** v17：自转空间（true=local）。 */
        var spinLocal: Boolean = true,
        /** true=加法混合（来自所属函数对象的 flags bit7）；渲染端据此换 ADDITIVE_PARTICLE 管线。 */
        var additive: Boolean = false,
    ) {
        override fun equals(other: Any?): Boolean {
            if (this === other) return true
            if (javaClass != other?.javaClass) return false

            other as ParticleState

            if (glowing != other.glowing) return false
            if (lightLevel != other.lightLevel) return false
            if (visible != other.visible) return false
            if (derived != other.derived) return false
            if (id != other.id) return false
            if (pos != other.pos) return false
            if (color != other.color) return false
            if (!scale.contentEquals(other.scale)) return false
            if (uv != other.uv) return false
            if (billboard != other.billboard) return false
            if (!spin.contentEquals(other.spin)) return false
            if (spinLocal != other.spinLocal) return false
            if (additive != other.additive) return false

            return true
        }

        override fun hashCode(): Int {
            var result = glowing.hashCode()
            result = 31 * result + lightLevel
            result = 31 * result + visible.hashCode()
            result = 31 * result + derived.hashCode()
            result = 31 * result + id.hashCode()
            result = 31 * result + pos.hashCode()
            result = 31 * result + color.hashCode()
            result = 31 * result + scale.contentHashCode()
            result = 31 * result + uv.hashCode()
            result = 31 * result + billboard.hashCode()
            result = 31 * result + spin.contentHashCode()
            result = 31 * result + spinLocal.hashCode()
            result = 31 * result + additive.hashCode()
            return result
        }
    }

    /** 摄像机某时刻姿态；播放端不自动改玩家相机。pos/target 为世界坐标，roll 绕视线翻滚角（度），fov 视场角（度）。 */
    data class CameraPose(
        val pos: DoubleArray,
        val target: DoubleArray,
        val roll: Double,
        val fov: Double,
    ) {
        override fun equals(other: Any?): Boolean {
            if (this === other) return true
            if (javaClass != other?.javaClass) return false

            other as CameraPose

            if (roll != other.roll) return false
            if (fov != other.fov) return false
            if (!pos.contentEquals(other.pos)) return false
            if (!target.contentEquals(other.target)) return false

            return true
        }

        override fun hashCode(): Int {
            var result = roll.hashCode()
            result = 31 * result + fov.hashCode()
            result = 31 * result + pos.contentHashCode()
            result = 31 * result + target.contentHashCode()
            return result
        }
    }

    private var currentMs = 0
    private val states = LinkedHashMap<String, ParticleState>()
    private var finished = false
    private var justLooped = false
    private var prevAdvanceT = 0.0
    private var advanceInitialized = false

    // —— 调试统计 ——
    var lastAdvanceNanos: Long = 0; private set
    var frameCount: Long = 0; private set
    private var advanceNanosTotal = 0L
    private var advanceCount = 0L

    val avgAdvanceNanos: Long get() = if (advanceCount == 0L) 0L else advanceNanosTotal / advanceCount
    val particleCount: Int get() = states.size
    val currentMsValue: Int get() = currentMs
    val maxMsValue: Int get() = maxMs

    private val maxMs: Int = animation.timelineLength()

    /**
     * 按已过的 game tick 算播放头毫秒。
     * 时间轴非空（maxMs > 0）走 [AnimationProgress.msAt] 的 wrap/clamp；时间轴为空（maxMs <= 0）时
     * 播放头照样随时间前进，不能钉在 0：编辑器里函数对象 duration = 0 表示「不限时长」
     * （animation-eval.js 的 fxParticleVisible：`duration <= 0` 视为无时长上限），播放头一直往前跑。
     * 钉在 0 会让每帧传给脚本的时刻往回跳，函数对象运行时被反复重建（`t < rt.curMs` → resetFxRuntime），
     * 脚本攒的状态（环形缓冲、包络、累计量）每刻清零。
     */
    private fun progressMsAt(elapsedTicks: Long): Int {
        if (maxMs > 0) return AnimationProgress.msAt(elapsedTicks, maxMs, animation.loop)
        val ms = elapsedTicks.coerceAtLeast(0L) * 50L
        return ms.coerceAtMost(Int.MAX_VALUE.toLong()).toInt()
    }

    // 静态动画（无轨道/时间轴，且公式与变量均不含 random()、脚本也没有随时间跑的阶段）：
    // init 已算好 t=0 状态，每 tick 无需重算。5w 粒子的静态粒子云若每刻重算会白费约 70ms/tick。
    // 存在 st 门控或入场预设时必然随时间变化，强制按动态处理。
    // 带 tick/process 的脚本同样必然随时间变化（读 this.time / this.delta / 音频 / 被动输入）：
    // 编辑器里这两段跟着播放头每帧求值（generators.js evaluateFxFrame），所以播放端不能因为
    // duration == 0、时间轴为空就把整支 fx 跳过——那样画面会静悄悄地少一整块。
    // 延迟求值：判据要用 fxRuntimes 里解析好的脚本阶段，它在本字段之后才初始化。
    private val isStaticAnimation: Boolean by lazy {
        if (maxMs > 0) return@lazy false
        if (animation.particles.any { it.st > 0 || it.ent != null }) return@lazy false
        if (animation.functions.any { it.st > 0 || it.ent != null }) return@lazy false
        if (animation.functions.any { hasTimePhase(it) }) return@lazy false
        animation.functions.none { fx -> usesRandom(fx) }
    }

    /** 该函数对象的脚本有没有随时间跑的阶段（tick / process）。解析失败（runtime 为空）按没有算：
     *  那个对象本来就跑不起来，构造时已经报过编译错误。 */
    private fun hasTimePhase(fx: FunctionObject): Boolean {
        val program = fxRuntimes[fx.id]?.program ?: return false
        return program.process.isNotEmpty() || program.tick.isNotEmpty()
    }

    // —— 预构建求值索引（避免每 tick 线性扫描轨道 / 组 / 粒子） ——
    private val trackIndex: Map<TrackPr, Map<String, AnimTrack>> = buildTrackIndex()
    private val opTracks: List<AnimTrack> = animation.tracks.filter { it.mode == AnimTrack.Mode.OP }
    private val opTracksByPr: Map<TrackPr, List<AnimTrack>> = opTracks.filter { it.keyframes.isNotEmpty() }.groupBy { it.pr }
    private val groupSets: Map<String, Set<String>> = buildOwnerSets()
    private val groupSpinLocal: Set<String> = animation.groupSpinSpace.filterValues { it }.keys
    private val groupRotLocal: Set<String> = animation.groupRotSpace.filterValues { it }.keys
    private val particleGroupIndex: Map<String, Set<String>> = buildParticleGroupIndex()
    private val groupCentroidCache: Map<String, Vec3> = buildGroupCentroids()

    /** owner 键（'g:名' | 't:id'）→ 成员集合。 */
    private fun buildOwnerSets(): Map<String, Set<String>> {
        val map = HashMap<String, Set<String>>()
        for ((name, members) in animation.groups) map["g:$name"] = members.toSet()
        for (tx in animation.texts) map["t:${tx.id}"] = tx.memberIds().toSet()
        return map
    }
    private val camUp = Vec3(0.0, 1.0, 0.0)

    // —— UV 字段表达式 ——
    // 普通粒子全局序号：index=全局序号、count=粒子总数（普通 + 派生，与编辑器 state.particles.length 一致）；
    // 派生粒子 index=spawn 序号、uv=(0,0)。
    private val particleGlobalIndex: Map<String, Int> = animation.particles.mapIndexed { i, p -> p.id to i }.toMap()
    private val animationParticleById: Map<String, AnimParticle> = animation.particles.associateBy { it.id }

    // UV 表达式 runner 缓存：同一表达式字符串跨粒子复用编译产物。
    private val uvExprCache = HashMap<String, ScriptRuntime.ExpressionRunner?>()

    // 普通粒子 UV 表达式复用的 ProcessCtx（每次求值前改字段；vars 恒为 emptyMap）。
    private val uvCtx = ScriptRuntime.ProcessCtx(
        0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, emptyMap(),
        fastMath = false, duration = 0.0,
    )

    private fun uvExprRunner(expr: String): ScriptRuntime.ExpressionRunner? =
        uvExprCache.getOrPut(expr) {
            try {
                ScriptRuntime.ExpressionRunner(expr)
            } catch (e: Throwable) {
                println("[pdrawc] UV 表达式编译失败：${e.message}")
                null
            }
        }

    /** 求值单个 UV 字段表达式；出错/非有限回退到数值字段 [fallback]。 */
    private fun evalUvField(expr: String?, ctx: ScriptRuntime.ProcessCtx, fallback: Double): Double {
        if (expr == null) return fallback
        val runner = uvExprRunner(expr) ?: return fallback
        return try {
            val v = runner.eval(ctx)
            if (v.isFinite()) v else fallback
        } catch (e: Throwable) {
            println("[pdrawc] UV 表达式求值失败：${e.message}")
            fallback
        }
    }

    /** 把 UV 表达式逐字段求值并生成「数值化」的新 UvData（表达式置 null）。 */
    private fun evalUv(uv: UvData, ctx: ScriptRuntime.ProcessCtx): UvData {
        if (!uv.hasExpressions()) return uv
        val start = intArrayOf(
            evalUvField(uv.uvStartExpr[0], ctx, uv.uvStart[0].toDouble()).roundToInt(),
            evalUvField(uv.uvStartExpr[1], ctx, uv.uvStart[1].toDouble()).roundToInt(),
        )
        val size = intArrayOf(
            evalUvField(uv.uvSizeExpr[0], ctx, uv.uvSize[0].toDouble()).roundToInt(),
            evalUvField(uv.uvSizeExpr[1], ctx, uv.uvSize[1].toDouble()).roundToInt(),
        )
        val step = intArrayOf(
            evalUvField(uv.uvStepExpr[0], ctx, uv.uvStep[0].toDouble()).roundToInt(),
            evalUvField(uv.uvStepExpr[1], ctx, uv.uvStep[1].toDouble()).roundToInt(),
        )
        val fps = evalUvField(uv.fpsExpr, ctx, uv.fps.toDouble()).toFloat()
        val maxFrame = evalUvField(uv.maxFrameExpr, ctx, uv.maxFrame.toDouble()).roundToInt()
        return UvData(uv.texture, uv.mode, uv.texSize, start, size, step, fps, maxFrame, uv.loop)
    }

    // —— 函数对象脚本运行时（setup 一次、tick 补跑、process 每帧一次） ——
    private val fxById: Map<String, FunctionObject> = animation.functions.associateBy { it.id }

    private class FxRuntime(
        val fx: FunctionObject,
        val program: ScriptProgram,
        val objState: ScriptRuntime.ObjectState,
    ) {
        val particles = ArrayList<ParticleHost>()
        var spawnSerial = 0
        var cursorMs = 0.0
        var curMs = 0.0
        /**
         * 上一次真正跑过 tick/process 的时刻（毫秒）。this.delta = 本次时刻 − 它，上限 100ms；
         * null = 本运行时还没跑过任何一个阶段，此时 this.delta 记 0（编辑器 generators.js 的 runtime.lastPhaseMs 同一套）。
         */
        var lastPhaseMs: Double? = null
        /** 函数对象级视图变换（脚本 this.viewScale / this.viewOffset）：本对象的派生粒子专用。 */
        val view = ViewTransform()

        companion object {
            // 与编辑器 generators.js 一致：阻止恶意脚本逐帧无限 spawn 造成内存/渲染 DoS。
            private const val MAX_FX_PARTICLES = 100_000
        }

        /** 粒子句柄桥接（脚本 this.spawn() / 粒子字段读写 / kill()）。 */
        inner class FxParticleHost(
            override val index: Int,
            var spawnMs: Double,
        ) : ParticleHost {
            override val pos = DoubleArray(3)
            override val color = doubleArrayOf(1.0, 1.0, 1.0, 1.0)
            override val vel = DoubleArray(3)
            override val scale = DoubleArray(3) { 1.0 }
            override var scaleDim = 0
            override var glow = false
            override var light = 0.0
            override var life = -1.0
            override val rotation = DoubleArray(3)   // 自转（度）；billboard=true 时忽略
            override var billboard = true
            override var spinLocal = true
            override val fields = HashMap<String, Any?>()
            var alive = true

            override fun kill() {
                if (!alive) return
                alive = false
                particles.remove(this)
            }
        }

        fun spawn(): ParticleHost {
            if (particles.size >= MAX_FX_PARTICLES) {
                throw ScriptException("function object particle limit ($MAX_FX_PARTICLES) exceeded")
            }
            val serial = spawnSerial++
            val host = FxParticleHost(serial, curMs)
            particles.add(host)
            return host
        }

        // —— 循环回卷快照：避免回卷时重新 setup / 重建粒子造成顿挫，并保证 rand/global 确定性。 ——
        // loopSnapshot：process 前（首圈活动窗口首个 tick、cursor == st）捕获，供一般向后 seek 正向补跑。
        // loopDoneSnapshot：process 后（t == st）捕获，供回卷恰好落在 st 时直接恢复并跳过 process。
        var loopSnapshot: LoopSnapshot? = null
        var loopDoneSnapshot: LoopSnapshot? = null
        var skipProcessOnce = false

        class LoopSnapshot(
            val particles: List<HostSnapshot>,
            val spawnSerial: Int,
            val cursorMs: Double,
            val curMs: Double,
            val globals: Map<String, Any?>,
            val randState: Int,
            val viewScale: Double,
            val viewOffset: DoubleArray,
        )

        class HostSnapshot(
            val index: Int,
            val spawnMs: Double,
            val pos: DoubleArray,
            val color: DoubleArray,
            val vel: DoubleArray,
            val scale: DoubleArray,
            val scaleDim: Int,
            val glow: Boolean,
            val light: Double,
            val life: Double,
            val rotation: DoubleArray,
            val billboard: Boolean,
            val spinLocal: Boolean,
            val fields: Map<String, Any?>,
        )

        private fun buildSnapshot(): LoopSnapshot = LoopSnapshot(
            particles = particles.map { h ->
                val p = h as FxParticleHost
                HostSnapshot(
                    index = p.index,
                    spawnMs = p.spawnMs,
                    pos = p.pos.copyOf(),
                    color = p.color.copyOf(),
                    vel = p.vel.copyOf(),
                    scale = p.scale.copyOf(),
                    scaleDim = p.scaleDim,
                    glow = p.glow,
                    light = p.light,
                    life = p.life,
                    rotation = p.rotation.copyOf(),
                    billboard = p.billboard,
                    spinLocal = p.spinLocal,
                    fields = HashMap<String, Any?>().also { out ->
                        for ((k, v) in p.fields) out[k] = deepCopyScriptValue(v)
                    },
                )
            },
            spawnSerial = spawnSerial,
            cursorMs = cursorMs,
            curMs = curMs,
            globals = HashMap<String, Any?>().also { out ->
                for ((k, v) in objState.globals) out[k] = deepCopyScriptValue(v)
            },
            randState = objState.rand.a,
            viewScale = view.scale,
            viewOffset = view.offset.copyOf(),
        )

        fun captureLoopSnapshot() {
            loopSnapshot = buildSnapshot()
        }

        fun captureLoopDoneSnapshot() {
            loopDoneSnapshot = buildSnapshot()
        }

        /** 按目标 tick 恢复循环起点：目标恰为 st 时用 process 后快照并跳过 process；否则用 process 前快照正向补跑。 */
        fun restoreForLoopStart(targetT: Double) {
            val st = fx.st.toDouble()
            val done = loopDoneSnapshot
            if (done != null && targetT == st) {
                applySnapshot(done)
                skipProcessOnce = true
            } else {
                loopSnapshot?.let { applySnapshot(it) }
            }
        }

        private fun applySnapshot(s: LoopSnapshot) {
            // 原地恢复：按 index 复用本圈仍存活的句柄，只回写字段；
            // 避免每圈全量重新分配粒子句柄（每个句柄还带 3 个 DoubleArray + fields Map）造成 GC 顿挫。
            val aliveByIndex = HashMap<Int, FxParticleHost>(particles.size)
            for (h in particles) {
                val host = h as FxParticleHost
                aliveByIndex[host.index] = host
            }
            particles.clear()
            for (hs in s.particles) {
                val host = aliveByIndex.remove(hs.index) ?: FxParticleHost(hs.index, hs.spawnMs)
                host.spawnMs = hs.spawnMs
                hs.pos.copyInto(host.pos)
                hs.color.copyInto(host.color)
                hs.vel.copyInto(host.vel)
                hs.scale.copyInto(host.scale)
                host.scaleDim = hs.scaleDim
                host.glow = hs.glow
                host.light = hs.light
                host.life = hs.life
                hs.rotation.copyInto(host.rotation)
                host.billboard = hs.billboard
                host.spinLocal = hs.spinLocal
                host.alive = true
                host.fields.clear()
                for ((k, v) in hs.fields) host.fields[k] = deepCopyScriptValue(v)
                particles.add(host)
            }
            // aliveByIndex 剩余的是本圈额外 spawn / 已被 kill 的句柄，不再入列，自然丢弃。
            spawnSerial = s.spawnSerial
            cursorMs = s.cursorMs
            curMs = s.curMs
            // 回到本圈起点后时刻是往回走的，this.delta 不能拿回卷前的旧时刻算（会得到负值被钳成 0，
            // 语义上却是「上一次阶段」错位）：按编辑器的重建路径记成「还没跑过」，下一个阶段给 0。
            lastPhaseMs = null
            objState.globals.clear()
            for ((k, v) in s.globals) objState.globals[k] = deepCopyScriptValue(v)
            objState.rand.a = s.randState
            view.scale = s.viewScale
            s.viewOffset.copyInto(view.offset)
        }
    }

    private val fxRuntimes: MutableMap<String, FxRuntime?> = buildFxRuntimes()
    private val derivedByFx: HashMap<String, HashSet<String>> = HashMap()
    private val derivedHosts: HashMap<String, FxRuntime.FxParticleHost> = HashMap()

    // 视觉会随时间变化的普通粒子（有轨道/速度/入场过渡）；其余静态粒子每 tick 只更新可见性。
    private val dynamicParticleIds: Set<String> = buildDynamicParticleIds()

    private fun buildFxRuntimes(): MutableMap<String, FxRuntime?> {
        val map = HashMap<String, FxRuntime?>()
        for (fx in animation.functions) map[fx.id] = buildFxRuntime(fx)
        return map
    }

    private fun buildFxRuntime(fx: FunctionObject): FxRuntime? = try {
        val program = parseProgram(fx.source)
        val obj = ScriptRuntime.createObjectState(fx.seed)
        val rt = FxRuntime(fx, program, obj)
        rt.cursorMs = ceil(fx.st.toDouble() / 50.0) * 50.0 - 50.0
        rt.curMs = fx.st.toDouble()
        ScriptRuntime.runSpawnSetup(program, obj, makeCtx(fx, rt, fx.st.toDouble()))
        // 与编辑器一致：setup 不算「跑过阶段」，第一个 tick/process 的 this.delta 记 0。
        rt.lastPhaseMs = fx.st.toDouble()
        rt
    } catch (e: Throwable) {
        println("[pdrawc] 函数对象 ${fx.id} 编译失败：${e.message}")
        null
    }

    private fun resetFxRuntime(fx: FunctionObject, rt: FxRuntime) {
        rt.particles.clear()
        rt.spawnSerial = 0
        rt.cursorMs = ceil(fx.st.toDouble() / 50.0) * 50.0 - 50.0
        rt.curMs = fx.st.toDouble()
        // 与编辑器一致：向后 seek 重建 objState（fresh globals + fresh PRNG），
        // 避免 setup 反复在脏 global / 已推进的 rand 状态上叠加导致漂移。
        rt.objState.globals.clear()
        rt.objState.constGlobals.clear()
        rt.objState.topLevelDone = false
        rt.objState.rand.a = fx.seed
        rt.view.reset()
        // 重建后第一个 process/tick 的 this.delta 记 0（编辑器重建运行时后 lastPhaseMs 也是空的）。
        rt.lastPhaseMs = null
        try {
            ScriptRuntime.runSpawnSetup(rt.program, rt.objState, makeCtx(fx, rt, fx.st.toDouble()))
        } catch (e: Throwable) {
            println("[pdrawc] 函数对象 ${fx.id} setup 求值失败：${e.message}")
        }
    }

    /**
     * this.delta：本次阶段时刻距上一次跑过 tick/process 的毫秒数，上限 100ms（编辑器 MAX_PHASE_DELTA_MS）。
     * 首次执行前给 0——编辑器用 lastPhaseMs == null 表达同一件事。
     */
    private fun fxDeltaMs(rt: FxRuntime, t: Double): Double {
        val last = rt.lastPhaseMs ?: return 0.0
        return ((t - last).coerceAtLeast(0.0)).coerceAtMost(100.0)
    }

    private fun makeCtx(fx: FunctionObject, rt: FxRuntime, t: Double): ScriptRuntime.ScriptCtx =
        ScriptRuntime.ScriptCtx(
            t = t,
            duration = fx.duration.toDouble(),
            vars = varsAt(fx, t),
            particles = rt.particles,
            spawn = rt::spawn,
            deltaMs = fxDeltaMs(rt, t),
            fastMath = fx.fastMath,
            print = { line -> println("[pdrawc:${fx.id}] $line") },
            st = fx.st.toDouble(),
            maxMs = maxMs.toDouble(),
            view = rt.view,
            get = { name ->
                animation.texts.firstOrNull { it.name == name }?.let { TextValue(it) }
                    ?: animation.audioAssets.firstOrNull { it.name == name }?.let { a ->
                        val owner = "a:" + a.id
                        // v18：内容位置按倍速折算，倍速/是否在窗口内都走轨道求值（与编辑器同一套公式）
                        val speed = audioSpeedOf(audioProp(owner, TrackPr.SPEED, a.speed, t)).coerceIn(0.25, 4.0)
                        val local = (t - a.st) * speed
                        AudioValue(a, t, local >= 0.0 && local < a.durMs, speed)
                    }
                    ?: throw ScriptException("unknown asset '$name'")
            },
        )

    private fun buildTrackIndex(): Map<TrackPr, Map<String, AnimTrack>> {
        val map = HashMap<TrackPr, HashMap<String, AnimTrack>>()
        for (tr in animation.tracks) {
            if (tr.ids.size == 1) {
                val byId = map.getOrPut(tr.pr) { HashMap() }
                byId[tr.ids[0]] = tr
            }
        }
        return map
    }

    private fun buildParticleGroupIndex(): Map<String, Set<String>> {
        val map = HashMap<String, HashSet<String>>()
        for ((gname, members) in animation.groups) {
            for (id in members) map.getOrPut(id) { HashSet() }.add("g:$gname")
        }
        for (tx in animation.texts) {
            for (id in tx.memberIds()) map.getOrPut(id) { HashSet() }.add("t:${tx.id}")
        }
        return map
    }

    private fun buildGroupCentroids(): Map<String, Vec3> {
        val byId = HashMap<String, AnimParticle>()
        for (p in animation.particles) byId[p.id] = p
        val map = HashMap<String, Vec3>()
        for (gname in animation.groups.keys) {
            centroidOf("g:$gname", byId)?.let { map["g:$gname"] = it }
        }
        for (tx in animation.texts) {
            centroidOf("t:${tx.id}", byId)?.let { map["t:${tx.id}"] = it }
        }
        return map
    }

    /** owner（组/文字对象）质心（成员位置平均）；空或不存在返回 null。 */
    private fun centroidOf(okey: String, byId: Map<String, AnimParticle>): Vec3? {
        val members = ownerMembers(okey) ?: return null
        var sx = 0.0; var sy = 0.0; var sz = 0.0; var n = 0
        for (id in members) {
            val m = byId[id] ?: continue
            sx += m.pos.x; sy += m.pos.y; sz += m.pos.z; n++
        }
        if (n == 0) return null
        return Vec3(sx / n, sy / n, sz / n)
    }

    /** owner 键（'g:名' | 't:id'）的成员粒子 id 列表。 */
    private fun ownerMembers(okey: String): List<String>? = when {
        okey.startsWith("g:") -> animation.groups[okey.removePrefix("g:")]
        okey.startsWith("t:") -> animation.texts.firstOrNull { it.id == okey.removePrefix("t:") }?.memberIds()
        else -> null
    }

    /** owner 键的自转空间（true=local）。 */
    private fun ownerSpinLocal(okey: String): Boolean = when {
        okey.startsWith("g:") -> animation.groupSpinSpace[okey.removePrefix("g:")] ?: true
        okey.startsWith("t:") -> animation.texts.firstOrNull { it.id == okey.removePrefix("t:") }?.spinLocal ?: true
        else -> true
    }

    /** owner 键的公转空间（true=local）。 */
    private fun ownerRotLocal(okey: String): Boolean = when {
        okey.startsWith("g:") -> animation.groupRotSpace[okey.removePrefix("g:")] ?: true
        okey.startsWith("t:") -> animation.texts.firstOrNull { it.id == okey.removePrefix("t:") }?.rotLocal ?: true
        else -> true
    }

    /** 派生粒子 id（fxId:p<serial>）反查函数对象；普通粒子返回 null。 */
    private fun particleFunction(id: String): FunctionObject? {
        val marker = id.indexOf(":p")
        if (marker <= 0) return null
        return fxById[id.substring(0, marker)]
    }

    // 标记「视觉会随时间变化」的普通粒子（有轨道/速度/入场过渡）；其余静态粒子只更新 st/life 可见性，省去每 tick 重算与分配。
    // 派生粒子由函数对象循环求值，不在本集合内。
    private fun buildDynamicParticleIds(): Set<String> {
        val ids = HashSet<String>()
        for (p in animation.particles) {
            if (p.vel.x != 0.0 || p.vel.y != 0.0 || p.vel.z != 0.0) ids.add(p.id)
            if (p.ent != null) ids.add(p.id)
        }
        for (tr in animation.tracks) {
            if (tr.keyframes.isEmpty()) continue
            for (id in tr.ids) {
                if (id.startsWith("g:") || id.startsWith("t:")) {
                    val members = ownerMembers(id) ?: continue
                    ids.addAll(members)
                } else if (!id.startsWith("f:")) {
                    ids.add(id)
                }
            }
        }
        return ids
    }

    init {
        for (p in animation.particles) {
            states[p.id] = ParticleState(
                p.id, origin.add(p.pos), p.color, p.scale.copyOf(), p.glowing, p.lightLevel, resolveUV(p.id, p.uv),
                billboard = p.billboard, spinLocal = p.spinLocal,
            )
        }
        // 函数对象运行时已在字段初始化阶段构建（setup 各执行一次）；派生粒子状态由 advanceFunctions 的
        // reconcile 按当前存活粒子动态创建/更新/删除。
        // 按服务端权威进度定位到当前帧（elapsed = currentGameTick - startGameTick）：
        // 新播放等价于从 0 开始；重发/迟到加入则直接跳到其他玩家正在看的同一帧。
        val initial = if (initialMs >= 0) initialMs else progressMsAt((currentGameTick - startGameTick))
        currentMs = initial
        advanceTo(initial.toDouble())
        advanceFunctions(initial.toDouble())
    }

    /**
     * 以维度 gameTime 为权威时钟推进一 tick。
     * 所有客户端使用同一 startGameTick 与同一 gameTime，因此帧号完全一致；
     * 本地不再各自递增，杜绝客户端间漂移与重发后从头重播的问题。
     */
    fun tick(gameTick: Long): Boolean {
        if (finished) return false
        frameCount++
        val elapsedTicks = (gameTick - startGameTick).coerceAtLeast(0L)
        if (AnimationProgress.isFinished(elapsedTicks, maxMs, animation.loop)) {
            finished = true
            return false
        }
        val target = progressMsAt(elapsedTicks)
        if (target != currentMs) {
            if (target < currentMs) {
                justLooped = true // 循环回卷（st 门控粒子在 sync 中重新生成）
                if (!isStaticAnimation) {
                    restoreLoopStart(target)
                    reconcileFunctions(target.toDouble())
                }
            }
            currentMs = target
            if (!isStaticAnimation) {
                val t0 = System.nanoTime()
                advanceTo(target.toDouble())
                val elapsedNs = System.nanoTime() - t0
                lastAdvanceNanos = elapsedNs
                advanceNanosTotal += elapsedNs
                advanceCount++
            }
        }
        return true
    }

    /**
     * 由外部播放时钟驱动推进（特效 API 使用）：直接给定目标时间轴毫秒，
     * 而非由 `gameTime - startGameTick` 推导。支持任意 seek（含向后回退）、暂停与变速。
     * @return 是否仍在播放（非循环动画越过 maxMs 时返回 false 并置 finished）
     */
    fun tickExternal(targetMs: Int): Boolean {
        if (finished) return false
        frameCount++
        val max = maxMs
        if (!animation.loop && max > 0 && targetMs >= max) {
            finished = true
            return false
        }
        val target = if (max <= 0) targetMs.coerceAtLeast(0)
        else if (animation.loop) ((targetMs % max) + max) % max
        else minOf(targetMs, max - 1)
        if (target != currentMs) {
            if (target < currentMs && animation.loop) {
                justLooped = true
                if (!isStaticAnimation) {
                    restoreLoopStart(target)
                    reconcileFunctions(target.toDouble())
                }
            }
            currentMs = target
            if (!isStaticAnimation) advanceTo(target.toDouble())
        }
        return true
    }

    fun isFinished(): Boolean = finished
    fun consumeJustLooped(): Boolean { val v = justLooped; justLooped = false; return v }
    fun isStatic(): Boolean = isStaticAnimation

    /** 循环回卷：把函数对象运行时恢复到循环起点快照，避免重新 setup / 重建粒子。 */
    private fun restoreLoopStart(target: Int) {
        for (rt in fxRuntimes.values) {
            rt ?: continue
            try {
                rt.restoreForLoopStart(target.toDouble())
            } catch (e: Throwable) {
                println("[pdrawc] 函数对象 ${rt.fx.id} 循环回卷恢复失败：${e.message}")
            }
        }
    }

    private fun usesRandom(fx: FunctionObject): Boolean =
        Regex("\\brandom\\s*\\(").containsMatchIn(fx.source) || Regex("\\brand\\s*\\(").containsMatchIn(fx.source)
    fun currentStates(): Collection<ParticleState> = states.values

    /** 派生粒子 id（fxId:p<serial>）判断。 */
    fun isDerivedId(id: String): Boolean = particleFunction(id) != null

    /** 该派生粒子所属函数对象是否开启帧级同步（false=按 game tick 同步，与普通粒子渲染一致）。 */
    fun isFrameSyncDerived(id: String): Boolean = particleFunction(id)?.frameSync == true

    fun stop() { finished = true }

    // 查询摄像机在 t 时刻的姿态；与编辑器 cameraPoseAt 语义一致。
    // pos/target：set=绝对值、op=增量；roll 静态不走关键帧；fov 不分 set/op。
    // 旋转 = 位置绕 target 公转：world 绕世界轴，local 按 lookAt+roll 朝向做 intrinsic XYZ。摄像机不存在时返回 null。
    fun cameraPoseAt(camId: String, t: Double): CameraPose? {
        val cam = animation.cameras.firstOrNull { it.id == camId } ?: return null
        val id = "c:" + camId
        val pos = DoubleArray(3)
        val target = DoubleArray(3)
        val posPr = arrayOf(TrackPr.POS_X, TrackPr.POS_Y, TrackPr.POS_Z)
        val targetPr = arrayOf(TrackPr.TARGET_X, TrackPr.TARGET_Y, TrackPr.TARGET_Z)
        for (i in 0 until 3) {
            pos[i] = cameraComponentAt(id, posPr[i], cam.pos[i], t)
            target[i] = cameraComponentAt(id, targetPr[i], cam.target[i], t)
        }
        val rot = rotVectorAt(id, t)
        if (rot[0] != 0.0 || rot[1] != 0.0 || rot[2] != 0.0) {
            applyCameraOrbit(pos, target, rot, cam.rotLocal, cam.roll)
        }
        val roll = cam.roll
        val fov = scalarAt(TrackPr.FOV, id, t, cam.fov)
        return CameraPose(pos, target, roll, fov)
    }

    /** 摄像机公转：把位置绕「看向目标点」旋转。 */
    private fun applyCameraOrbit(pos: DoubleArray, target: DoubleArray, rot: DoubleArray, rotLocal: Boolean, roll: Double) {
        val d = Vec3(pos[0] - target[0], pos[1] - target[1], pos[2] - target[2])
        if (d.lengthSqr() < 1e-18) return // 与目标重合：无法公转
        val r = if (rotLocal) {
            val frame = cameraLookFrame(Vec3(pos[0], pos[1], pos[2]), Vec3(target[0], target[1], target[2]), roll)
                ?: return worldCameraOrbitInto(pos, target, rot)
            rotateAroundFrame(d, rot, frame.first, frame.second, frame.third)
        } else {
            rotateAround(d, Vec3.ZERO, rot)
        }
        pos[0] = target[0] + r.x
        pos[1] = target[1] + r.y
        pos[2] = target[2] + r.z
    }

    /** 世界空间回退（lookAt 退化时）：绕世界 X/Y/Z 轴依次旋转并写回 pos。 */
    private fun worldCameraOrbitInto(pos: DoubleArray, target: DoubleArray, rot: DoubleArray) {
        val d = Vec3(pos[0] - target[0], pos[1] - target[1], pos[2] - target[2])
        val r = rotateAround(d, Vec3.ZERO, rot)
        pos[0] = target[0] + r.x
        pos[1] = target[1] + r.y
        pos[2] = target[2] + r.z
    }

    /**
     * 摄像机 lookAt+roll 朝向基（列 = 世界坐标）：(right, camUp, back)。
     * 与编辑器一致：局部 +Z = normalize(pos − target)（即局部 −Z 指向目标），
     * right = normalize(cross(up, back))，camUp = cross(back, right)，再绕 back 翻滚 roll。
     * 视线与世界 up 平行（lookAt 退化）时返回 null。
     */
    private fun cameraLookFrame(pos: Vec3, target: Vec3, roll: Double): Triple<Vec3, Vec3, Vec3>? {
        val back = pos.subtract(target).normalize()
        var right = camUp.cross(back)
        if (right.lengthSqr() < 1e-12) return null
        right = right.normalize()
        val up = back.cross(right)
        if (roll == 0.0) return Triple(right, up, back)
        val rz = Math.toRadians(roll)
        return Triple(right.rotateAround(back, rz), up.rotateAround(back, rz), back)
    }

    /** 在给定正交基（列 = 世界坐标）下做 intrinsic XYZ 旋转（绕原点；与编辑器 M_look·M_local·M_lookᵀ 等价）。 */
    private fun rotateAroundFrame(p: Vec3, rot: DoubleArray, xAxis: Vec3, yAxis: Vec3, zAxis: Vec3): Vec3 {
        var r = p
        val rx = Math.toRadians(rot[0])
        val ry = Math.toRadians(rot[1])
        val rz = Math.toRadians(rot[2])
        if (rot[0] != 0.0) r = r.rotateAround(xAxis, rx)
        var y = yAxis
        if (rot[0] != 0.0) y = y.rotateAround(xAxis, rx)
        if (rot[1] != 0.0) r = r.rotateAround(y, ry)
        var z = zAxis
        if (rot[0] != 0.0) z = z.rotateAround(xAxis, rx)
        if (rot[1] != 0.0) z = z.rotateAround(y, ry)
        if (rot[2] != 0.0) r = r.rotateAround(z, rz)
        return r
    }

    /** 摄像机单分量求值（pos/target；set=绝对值，op=增量叠加到基础值）。 */
    private fun cameraComponentAt(id: String, pr: TrackPr, base: Double, t: Double): Double {
        val tr = findTrackByPr(pr, id) ?: return base
        if (tr.keyframes.isEmpty()) return base
        return if (tr.mode == AnimTrack.Mode.OP) base + trackValueAt(tr, t, 0.0) else trackValueAt(tr, t, base)
    }

    fun updateVariable(name: String, value: String) {
        // 非数字值：忽略（不把用户参数悄悄清零——静默降级禁止）。数字值：整组生效——
        // §5.4 契约「对整组生效」，所有声明该变量的函数对象都要更新，不是第一个。
        val numeric = value.toDoubleOrNull() ?: return
        for (fx in animation.functions) {
            val v = fx.vars[name] ?: continue
            v.base = numeric
            v.kf = emptyList()
            fxRuntimes[fx.id] = buildFxRuntime(fx)
        }
    }

    /**
     * 把时间推进到 t（毫秒）：普通粒子门控/视觉 + UV 表达式。
     * 函数对象脚本（setup/tick/process）由 [advanceFrame] 按渲染帧单独驱动。
     */
    private fun advanceTo(t: Double) {
        advanceOrdinary(t)
        advanceUv(t)
        prevAdvanceT = t
        advanceInitialized = true
    }

    /**
     * 每渲染帧推进函数对象脚本到渲染帧时刻 t（毫秒，可为小数）。
     * 与编辑器语义一致：process 每渲染帧执行一次；tick 只在 50ms 边界补跑；寿命按真实经过毫秒递减。
     * 顺带刷新 UV，使 process 新 spawn 的派生粒子当帧即获得正确贴图。
     */
    fun advanceFrame(t: Double) {
        if (finished || isStaticAnimation) return
        advanceFunctions(t)
        advanceUv(t)
        prevAdvanceT = t
    }

    /** 函数对象推进（50ms 边界补跑 tick + 按真实经过毫秒递减寿命 + process + reconcile）。 */
    private fun advanceFunctions(t: Double) {
        for (fx in animation.functions) {
            val rt = fxRuntimes[fx.id] ?: continue
            try {
                advanceFx(fx, rt, t)
            } catch (e: Throwable) {
                println("[pdrawc] 函数对象 ${fx.id} 推进失败：${e.message}")
            }
        }
    }

    /** 仅 reconcile 函数对象（宿主状态 → 渲染状态），不跑 process/tick；用于循环回卷后立即刷新派生粒子状态。 */
    private fun reconcileFunctions(t: Double) {
        for (fx in animation.functions) {
            val rt = fxRuntimes[fx.id] ?: continue
            try {
                reconcileFxStates(fx, rt, t, t - fx.st)
            } catch (e: Throwable) {
                println("[pdrawc] 函数对象 ${fx.id} reconcile 失败：${e.message}")
            }
        }
    }

    /** 普通粒子：st/life 门控 + 视觉更新（轨道/速度/入场过渡）。 */
    private fun advanceOrdinary(t: Double) {
        for (p in animation.particles) {
            val s = states[p.id] ?: continue
            val localT = t - p.st
            val life = p.life
            // st 门控 + 寿命到期回收（life=-1 无限）
            s.visible = localT >= 0 && (life < 0 || localT < life)
            if (p.id in dynamicParticleIds) {
                s.pos = origin.add(particlePosition(p, t))
                s.color = applyEntrance(particleColor(p, t), p.ent, localT)
                particleScaleInto(p, t, s.scale)
                // v17：粒子级自转（仅非广告牌时渲染端可见）
                s.billboard = p.billboard
                s.spinLocal = p.spinLocal
                val sp = spinVectorAt(p.id, t)
                s.spin[0] = sp[0]; s.spin[1] = sp[1]; s.spin[2] = sp[2]
            }
        }
    }

    /** UV 字段表达式求值（普通 + 派生粒子统一；n=总粒子数，与编辑器 state.particles.length 一致）。 */
    private fun advanceUv(t: Double) {
        val n = states.size.toDouble()
        for ((id, s) in states) {
            val host = derivedHosts[id]
            val fx = particleFunction(id)
            val ownUv = if (fx != null) fx.uv else animationParticleById[id]?.uv
            val resolvedUv = resolveUV(id, ownUv)
            if (resolvedUv != null && resolvedUv.hasExpressions()) {
                // 与编辑器 ensureOut 一致：先把 out 归到默认值，再逐字段镜像本粒子状态。
                // rotation/billboard/spinSpace 编辑器在 UV 表达式里也不镜像（只留在默认值），
                // 这里同样不写；靠这次重置保证「上一个粒子写过的值」不会串到下一个粒子。
                uvCtx.resetOut()
                uvCtx.i = host?.index?.toDouble() ?: (particleGlobalIndex[id] ?: 0).toDouble()
                uvCtx.n = n
                uvCtx.t = t
                uvCtx.dt = 0.0
                uvCtx.duration = maxMs.toDouble()
                uvCtx.life = host?.life ?: (animationParticleById[id]?.life?.toDouble() ?: -1.0)
                uvCtx.uv_x = 0.0
                uvCtx.uv_y = 0.0
                uvCtx.out.pos[0] = s.pos.x; uvCtx.out.pos[1] = s.pos.y; uvCtx.out.pos[2] = s.pos.z
                uvCtx.out.color[0] = s.color.r.toDouble(); uvCtx.out.color[1] = s.color.g.toDouble()
                uvCtx.out.color[2] = s.color.b.toDouble(); uvCtx.out.color[3] = s.color.a.toDouble()
                if (host != null) {
                    uvCtx.out.vel[0] = host.vel[0]; uvCtx.out.vel[1] = host.vel[1]; uvCtx.out.vel[2] = host.vel[2]
                } else {
                    val p = animationParticleById[id]
                    if (p != null) {
                        uvCtx.out.vel[0] = componentValueAt(p, TrackPr.VEL_X, t)
                        uvCtx.out.vel[1] = componentValueAt(p, TrackPr.VEL_Y, t)
                        uvCtx.out.vel[2] = componentValueAt(p, TrackPr.VEL_Z, t)
                    }
                }
                uvCtx.out.scale = s.scale[0].toDouble()
                uvCtx.out.glow = s.glowing
                uvCtx.out.light = s.lightLevel.toDouble()
                uvCtx.out.life = uvCtx.life
                s.uv = evalUv(resolvedUv, uvCtx)
            } else {
                s.uv = resolvedUv
            }
        }
    }

    // 把函数对象推进到时间 t（毫秒，与编辑器 evaluateFxFrame 同语义）。
    // t < st 或超时长只保持 setup；向后 seek 重建运行时；正常则按经过毫秒递减寿命、补跑 50ms 边界 tick()、再跑一次 process()。
    private fun advanceFx(fx: FunctionObject, rt: FxRuntime, t: Double) {
        val st = fx.st.toDouble()
        val dur = fx.duration.toDouble()
        if (t >= st && (dur <= 0 || t < st + dur)) {
            // 向后 seek：确定性重算
            if (t < rt.curMs) resetFxRuntime(fx, rt)

            var b = rt.cursorMs + 50.0
            while (b <= t) {
                decrementLifeMs(fx, rt, rt.curMs, b)
                rt.curMs = b
                rt.cursorMs = b
                if (rt.program.tick.isNotEmpty()) {
                    try {
                        ScriptRuntime.runTickFrame(rt.program, rt.objState, makeCtx(fx, rt, b))
                        // 与编辑器一致：跑过的阶段才算「上一次」，this.delta 从它起算。
                        rt.lastPhaseMs = b
                    } catch (e: Throwable) {
                        println("[pdrawc] 函数对象 ${fx.id} tick 求值失败：${e.message}")
                        break
                    }
                }
                // 捕获循环起点快照：loop 动画首圈、首个 50ms 边界、process 执行前。
                if (animation.loop && rt.loopSnapshot == null) {
                    rt.captureLoopSnapshot()
                }
                b += 50.0
            }

            decrementLifeMs(fx, rt, rt.curMs, t)
            rt.curMs = t
            if (rt.skipProcessOnce) {
                rt.skipProcessOnce = false
            } else if (rt.program.process.isNotEmpty()) {
                try {
                    ScriptRuntime.runProcessFrame(rt.program, rt.objState, makeCtx(fx, rt, t))
                    rt.lastPhaseMs = t
                } catch (e: Throwable) {
                    println("[pdrawc] 函数对象 ${fx.id} process 求值失败：${e.message}")
                }
            }
            // 捕获 process 后快照：loop 动画首圈、恰在 t == st、process 执行后。
            if (animation.loop && rt.loopDoneSnapshot == null && t == st) {
                rt.captureLoopDoneSnapshot()
            }
        }
        reconcileFxStates(fx, rt, t, t - fx.st)
    }

    /** 按真实经过毫秒递减剩余寿命；到期（或 life 已为 0）立即移除。 */
    private fun decrementLifeMs(fx: FunctionObject, rt: FxRuntime, fromMs: Double, toMs: Double) {
        val st = fx.st.toDouble()
        if (!(toMs > fromMs)) return
        for (i in rt.particles.indices.reversed()) {
            val host = rt.particles[i] as FxRuntime.FxParticleHost
            val entry = max(host.spawnMs, st)
            if (host.life >= 0.0 && toMs > entry) {
                val elapsed = toMs - max(entry, fromMs)
                if (elapsed > 0.0) {
                    if (host.life <= elapsed) {
                        host.kill()
                    } else {
                        host.life -= elapsed
                    }
                }
            }
        }
    }

    /** 把函数对象当前存活粒子同步进渲染状态（新建/更新/删除 + 整体变换 + 可见性门控）。 */
    private fun reconcileFxStates(fx: FunctionObject, rt: FxRuntime, t: Double, fxLocalT: Double) {
        val visible = fxLocalT >= 0 && (fx.duration <= 0 || fxLocalT < fx.duration)
        val cx = fx.center[0]; val cy = fx.center[1]; val cz = fx.center[2]
        // 整体变换 / 自转 / 公转 / op 增量 每 tick 只算一次（与粒子序号无关）
        val sx = scalarAt(TrackPr.SPIN_X, "f:" + fx.id, t, 0.0)
        val sy = scalarAt(TrackPr.SPIN_Y, "f:" + fx.id, t, 0.0)
        val sz = scalarAt(TrackPr.SPIN_Z, "f:" + fx.id, t, 0.0)
        val hasSpin = sx != 0.0 || sy != 0.0 || sz != 0.0
        val spinPivot = Vec3(cx, cy, cz)
        val spin = doubleArrayOf(sx, sy, sz)
        val rx = scalarAt(TrackPr.ROT_X, "f:" + fx.id, t, 0.0)
        val ry = scalarAt(TrackPr.ROT_Y, "f:" + fx.id, t, 0.0)
        val rz = scalarAt(TrackPr.ROT_Z, "f:" + fx.id, t, 0.0)
        val hasRot = rx != 0.0 || ry != 0.0 || rz != 0.0
        val orbitPivot = orbitCenterAt("f:" + fx.id, t)
        val rot = doubleArrayOf(rx, ry, rz)
        val dx = opDeltaAt(TrackPr.POS_X, "f:" + fx.id, t)
        val dy = opDeltaAt(TrackPr.POS_Y, "f:" + fx.id, t)
        val dz = opDeltaAt(TrackPr.POS_Z, "f:" + fx.id, t)

        val newIds = HashSet<String>()
        for (particle in rt.particles) {
            val host = particle as FxRuntime.FxParticleHost
            val id = fx.id + ":p" + host.index
            newIds.add(id)
            derivedHosts[id] = host
            val s = states.getOrPut(id) {
                ParticleState(id, Vec3.ZERO, Color.WHITE, floatArrayOf(1f, 1f, 1f), false, 0, null, visible = true, derived = true, additive = fx.additive)
            }
            s.additive = fx.additive   // 已在状态里时也保持跟随函数对象（导出文件里该字段不变，但保持一致）
            // 函数对象级视图变换（脚本 this.viewScale / this.viewOffset）：整条迹线的全局增益与直流偏移。
            // 套在粒子自己的局部坐标上——与脚本 p.position 同一套坐标系，也就是下面这条链路（center → 自转 →
            // pos op → 公转）的**最前**；于是对象有自转/公转时偏移会被一起带着转（有意语义）。
            val vs = rt.view.scale
            val vo = rt.view.offset
            var pos = Vec3(
                host.pos[0] * vs + vo[0] + cx,
                host.pos[1] * vs + vo[1] + cy,
                host.pos[2] * vs + vo[2] + cz,
            )
            if (hasSpin) pos = if (fx.spinLocal) rotateAroundLocal(pos, spinPivot, spin) else rotateAround(pos, spinPivot, spin)
            // pos op 位移必须先于公转：函数对象的实际世界位置应绕公转中心旋转。
            pos = Vec3(pos.x + dx, pos.y + dy, pos.z + dz)
            if (hasRot) pos = if (fx.rotLocal) rotateAroundLocalOrbit(pos, orbitPivot, rot, spin, fx.spinLocal) else rotateAround(pos, orbitPivot, rot)
            s.pos = origin.add(pos)
            s.color = applyEntrance(
                Color.of(
                    host.color[0].coerceIn(0.0, 1.0).toFloat(),
                    host.color[1].coerceIn(0.0, 1.0).toFloat(),
                    host.color[2].coerceIn(0.0, 1.0).toFloat(),
                    host.color[3].coerceIn(0.0, 1.0).toFloat(),
                ),
                fx.ent, fxLocalT,
            )
            fxScaleInto(fx.id, host.scale, t, s.scale)
            // 尺寸同样按全局增益均匀缩放（脚本会写 width = lineW / viewScale 来补偿线宽）
            if (vs != 1.0) {
                val vsf = vs.toFloat()
                s.scale[0] *= vsf
                s.scale[1] *= vsf
                s.scale[2] *= vsf
            }
            s.glowing = host.glow
            s.lightLevel = host.light.toInt().coerceIn(0, 15)
            s.visible = visible
            // v17：脚本逐粒子广告牌/自转（billboard=true 时渲染端忽略 spin）
            s.billboard = host.billboard
            s.spinLocal = host.spinLocal
            s.spin[0] = host.rotation[0]; s.spin[1] = host.rotation[1]; s.spin[2] = host.rotation[2]
        }
        // 删除已消失（被 kill / 重建后未再 spawn）的派生粒子状态
        val oldIds = derivedByFx[fx.id] ?: emptySet()
        for (id in oldIds) {
            if (id !in newIds) {
                states.remove(id)
                derivedHosts.remove(id)
            }
        }
        derivedByFx[fx.id] = newIds
    }

    /** 入场预设的 alpha 系数（仅 fade：localT ∈ [0,dur) 线性 0→1）；其余/超窗恒 1。 */
    private fun entranceFactor(ent: Entrance?, localT: Double): Float {
        if (ent == null || ent.preset != "fade" || localT >= ent.dur) return 1f
        if (localT <= 0) return 0f
        return (localT / ent.dur.coerceAtLeast(1)).toFloat()
    }

    private fun applyEntrance(c: Color, ent: Entrance?, localT: Double): Color {
        val k = entranceFactor(ent, localT)
        if (k >= 1f) return c
        return Color.of(c.r, c.g, c.b, (c.a * k))
    }

    private fun varsAt(fx: FunctionObject, t: Double): Map<String, Double> {
        val out = HashMap<String, Double>()
        for ((name, v) in fx.vars) out[name] = varValue(v, t)
        return out
    }

    private fun varValue(v: FunctionVar, t: Double): Double {
        val kf = v.kf
        if (kf.isEmpty()) return v.base
        if (t <= kf[0].ms) return kf[0].value
        if (t >= kf.last().ms) return kf.last().value
        var lo = 0
        var hi = kf.size - 1
        while (lo + 1 < hi) {
            val mid = (lo + hi) ushr 1
            if (kf[mid].ms <= t) lo = mid else hi = mid
        }
        val a = kf[lo]; val b = kf[lo + 1]
        val dur = b.ms - a.ms
        val f = if (dur == 0.0) 1.0 else (t - a.ms) / dur
        val e = b.easing.evaluate(f.toFloat()).toDouble()
        return a.value + (b.value - a.value) * e
    }

    private fun findTrackByPr(pr: TrackPr, id: String): AnimTrack? = trackIndex[pr]?.get(id)

    private fun trackValueAt(tr: AnimTrack, t: Double, fallback: Double): Double {
        val kfs = tr.keyframes
        if (kfs.isEmpty()) return fallback
        if (t <= kfs[0].ms) return kfs[0].value
        if (t >= kfs.last().ms) return kfs.last().value
        var lo = 0
        var hi = kfs.size - 1
        while (lo + 1 < hi) {
            val mid = (lo + hi) ushr 1
            if (kfs[mid].ms <= t) lo = mid else hi = mid
        }
        val a = kfs[lo]; val b = kfs[lo + 1]
        val dur = (b.ms - a.ms).toDouble()
        val f = if (dur == 0.0) 1.0 else (t - a.ms) / dur
        val e = b.easing.evaluate(f.toFloat()).toDouble()
        return a.value + (b.value - a.value) * e
    }

    private fun scalarAt(pr: TrackPr, id: String, t: Double, fallback: Double): Double {
        val tr = findTrackByPr(pr, id) ?: return fallback
        return trackValueAt(tr, t, fallback)
    }

    private fun opDeltaAt(pr: TrackPr, id: String, t: Double): Double {
        val tr = findTrackByPr(pr, id) ?: return 0.0
        if (tr.mode != AnimTrack.Mode.OP || tr.keyframes.isEmpty()) return 0.0
        return trackValueAt(tr, t, 0.0)
    }

    private fun findSetTrackFor(id: String, pr: TrackPr): AnimTrack? {
        findTrackByPr(pr, id)?.let { if (it.mode != AnimTrack.Mode.OP) return it }
        for (okey in particleGroupIndex[id] ?: emptySet()) {
            findTrackByPr(pr, okey)?.let { if (it.mode != AnimTrack.Mode.OP) return it }
        }
        val fx = particleFunction(id)
        if (fx != null) {
            findTrackByPr(pr, "f:" + fx.id)?.let { if (it.mode != AnimTrack.Mode.OP) return it }
        }
        return null
    }

    private fun compOpDelta(p: AnimParticle, pr: TrackPr, t: Double): Double {
        var delta = 0.0
        for (tr in opTracksByPr[pr] ?: emptyList()) {
            for (id in tr.ids) {
                if (id.startsWith("g:") || id.startsWith("t:")) {
                    val members = groupSets[id] ?: continue
                    if (p.id in members) delta += trackValueAt(tr, t, 0.0)
                } else if (id.startsWith("f:") && p.id.startsWith(id.removePrefix("f:") + ":p")) {
                    delta += trackValueAt(tr, t, 0.0)
                }
            }
        }
        return delta
    }

    private fun rotVectorAt(id: String, t: Double): DoubleArray =
        doubleArrayOf(
            scalarAt(TrackPr.ROT_X, id, t, 0.0),
            scalarAt(TrackPr.ROT_Y, id, t, 0.0),
            scalarAt(TrackPr.ROT_Z, id, t, 0.0),
        )

    private fun spinVectorAt(id: String, t: Double): DoubleArray =
        doubleArrayOf(
            scalarAt(TrackPr.SPIN_X, id, t, 0.0),
            scalarAt(TrackPr.SPIN_Y, id, t, 0.0),
            scalarAt(TrackPr.SPIN_Z, id, t, 0.0),
        )

    private fun orbitCenterAt(id: String, t: Double): Vec3 =
        Vec3(
            scalarAt(TrackPr.CENTER_X, id, t, 0.0),
            scalarAt(TrackPr.CENTER_Y, id, t, 0.0),
            scalarAt(TrackPr.CENTER_Z, id, t, 0.0),
        )

    private fun baseComponent(p: AnimParticle, pr: TrackPr): Double = when (pr) {
        TrackPr.POS_X -> p.pos.x
        TrackPr.POS_Y -> p.pos.y
        TrackPr.POS_Z -> p.pos.z
        TrackPr.COL_R -> p.color.r.toDouble()
        TrackPr.COL_G -> p.color.g.toDouble()
        TrackPr.COL_B -> p.color.b.toDouble()
        TrackPr.COL_A -> p.color.a.toDouble()
        TrackPr.VEL_X -> p.vel.x
        TrackPr.VEL_Y -> p.vel.y
        TrackPr.VEL_Z -> p.vel.z
        TrackPr.SCL_X -> p.scale[0].toDouble()
        TrackPr.SCL_Y -> p.scale[1].toDouble()
        TrackPr.SCL_Z -> p.scale[2].toDouble()
        else -> 0.0
    }

    /**
     * 音频对象播放属性求值（v18）：属主 [owner] = "a:<资产id>"，[pr] 为 VOL/SPEED/PAN/FADE_IN/FADE_OUT。
     * 没有轨道或轨道无关键帧时取资产自带的基础值 [base]（与编辑器 audioPropAt 一致）。
     */
    fun audioProp(owner: String, pr: TrackPr, base: Double, t: Double): Double {
        val tr = findTrackByPr(pr, owner) ?: return base
        if (tr.keyframes.isEmpty()) return base
        return trackValueAt(tr, t, base)
    }

    /** 倍速兜底：非有限值/<=0 一律按 1（与编辑器 audioSpeedOf 一致）。 */
    private fun audioSpeedOf(speed: Double): Double = if (speed.isFinite() && speed > 0.0) speed else 1.0

    private fun componentValueAt(p: AnimParticle, pr: TrackPr, t: Double): Double {
        var v = baseComponent(p, pr)
        val tr = findSetTrackFor(p.id, pr)
        if (tr != null && tr.keyframes.isNotEmpty()) v = trackValueAt(tr, t, v)
        v += compOpDelta(p, pr, t)
        return v
    }

    private fun particlePosition(p: AnimParticle, t: Double): Vec3 {
        var pos = Vec3(
            setComponentValueAt(p, TrackPr.POS_X, t),
            setComponentValueAt(p, TrackPr.POS_Y, t),
            setComponentValueAt(p, TrackPr.POS_Z, t),
        )
        pos = applyGroupScale(p, pos, t)
        pos = applyParticleOrbit(p, pos, t)
        pos = applySelfRotation(p, pos, t)
        pos = applyOrbitRotation(p, pos, t)
        pos = pos.add(
            compOpDelta(p, TrackPr.POS_X, t),
            compOpDelta(p, TrackPr.POS_Y, t),
            compOpDelta(p, TrackPr.POS_Z, t),
        )
        return pos
    }

    private fun setComponentValueAt(p: AnimParticle, pr: TrackPr, t: Double): Double {
        var v = baseComponent(p, pr)
        val tr = findSetTrackFor(p.id, pr)
        if (tr != null && tr.keyframes.isNotEmpty()) v = trackValueAt(tr, t, v)
        return v
    }

    private fun applyParticleOrbit(p: AnimParticle, value: Vec3, t: Double): Vec3 {
        val fx = particleFunction(p.id)
        if (fx != null) return value // 派生粒子没有独立公转轨道
        val rot = rotVectorAt(p.id, t)
        if (rot[0] == 0.0 && rot[1] == 0.0 && rot[2] == 0.0) return value
        return rotateAround(value, orbitCenterAt(p.id, t), rot)
    }

    private fun applySelfRotation(p: AnimParticle, value: Vec3, t: Double): Vec3 {
        val gs = particleGroupIndex[p.id]
        if (gs != null) {
            for (okey in gs) {
                val spin = spinVectorAt(okey, t)
                if (spin[0] == 0.0 && spin[1] == 0.0 && spin[2] == 0.0) continue
                val pivot = groupCentroidCache[okey] ?: groupCentroid(okey)
                return if (ownerSpinLocal(okey)) rotateAroundLocal(value, pivot, spin) else rotateAround(value, pivot, spin)
            }
        }
        val fx = particleFunction(p.id)
        if (fx != null) {
            val spin = spinVectorAt("f:" + fx.id, t)
            if (spin[0] == 0.0 && spin[1] == 0.0 && spin[2] == 0.0) return value
            val pivot = Vec3(fx.center[0], fx.center[1], fx.center[2])
            return if (fx.spinLocal) rotateAroundLocal(value, pivot, spin) else rotateAround(value, pivot, spin)
        }
        return value
    }

    private fun applyOrbitRotation(p: AnimParticle, value: Vec3, t: Double): Vec3 {
        val gs = particleGroupIndex[p.id]
        if (gs != null) {
            for (okey in gs) {
                val rot = rotVectorAt(okey, t)
                if (rot[0] == 0.0 && rot[1] == 0.0 && rot[2] == 0.0) continue
                val pivot = orbitCenterAt(okey, t)
                if (ownerRotLocal(okey)) {
                    val spin = spinVectorAt(okey, t)
                    return rotateAroundLocalOrbit(value, pivot, rot, spin, ownerSpinLocal(okey))
                }
                return rotateAround(value, pivot, rot)
            }
        }
        val fx = particleFunction(p.id)
        if (fx != null) {
            val rot = rotVectorAt("f:" + fx.id, t)
            if (rot[0] == 0.0 && rot[1] == 0.0 && rot[2] == 0.0) return value
            val pivot = orbitCenterAt("f:" + fx.id, t)
            if (fx.rotLocal) {
                val spin = spinVectorAt("f:" + fx.id, t)
                return rotateAroundLocalOrbit(value, pivot, rot, spin, fx.spinLocal)
            }
            return rotateAround(value, pivot, rot)
        }
        return value
    }

    /** owner 整体缩放：作用于成员相对 owner 质心的偏移，而非粒子大小。 */
    private fun applyGroupScale(p: AnimParticle, value: Vec3, t: Double): Vec3 {
        val gs = particleGroupIndex[p.id] ?: return value
        for (okey in gs) {
            val s = groupScaleAt(okey, t)
            if (s[0] == 1.0 && s[1] == 1.0 && s[2] == 1.0) continue
            val pivot = groupCentroidCache[okey] ?: groupCentroid(okey)
            return Vec3(
                pivot.x + (value.x - pivot.x) * s[0],
                pivot.y + (value.y - pivot.y) * s[1],
                pivot.z + (value.z - pivot.z) * s[2],
            )
        }
        return value
    }

    private fun groupScaleAt(okey: String, t: Double): DoubleArray =
        doubleArrayOf(
            groupScaleComponent(okey, TrackPr.SCL_X, t),
            groupScaleComponent(okey, TrackPr.SCL_Y, t),
            groupScaleComponent(okey, TrackPr.SCL_Z, t),
        )

    private fun groupScaleComponent(okey: String, pr: TrackPr, t: Double): Double {
        val tr = findTrackByPr(pr, okey) ?: return 1.0
        if (tr.keyframes.isEmpty()) return 1.0
        return if (tr.mode == AnimTrack.Mode.OP) 1.0 + trackValueAt(tr, t, 0.0)
        else trackValueAt(tr, t, 1.0)
    }

    private fun groupCentroid(okey: String): Vec3 {
        val byId = HashMap<String, AnimParticle>(animation.particles.size)
        for (p in animation.particles) byId[p.id] = p
        return centroidOf(okey, byId) ?: Vec3.ZERO
    }

    private fun particleColor(p: AnimParticle, t: Double): Color {
        return Color.of(
            componentValueAt(p, TrackPr.COL_R, t).toFloat(),
            componentValueAt(p, TrackPr.COL_G, t).toFloat(),
            componentValueAt(p, TrackPr.COL_B, t).toFloat(),
            componentValueAt(p, TrackPr.COL_A, t).toFloat(),
        )
    }

    private fun particleScaleInto(p: AnimParticle, t: Double, out: FloatArray) {
        // 粒子缩放只有 X/Y（四边形两条边长由 sx/sy 决定）；组 scl 不再影响粒子大小，改为位置级整体缩放。
        // 就地写进状态里那份数组：这里是每帧每颗粒子都跑的热路径，不能每次新建
        out[0] = ownScaleComponent(p, TrackPr.SCL_X, t).toFloat().coerceAtLeast(0.01f)
        out[1] = ownScaleComponent(p, TrackPr.SCL_Y, t).toFloat().coerceAtLeast(0.01f)
        out[2] = 1f
    }

    private fun ownScaleComponent(p: AnimParticle, pr: TrackPr, t: Double): Double {
        var v = baseComponent(p, pr)
        val tr = findTrackByPr(pr, p.id)
        if (tr != null && tr.mode != AnimTrack.Mode.OP && tr.keyframes.isNotEmpty()) v = trackValueAt(tr, t, v)
        return v
    }

    /**
     * 函数对象整体缩放（三分量）：代码块输出的尺寸 [base]（标量写法是 [s, s, 1]，vec2 的 z 也已是 1），
     * 再叠加作用于 `f:fxId` 的 `scl.x/y/z` 轨道（存在则覆盖对应分量，与编辑器 currentVisualDerived 语义一致）。
     */
    private fun fxScaleInto(fxId: String, base: DoubleArray, t: Double, out: FloatArray) {
        // 就地写进状态里那份数组（原因同 particleScaleInto）
        out[0] = scalarAt(TrackPr.SCL_X, "f:" + fxId, t, finiteOrOne(base[0])).toFloat().coerceAtLeast(0.01f)
        out[1] = scalarAt(TrackPr.SCL_Y, "f:" + fxId, t, finiteOrOne(base[1])).toFloat().coerceAtLeast(0.01f)
        out[2] = scalarAt(TrackPr.SCL_Z, "f:" + fxId, t, finiteOrOne(base[2])).toFloat().coerceAtLeast(0.01f)
    }

    /** 脚本给的尺寸可能是 NaN/Inf（表达式算爆了）：按 1 兜底，别把坏尺寸传进渲染。 */
    private fun finiteOrOne(v: Double): Double = if (v.isFinite()) v else 1.0

    /**
     * 解析粒子最终 UV（继承覆盖：p.uv > 组 guv[gname] > 函数对象 fx.uv）。
     * [ownUv] 为该对象自身的 UV（粒子为 p.uv，派生粒子为 fx.uv），组级在内部按成员关系补充。
     */
    private fun resolveUV(stateId: String, ownUv: UvData?): UvData? {
        if (ownUv != null && ownUv.texture != null) return ownUv
        for (okey in particleGroupIndex[stateId] ?: emptySet()) {
            if (!okey.startsWith("g:")) continue // 文字对象无组级 UV
            animation.groupUV[okey.removePrefix("g:")]?.let { if (it.texture != null) return it }
        }
        // 派生粒子：函数对象级 uv 已在 ownUv 传入；此处兜底再查一次（按 id 反查 fx）
        val fx = particleFunction(stateId)
        if (fx?.uv != null && fx.uv.texture != null) return fx.uv
        return ownUv
    }

    private fun rotateAround(p: Vec3, pivot: Vec3, rot: DoubleArray): Vec3 {
        var r = p.subtract(pivot)
        if (rot[0] != 0.0) r = r.rotateAround(Vec3(1.0, 0.0, 0.0), Math.toRadians(rot[0]))
        if (rot[1] != 0.0) r = r.rotateAround(Vec3(0.0, 1.0, 0.0), Math.toRadians(rot[1]))
        if (rot[2] != 0.0) r = r.rotateAround(Vec3(0.0, 0.0, 1.0), Math.toRadians(rot[2]))
        return pivot.add(r)
    }

    /** 局部自转：intrinsic XYZ（先绕局部 X，再绕已旋转的局部 Y，再绕已旋转的局部 Z）。 */
    private fun rotateAroundLocal(p: Vec3, pivot: Vec3, rot: DoubleArray): Vec3 {
        var r = p.subtract(pivot)
        val rx = Math.toRadians(rot[0])
        val ry = Math.toRadians(rot[1])
        val rz = Math.toRadians(rot[2])
        if (rot[0] != 0.0) r = r.rotateAround(Vec3(1.0, 0.0, 0.0), rx)
        var yAxis = Vec3(0.0, 1.0, 0.0)
        if (rot[0] != 0.0) yAxis = yAxis.rotateAround(Vec3(1.0, 0.0, 0.0), rx)
        if (rot[1] != 0.0) r = r.rotateAround(yAxis, ry)
        var zAxis = Vec3(0.0, 0.0, 1.0)
        if (rot[0] != 0.0) zAxis = zAxis.rotateAround(Vec3(1.0, 0.0, 0.0), rx)
        if (rot[1] != 0.0) zAxis = zAxis.rotateAround(yAxis, ry)
        if (rot[2] != 0.0) r = r.rotateAround(zAxis, rz)
        return pivot.add(r)
    }

    /** 把向量按自转姿态旋转（绕原点；local = intrinsic XYZ）。 */
    private fun forwardSpin(v: Vec3, spin: DoubleArray, local: Boolean): Vec3 =
        if (local) rotateAroundLocal(v, Vec3.ZERO, spin) else rotateAround(v, Vec3.ZERO, spin)

    /** 把向量按自转姿态的逆旋转（绕原点；local = intrinsic XYZ）。 */
    private fun inverseSpin(v: Vec3, spin: DoubleArray, local: Boolean): Vec3 {
        val rx = Math.toRadians(spin[0])
        val ry = Math.toRadians(spin[1])
        val rz = Math.toRadians(spin[2])
        var r = v
        if (local) {
            if (spin[0] != 0.0) r = r.rotateAround(Vec3(1.0, 0.0, 0.0), -rx)
            if (spin[1] != 0.0) r = r.rotateAround(Vec3(0.0, 1.0, 0.0), -ry)
            if (spin[2] != 0.0) r = r.rotateAround(Vec3(0.0, 0.0, 1.0), -rz)
        } else {
            if (spin[2] != 0.0) r = r.rotateAround(Vec3(0.0, 0.0, 1.0), -rz)
            if (spin[1] != 0.0) r = r.rotateAround(Vec3(0.0, 1.0, 0.0), -ry)
            if (spin[0] != 0.0) r = r.rotateAround(Vec3(1.0, 0.0, 0.0), -rx)
        }
        return r
    }

    /** 局部公转：公转轴跟随对象自转后的姿态。M = M_spin · M_localOrbit · M_spinᵀ。 */
    private fun rotateAroundLocalOrbit(p: Vec3, pivot: Vec3, rot: DoubleArray, spin: DoubleArray, spinLocal: Boolean): Vec3 {
        val r = p.subtract(pivot)
        val local = inverseSpin(r, spin, spinLocal)
        val rotated = rotateAroundLocal(local, Vec3.ZERO, rot)
        return pivot.add(forwardSpin(rotated, spin, spinLocal))
    }

    }

/** 深拷贝脚本值（global / 粒子自定义字段）：数组递归拷贝；其余值类型（标量/向量/矩阵/函数）视为不可变。 */
private fun deepCopyScriptValue(v: Any?, depth: Int = 0): Any? {
    if (depth > 128) throw ScriptException("value nesting too deep")
    return when (v) {
        is MutableList<*> -> {
            val out = ArrayList<Any?>(v.size)
            for (x in v) out.add(deepCopyScriptValue(x, depth + 1))
            out
        }
        is Map<*, *> -> {
            val out = HashMap<String, Any?>()
            for ((k, x) in v) out[k as String] = deepCopyScriptValue(x, depth + 1)
            out
        }
        else -> v
    }
}
