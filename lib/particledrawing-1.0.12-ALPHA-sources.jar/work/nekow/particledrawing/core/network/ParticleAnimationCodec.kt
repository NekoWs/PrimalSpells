package work.nekow.particledrawing.core.network

import net.minecraft.network.FriendlyByteBuf
import net.minecraft.world.phys.Vec3
import work.nekow.particledrawing.animation.AnimCamera
import work.nekow.particledrawing.animation.AnimKeyframe
import work.nekow.particledrawing.animation.AnimParticle
import work.nekow.particledrawing.animation.AnimTrack
import work.nekow.particledrawing.animation.AudioAsset
import work.nekow.particledrawing.animation.Entrance
import work.nekow.particledrawing.animation.FunctionObject
import work.nekow.particledrawing.animation.FunctionVar
import work.nekow.particledrawing.animation.ParticleAnimation
import work.nekow.particledrawing.animation.TextChar
import work.nekow.particledrawing.animation.TextObject
import work.nekow.particledrawing.animation.TrackPr
import work.nekow.particledrawing.animation.UvData
import work.nekow.particledrawing.animation.script.Keyframe
import work.nekow.particledrawing.api.Color
import work.nekow.particledrawing.core.easing.EasingType

/**
 * 代码生成 [ParticleAnimation] 的网络编解码（手写二进制，与 .pdrawc 无关，不签名）。
 *
 * 布局：version varint + loop + particles + tracks + groups + functions + textures +
 * groupUV + texData + groupSpinSpace + groupRotSpace + cameras + texts + audioAssets。
 * 客户端按同一版本号解析；版本不符抛异常拒绝播放。
 */
internal object ParticleAnimationCodec {

    const val VERSION = 9   // v9：音频资产新增 vol/speed/pan/fadeIn/fadeOut（与 .pdrawc v18 对应）

    fun write(buf: FriendlyByteBuf, anim: ParticleAnimation) {
        buf.writeVarInt(VERSION)
        buf.writeBoolean(anim.loop)

        buf.writeVarInt(anim.particles.size)
        for (p in anim.particles) writeParticle(buf, p)

        buf.writeVarInt(anim.tracks.size)
        for (tr in anim.tracks) writeTrack(buf, tr)

        buf.writeVarInt(anim.groups.size)
        for ((name, members) in anim.groups) {
            buf.writeUtf(name)
            buf.writeVarInt(members.size)
            for (id in members) buf.writeUtf(id)
        }

        buf.writeVarInt(anim.functions.size)
        for (fx in anim.functions) writeFunction(buf, fx)

        buf.writeVarInt(anim.textures.size)
        for (name in anim.textures) buf.writeUtf(name)

        buf.writeVarInt(anim.groupUV.size)
        for ((name, uv) in anim.groupUV) {
            buf.writeUtf(name)
            writeUV(buf, uv)
        }

        buf.writeVarInt(anim.texData.size)
        for ((name, bytes) in anim.texData) {
            buf.writeUtf(name)
            buf.writeVarInt(bytes.size)
            buf.writeBytes(bytes)
        }

        writeBoolMap(buf, anim.groupSpinSpace)
        writeBoolMap(buf, anim.groupRotSpace)

        buf.writeVarInt(anim.cameras.size)
        for (cam in anim.cameras) writeCamera(buf, cam)

        buf.writeVarInt(anim.texts.size)
        for (tx in anim.texts) writeText(buf, tx)

        buf.writeVarInt(anim.audioAssets.size)
        for (a in anim.audioAssets) writeAudio(buf, a)
    }

    fun read(buf: FriendlyByteBuf): ParticleAnimation {
        val version = buf.readVarInt()
        if (version != VERSION) throw IllegalArgumentException("ParticleAnimation 载荷版本不支持: $version")

        val loop = buf.readBoolean()

        val particleCount = buf.readVarInt()
        val particles = ArrayList<AnimParticle>(particleCount)
        repeat(particleCount) { particles.add(readParticle(buf)) }

        val trackCount = buf.readVarInt()
        val tracks = ArrayList<AnimTrack>(trackCount)
        repeat(trackCount) { tracks.add(readTrack(buf)) }

        val groupCount = buf.readVarInt()
        val groups = LinkedHashMap<String, List<String>>(groupCount)
        repeat(groupCount) {
            val name = buf.readUtf()
            val memberCount = buf.readVarInt()
            val members = ArrayList<String>(memberCount)
            repeat(memberCount) { members.add(buf.readUtf()) }
            groups[name] = members
        }

        val fxCount = buf.readVarInt()
        val functions = ArrayList<FunctionObject>(fxCount)
        repeat(fxCount) { functions.add(readFunction(buf)) }

        val texCount = buf.readVarInt()
        val textures = ArrayList<String>(texCount)
        repeat(texCount) { textures.add(buf.readUtf()) }

        val groupUVCount = buf.readVarInt()
        val groupUV = LinkedHashMap<String, UvData>(groupUVCount)
        repeat(groupUVCount) { groupUV[buf.readUtf()] = readUV(buf) }

        val texDataCount = buf.readVarInt()
        val texData = LinkedHashMap<String, ByteArray>(texDataCount)
        repeat(texDataCount) {
            val name = buf.readUtf()
            val len = buf.readVarInt()
            val bytes = ByteArray(len)
            buf.readBytes(bytes)
            texData[name] = bytes
        }

        val groupSpinSpace = readBoolMap(buf)
        val groupRotSpace = readBoolMap(buf)

        val camCount = buf.readVarInt()
        val cameras = ArrayList<AnimCamera>(camCount)
        repeat(camCount) { cameras.add(readCamera(buf)) }

        val textCount = buf.readVarInt()
        val texts = ArrayList<TextObject>(textCount)
        repeat(textCount) { texts.add(readText(buf)) }

        val audioCount = buf.readVarInt()
        val audioAssets = ArrayList<AudioAsset>(audioCount)
        repeat(audioCount) { audioAssets.add(readAudio(buf)) }

        return ParticleAnimation(
            loop, particles, tracks, groups, functions,
            textures, groupUV, texData, groupSpinSpace, groupRotSpace, cameras, texts, audioAssets,
        )
    }

    private fun writeParticle(buf: FriendlyByteBuf, p: AnimParticle) {
        buf.writeUtf(p.id)
        buf.writeFloat(p.color.r)
        buf.writeFloat(p.color.g)
        buf.writeFloat(p.color.b)
        buf.writeFloat(p.color.a)
        buf.writeFloat(p.scale[0])
        buf.writeFloat(p.scale[1])
        buf.writeFloat(p.scale[2])
        buf.writeBoolean(p.glowing)
        buf.writeByte(p.lightLevel.coerceIn(0, 255))
        buf.writeDouble(p.pos.x)
        buf.writeDouble(p.pos.y)
        buf.writeDouble(p.pos.z)
        buf.writeDouble(p.vel.x)
        buf.writeDouble(p.vel.y)
        buf.writeDouble(p.vel.z)
        writeNullableUV(buf, p.uv)
        buf.writeVarInt(p.st)
        writeNullableEnt(buf, p.ent)
        buf.writeVarInt(p.life)
        buf.writeBoolean(p.billboard)   // v8
        buf.writeBoolean(p.spinLocal)   // v8
    }

    private fun readParticle(buf: FriendlyByteBuf): AnimParticle {
        val id = buf.readUtf()
        val color = Color.of(buf.readFloat(), buf.readFloat(), buf.readFloat(), buf.readFloat())
        val scale = floatArrayOf(buf.readFloat(), buf.readFloat(), buf.readFloat())
        val glowing = buf.readBoolean()
        val lightLevel = buf.readByte().toInt()
        val pos = Vec3(buf.readDouble(), buf.readDouble(), buf.readDouble())
        val vel = Vec3(buf.readDouble(), buf.readDouble(), buf.readDouble())
        val uv = readNullableUV(buf)
        val st = buf.readVarInt()
        val ent = readNullableEnt(buf)
        val life = buf.readVarInt()
        val billboard = buf.readBoolean()   // v8
        val spinLocal = buf.readBoolean()   // v8
        return AnimParticle(id, color, scale, glowing, lightLevel, pos, vel, uv, st, ent, life, billboard, spinLocal)
    }

    private fun writeTrack(buf: FriendlyByteBuf, tr: AnimTrack) {
        buf.writeByte(tr.pr.ordinal)
        buf.writeByte(if (tr.mode == AnimTrack.Mode.OP) 1 else 0)
        buf.writeVarInt(tr.ids.size)
        for (id in tr.ids) buf.writeUtf(id)
        buf.writeVarInt(tr.keyframes.size)
        for (kf in tr.keyframes) {
            buf.writeVarInt(kf.ms)
            buf.writeDouble(kf.value)
            writeEasing(buf, kf.easing)
        }
    }

    private fun readTrack(buf: FriendlyByteBuf): AnimTrack {
        val prOrdinal = buf.readByte().toInt()
        val pr = TrackPr.fromOrdinal(prOrdinal)
            ?: throw IllegalArgumentException("未知 pr 枚举序号: $prOrdinal")
        val mode = if (buf.readByte().toInt() == 1) AnimTrack.Mode.OP else AnimTrack.Mode.SET
        val idCount = buf.readVarInt()
        val ids = ArrayList<String>(idCount)
        repeat(idCount) { ids.add(buf.readUtf()) }
        val kfCount = buf.readVarInt()
        val keyframes = ArrayList<AnimKeyframe>(kfCount)
        repeat(kfCount) {
            keyframes.add(AnimKeyframe(buf.readVarInt(), buf.readDouble(), readEasing(buf)))
        }
        return AnimTrack(pr, ids, keyframes, mode)
    }

    private fun writeFunction(buf: FriendlyByteBuf, fx: FunctionObject) {
        buf.writeUtf(fx.id)
        buf.writeUtf(fx.name)
        buf.writeDouble(fx.center[0])
        buf.writeDouble(fx.center[1])
        buf.writeDouble(fx.center[2])
        buf.writeUtf(fx.source)
        buf.writeVarInt(fx.seed)
        buf.writeVarInt(fx.vars.size)
        for ((name, v) in fx.vars) {
            buf.writeUtf(name)
            buf.writeDouble(v.base)
            buf.writeVarInt(v.kf.size)
            for (kf in v.kf) {
                buf.writeDouble(kf.ms)
                buf.writeDouble(kf.value)
                writeEasing(buf, kf.easing)
            }
        }
        buf.writeVarInt(fx.duration)
        writeNullableUV(buf, fx.uv)
        buf.writeVarInt(fx.st)
        writeNullableEnt(buf, fx.ent)
        buf.writeBoolean(fx.fastMath)
        buf.writeBoolean(fx.spinLocal)
        buf.writeBoolean(fx.rotLocal)
        buf.writeBoolean(fx.frameSync)
        buf.writeBoolean(fx.additive)
    }

    private fun readFunction(buf: FriendlyByteBuf): FunctionObject {
        val id = buf.readUtf()
        val name = buf.readUtf()
        val center = doubleArrayOf(buf.readDouble(), buf.readDouble(), buf.readDouble())
        val source = buf.readUtf()
        val seed = buf.readVarInt()
        val varCount = buf.readVarInt()
        val vars = LinkedHashMap<String, FunctionVar>(varCount)
        repeat(varCount) {
            val varName = buf.readUtf()
            val base = buf.readDouble()
            val kfCount = buf.readVarInt()
            val kf = ArrayList<Keyframe>(kfCount)
            repeat(kfCount) {
                kf.add(Keyframe(buf.readDouble(), buf.readDouble(), readEasing(buf)))
            }
            vars[varName] = FunctionVar(base, kf)
        }
        val duration = buf.readVarInt()
        val uv = readNullableUV(buf)
        val st = buf.readVarInt()
        val ent = readNullableEnt(buf)
        val fastMath = buf.readBoolean()
        val spinLocal = buf.readBoolean()
        val rotLocal = buf.readBoolean()
        val frameSync = buf.readBoolean()
        val additive = buf.readBoolean()
        return FunctionObject(id, name, center, source, seed, vars, duration, uv, st, ent, fastMath, spinLocal, rotLocal, frameSync, additive)
    }

    private fun writeCamera(buf: FriendlyByteBuf, cam: AnimCamera) {
        buf.writeUtf(cam.id)
        buf.writeUtf(cam.name)
        buf.writeDouble(cam.pos[0])
        buf.writeDouble(cam.pos[1])
        buf.writeDouble(cam.pos[2])
        buf.writeDouble(cam.target[0])
        buf.writeDouble(cam.target[1])
        buf.writeDouble(cam.target[2])
        buf.writeDouble(cam.roll)
        buf.writeDouble(cam.fov)
        buf.writeBoolean(cam.rotLocal)
    }

    private fun readCamera(buf: FriendlyByteBuf): AnimCamera {
        val id = buf.readUtf()
        val name = buf.readUtf()
        val pos = doubleArrayOf(buf.readDouble(), buf.readDouble(), buf.readDouble())
        val target = doubleArrayOf(buf.readDouble(), buf.readDouble(), buf.readDouble())
        val roll = buf.readDouble()
        val fov = buf.readDouble()
        val rotLocal = buf.readBoolean()
        return AnimCamera(id, name, pos, target, roll, fov, rotLocal)
    }

    private fun writeText(buf: FriendlyByteBuf, tx: TextObject) {
        buf.writeUtf(tx.id)
        buf.writeUtf(tx.name)
        buf.writeUtf(tx.text)
        buf.writeUtf(tx.font)
        buf.writeVarInt(tx.fontSize)
        buf.writeUtf(tx.weight)
        buf.writeBoolean(tx.italic)
        buf.writeFloat(tx.color.r)
        buf.writeFloat(tx.color.g)
        buf.writeFloat(tx.color.b)
        buf.writeFloat(tx.color.a)
        writeNullableColor(buf, tx.strokeColor)
        buf.writeVarInt(tx.strokeWidth)
        buf.writeUtf(tx.align)
        buf.writeDouble(tx.lineHeight)
        buf.writeDouble(tx.letterSpacing)
        buf.writeVarInt(tx.st)
        buf.writeVarInt(tx.life)
        buf.writeBoolean(tx.spinLocal)   // v8
        buf.writeBoolean(tx.rotLocal)    // v8
        buf.writeBoolean(tx.billboard)   // v8
        buf.writeVarInt(tx.chars.size)
        for (c in tx.chars) {
            buf.writeVarInt(c.index)
            buf.writeVarInt(c.code)
            buf.writeDouble(c.pos.x)
            buf.writeDouble(c.pos.y)
            buf.writeDouble(c.pos.z)
            buf.writeDouble(c.size[0])
            buf.writeDouble(c.size[1])
            buf.writeVarInt(c.particles.size)
            for (id in c.particles) buf.writeUtf(id)
        }
    }

    private fun readText(buf: FriendlyByteBuf): TextObject {
        val id = buf.readUtf()
        val name = buf.readUtf()
        val text = buf.readUtf()
        val font = buf.readUtf()
        val fontSize = buf.readVarInt()
        val weight = buf.readUtf()
        val italic = buf.readBoolean()
        val color = Color.of(buf.readFloat(), buf.readFloat(), buf.readFloat(), buf.readFloat())
        val strokeColor = readNullableColor(buf)
        val strokeWidth = buf.readVarInt()
        val align = buf.readUtf()
        val lineHeight = buf.readDouble()
        val letterSpacing = buf.readDouble()
        val st = buf.readVarInt()
        val life = buf.readVarInt()
        val spinLocal = buf.readBoolean()   // v8
        val rotLocal = buf.readBoolean()    // v8
        val billboard = buf.readBoolean()   // v8
        val charCount = buf.readVarInt()
        val chars = ArrayList<TextChar>(charCount)
        repeat(charCount) {
            val index = buf.readVarInt()
            val code = buf.readVarInt()
            val pos = Vec3(buf.readDouble(), buf.readDouble(), buf.readDouble())
            val size = doubleArrayOf(buf.readDouble(), buf.readDouble())
            val pn = buf.readVarInt()
            val ids = ArrayList<String>(pn)
            repeat(pn) { ids.add(buf.readUtf()) }
            chars.add(TextChar(index, code, pos, size, ids))
        }
        return TextObject(id, name, text, font, fontSize, weight, italic, color, strokeColor, strokeWidth, align, lineHeight, letterSpacing, st, life, chars, spinLocal, rotLocal, billboard)
    }

    private fun writeNullableColor(buf: FriendlyByteBuf, c: Color?) {
        buf.writeBoolean(c != null)
        if (c != null) {
            buf.writeFloat(c.r)
            buf.writeFloat(c.g)
            buf.writeFloat(c.b)
            buf.writeFloat(c.a)
        }
    }

    private fun readNullableColor(buf: FriendlyByteBuf): Color? =
        if (buf.readBoolean()) Color.of(buf.readFloat(), buf.readFloat(), buf.readFloat(), buf.readFloat()) else null

    private fun writeAudio(buf: FriendlyByteBuf, a: AudioAsset) {
        buf.writeUtf(a.id)
        buf.writeUtf(a.name)
        buf.writeVarInt(a.fmt)
        buf.writeVarInt(a.data.size)
        buf.writeBytes(a.data)
        buf.writeVarInt(a.st)
        buf.writeVarInt(a.durMs)
        buf.writeDouble(a.vol)      // v9
        buf.writeDouble(a.speed)    // v9
        buf.writeDouble(a.pan)      // v9
        buf.writeVarInt(a.fadeIn)   // v9
        buf.writeVarInt(a.fadeOut)  // v9
        buf.writeVarInt(a.hopCount)
        buf.writeDouble(a.bpm)
        buf.writeDouble(a.beatOffsetMs)
        buf.writeDouble(a.onsetMax)
        buf.writeVarInt(a.beats.size)
        for (b in a.beats) buf.writeVarInt(b)
        buf.writeVarInt(a.rms.size)
        for (v in a.rms) buf.writeShort(v.toInt())
        buf.writeVarInt(a.peak.size)
        for (v in a.peak) buf.writeShort(v.toInt())
        buf.writeVarInt(a.centroid.size)
        for (v in a.centroid) buf.writeShort(v.toInt())
        buf.writeVarInt(a.onset.size)
        buf.writeBytes(a.onset)
        buf.writeVarInt(a.rolloff.size)
        buf.writeBytes(a.rolloff)
        buf.writeVarInt(a.bands.size)
        buf.writeBytes(a.bands)
    }

    private fun readAudio(buf: FriendlyByteBuf): AudioAsset {
        val id = buf.readUtf()
        val name = buf.readUtf()
        val fmt = buf.readVarInt()
        val dataLen = buf.readVarInt()
        val data = ByteArray(dataLen)
        buf.readBytes(data)
        val st = buf.readVarInt()
        val durMs = buf.readVarInt()
        val vol = buf.readDouble()      // v9
        val speed = buf.readDouble()    // v9
        val pan = buf.readDouble()      // v9
        val fadeIn = buf.readVarInt()   // v9
        val fadeOut = buf.readVarInt()  // v9
        val hopCount = buf.readVarInt()
        val bpm = buf.readDouble()
        val beatOffsetMs = buf.readDouble()
        val onsetMax = buf.readDouble()
        val beatCount = buf.readVarInt()
        val beats = ArrayList<Int>(beatCount)
        repeat(beatCount) { beats.add(buf.readVarInt()) }
        val rms = ShortArray(buf.readVarInt()) { buf.readShort() }
        val peak = ShortArray(buf.readVarInt()) { buf.readShort() }
        val centroid = ShortArray(buf.readVarInt()) { buf.readShort() }
        val onset = ByteArray(buf.readVarInt()); buf.readBytes(onset)
        val rolloff = ByteArray(buf.readVarInt()); buf.readBytes(rolloff)
        val bands = ByteArray(buf.readVarInt()); buf.readBytes(bands)
        return AudioAsset(
            id, name, fmt, data, st, durMs, hopCount, bpm, beatOffsetMs, onsetMax, beats,
            rms, peak, centroid, onset, rolloff, bands,
            vol = vol, speed = speed, pan = pan, fadeIn = fadeIn, fadeOut = fadeOut,
        )
    }

    private fun writeUV(buf: FriendlyByteBuf, uv: UvData) {
        writeNullableString(buf, uv.texture)
        buf.writeByte(uv.mode.ordinal)
        buf.writeVarInt(uv.texSize[0])
        buf.writeVarInt(uv.texSize[1])
        buf.writeVarInt(uv.uvStart[0])
        buf.writeVarInt(uv.uvStart[1])
        buf.writeVarInt(uv.uvSize[0])
        buf.writeVarInt(uv.uvSize[1])
        buf.writeVarInt(uv.uvStep[0])
        buf.writeVarInt(uv.uvStep[1])
        buf.writeFloat(uv.fps)
        buf.writeVarInt(uv.maxFrame)
        buf.writeBoolean(uv.loop)
        // v2：loop 后 1 字节 exprFlags，按位序写存在的表达式字符串（null=用数值字段）
        var exprFlags = 0
        if (uv.uvStartExpr[0] != null) exprFlags = exprFlags or (1 shl 0)
        if (uv.uvStartExpr[1] != null) exprFlags = exprFlags or (1 shl 1)
        if (uv.uvSizeExpr[0] != null) exprFlags = exprFlags or (1 shl 2)
        if (uv.uvSizeExpr[1] != null) exprFlags = exprFlags or (1 shl 3)
        if (uv.uvStepExpr[0] != null) exprFlags = exprFlags or (1 shl 4)
        if (uv.uvStepExpr[1] != null) exprFlags = exprFlags or (1 shl 5)
        if (uv.fpsExpr != null) exprFlags = exprFlags or (1 shl 6)
        if (uv.maxFrameExpr != null) exprFlags = exprFlags or (1 shl 7)
        buf.writeByte(exprFlags)
        uv.uvStartExpr[0]?.let { buf.writeUtf(it) }
        uv.uvStartExpr[1]?.let { buf.writeUtf(it) }
        uv.uvSizeExpr[0]?.let { buf.writeUtf(it) }
        uv.uvSizeExpr[1]?.let { buf.writeUtf(it) }
        uv.uvStepExpr[0]?.let { buf.writeUtf(it) }
        uv.uvStepExpr[1]?.let { buf.writeUtf(it) }
        uv.fpsExpr?.let { buf.writeUtf(it) }
        uv.maxFrameExpr?.let { buf.writeUtf(it) }
    }

    private fun readUV(buf: FriendlyByteBuf): UvData {
        val texture = readNullableString(buf)
        val mode = UvData.Mode.entries[buf.readByte().toInt()]
        val texSize = intArrayOf(buf.readVarInt(), buf.readVarInt())
        val uvStart = intArrayOf(buf.readVarInt(), buf.readVarInt())
        val uvSize = intArrayOf(buf.readVarInt(), buf.readVarInt())
        val uvStep = intArrayOf(buf.readVarInt(), buf.readVarInt())
        val fps = buf.readFloat()
        val maxFrame = buf.readVarInt()
        val loop = buf.readBoolean()
        val exprFlags = buf.readByte().toInt()
        val uvStartExpr = arrayOfNulls<String>(2)
        val uvSizeExpr = arrayOfNulls<String>(2)
        val uvStepExpr = arrayOfNulls<String>(2)
        if (exprFlags and (1 shl 0) != 0) uvStartExpr[0] = buf.readUtf()
        if (exprFlags and (1 shl 1) != 0) uvStartExpr[1] = buf.readUtf()
        if (exprFlags and (1 shl 2) != 0) uvSizeExpr[0] = buf.readUtf()
        if (exprFlags and (1 shl 3) != 0) uvSizeExpr[1] = buf.readUtf()
        if (exprFlags and (1 shl 4) != 0) uvStepExpr[0] = buf.readUtf()
        if (exprFlags and (1 shl 5) != 0) uvStepExpr[1] = buf.readUtf()
        val fpsExpr = if (exprFlags and (1 shl 6) != 0) buf.readUtf() else null
        val maxFrameExpr = if (exprFlags and (1 shl 7) != 0) buf.readUtf() else null
        return UvData(
            texture, mode, texSize, uvStart, uvSize, uvStep, fps, maxFrame, loop,
            uvStartExpr, uvSizeExpr, uvStepExpr, fpsExpr, maxFrameExpr,
        )
    }

    private fun writeNullableUV(buf: FriendlyByteBuf, uv: UvData?) {
        buf.writeBoolean(uv != null)
        if (uv != null) writeUV(buf, uv)
    }

    private fun readNullableUV(buf: FriendlyByteBuf): UvData? =
        if (buf.readBoolean()) readUV(buf) else null

    private fun writeNullableEnt(buf: FriendlyByteBuf, ent: Entrance?) {
        buf.writeBoolean(ent != null)
        if (ent != null) {
            buf.writeUtf(ent.preset)
            buf.writeVarInt(ent.dur)
        }
    }

    private fun readNullableEnt(buf: FriendlyByteBuf): Entrance? =
        if (buf.readBoolean()) Entrance(buf.readUtf(), buf.readVarInt()) else null

    private fun writeEasing(buf: FriendlyByteBuf, easing: EasingType) {
        when {
            easing.isStep() -> buf.writeByte(2)
            easing.isPreset() -> {
                buf.writeByte(0)
                buf.writeVarInt(easing.ordinal)
            }
            else -> {
                buf.writeByte(1)
                buf.writeDouble(easing.curve.x1)
                buf.writeDouble(easing.curve.y1)
                buf.writeDouble(easing.curve.x2)
                buf.writeDouble(easing.curve.y2)
            }
        }
    }

    private fun readEasing(buf: FriendlyByteBuf): EasingType = when (buf.readByte().toInt()) {
        0 -> {
            val idx = buf.readVarInt()
            if (idx !in EasingType.PRESETS.indices) throw IllegalArgumentException("缓动预设越界: $idx")
            EasingType.PRESETS[idx]
        }
        1 -> EasingType.custom(buf.readDouble(), buf.readDouble(), buf.readDouble(), buf.readDouble())
        2 -> EasingType.NONE
        else -> throw IllegalArgumentException("未知缓动类型")
    }

    private fun writeBoolMap(buf: FriendlyByteBuf, map: Map<String, Boolean>) {
        buf.writeVarInt(map.size)
        for ((k, v) in map) {
            buf.writeUtf(k)
            buf.writeBoolean(v)
        }
    }

    private fun readBoolMap(buf: FriendlyByteBuf): Map<String, Boolean> {
        val n = buf.readVarInt()
        val out = LinkedHashMap<String, Boolean>(n)
        repeat(n) { out[buf.readUtf()] = buf.readBoolean() }
        return out
    }

    private fun writeNullableString(buf: FriendlyByteBuf, value: String?) {
        buf.writeBoolean(value != null)
        if (value != null) buf.writeUtf(value)
    }

    private fun readNullableString(buf: FriendlyByteBuf): String? =
        if (buf.readBoolean()) buf.readUtf() else null
}