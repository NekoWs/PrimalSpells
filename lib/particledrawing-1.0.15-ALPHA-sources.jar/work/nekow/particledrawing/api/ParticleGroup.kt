package work.nekow.particledrawing.api

import net.minecraft.world.phys.Vec3
import work.nekow.particledrawing.animation.program.AnimInstruction
import work.nekow.particledrawing.animation.script.GetterRewriter
import work.nekow.particledrawing.animation.program.EntityBinding
import work.nekow.particledrawing.animation.program.PivotRef
import work.nekow.particledrawing.core.easing.EasingType
import work.nekow.particledrawing.core.network.AnimationProgramAppendPayload
import work.nekow.particledrawing.core.network.AnimationProgramPayload
import work.nekow.particledrawing.core.network.ProgramAnchorPayload
import work.nekow.particledrawing.core.server.AnimationScheduler
import net.neoforged.neoforge.network.PacketDistributor
import java.util.UUID

/**
 * 编排式动画的粒子组：一组可同时变换的粒子（经 Draw 工具或 [ParticleManager.createGroup] 创建）。
 *
 * **适用边界**：成员基本固定、变换是**组级统一**的编排式动画（旋转/缩放/脉冲/路径/淡入淡出）用它——
 * 链式调用录制 [AnimInstruction] 指令流一次下发，客户端本地求值直写渲染，持续动画零带宽。
 * 反过来，**成员逐 tick 增删、每颗粒子各自受力/轨迹/寿命、按位置条件回收**的粒子流
 * （黑洞吸入、重力场下落）请用 [ParticleBatch]：本类的成员变更会重发全量受控清单，
 * 组级变换也表达不了「每粒子沿各自轨迹运动」。
 *
 * delay 推进时间线游标（累积、不清零）；defineEntity/expression 提供实体句柄与表达式能力。
 * 程序下发之后录制的指令按「**从现在起**」读（见 [delay]），所以长寿组可以在运行期再追加一段动画。
 *
 * **轴心语义（组级变换都绕它算）**：轴心是**程序级状态**，由 [setPivot] / [followEntity] 绑定，
 * 绑定一次就对**其后**的 [rotate] / [spin] / [scale] / [pulse] 全部生效，直到下一次绑定。
 * 旋转/缩放类指令**不接受轴心参数**，所以**调用顺序就是语义**：
 *
 * ```
 * group.followEntity(uuid)        // 轴心 = 实体（每 tick 本地解析，零带宽）
 *     .spin(Vec3(0.0, 1.0, 0.0), 0.02)   // 绕实体转；反过来先 spin 就只绕当时的固定点转
 * ```
 *
 * 轴心绑定到实体后是**活的**（跟随位置，`local = true` 时连朝向一起），组内各粒子保持相对轴心的偏移。
 * 这个轴心同时是 **arm 基准**：客户端按「成员生成位置 − 轴心」反算各粒子的相对偏移，
 * 所以 [move] / [movePath] **不会**改它——平移只作用于渲染位置，不参与相对偏移的换算。
 *
 * **旋转可叠加**：多条 [rotate] / [spin] 的角度是累加的（后一条不会覆盖前一条的相位），
 * 于是「先自转一阵、再补一段一次性旋转、继续自转」能接得上（见 [rotate]）。
 */
@Suppress("unused")
class ParticleGroup(
    val id: UUID,
    var pivot: Vec3,
    internal val manager: ParticleManager
) {

    /** 时间线游标（毫秒）：delay 累积推进（1 game tick = 50ms）。 */
    private var cursorMs = 0

    /** 已录制的指令流（未下发部分）。 */
    private val instructions = ArrayList<AnimInstruction>()

    /** 程序是否已随粒子清单下发（后续走增量 append）。 */
    private var armed = false

    /** 是否已经绑定过可移动轴心（[updateAnchor] 的前置条件）。 */
    private var movableAnchor = false

    /** 游标 → 程序时刻的换算（增量追加按「从现在起」读）。 */
    private val clock = GroupClock()

    /** 实体注册表与初始变量。 */
    private val entityBindings = ArrayList<EntityBinding>()
    private val vars = LinkedHashMap<String, Double>()

    /** handle 合法性：公式标识符 + 不得与内建常量/属性寄存器撞名。 */
    private val HANDLE_REGEX = Regex("""^[A-Za-z_][A-Za-z0-9_]*$""")
    private val RESERVED_NAMES = setOf("i", "n", "t", "PI", "E") +
        setOf("x", "y", "z", "r", "g", "b", "a", "vx", "vy", "vz", "sc", "glow", "light")

    /** handle 在实体注册表中必须唯一，且不得与程序变量重名——同名会在公式环境里互相覆盖。 */
    private fun requireFreeHandle(handle: String) {
        require(entityBindings.none { it.handle == handle } && handle !in vars) { "实体句柄名 '$handle' 已被占用" }
    }

    /** 服务端 best-effort 预警：扫描代码里的 get_* 调用，报「确定错误」（未知名/形态误用）。 */
    private fun lintGetters(code: String) {
        for (problem in GetterRewriter.lint(code)) {
            LOGGER.warn("[ParticleDrawing] group {} 公式预警: {}", id, problem)
        }
    }

    // —— 基础 ——

    /**
     * 设置变换轴心（固定坐标），同时作为 **arm 基准**（客户端按「成员生成位置 − 轴心」反算相对偏移）。
     * **粘性**：一直生效到下一次 [setPivot] / [followEntity]，之后所有 [rotate] / [spin] / [scale] / [pulse]
     * 都绕它算。[move] / [movePath] 不会改它。
     */
    fun setPivot(pivot: Vec3): ParticleGroup {
        this.pivot = pivot
        emit(AnimInstruction.BindPivot(cursorNow(), PivotRef.Fixed(pivot)))
        return this
    }

    /** [setPivot] 的分量重载。 */
    fun setPivot(x: Number, y: Number, z: Number): ParticleGroup {
        return setPivot(Vec3(x.toDouble(), y.toDouble(), z.toDouble()))
    }

    /**
     * 轴心切换为跟随实体：组随实体位置移动（+偏移），由客户端本地解析，零逐 tick 带宽。
     *
     * 同样是**粘性**的：绑定之后的 [rotate] / [spin] / [scale] / [pulse] 都绕/相对它算，
     * 「跟随持有者 + 持续自转」就是本方法 + [spin] 的顺序（顺序反了只会绕固定点转）。
     * 绑定即改 arm 基准，所以**铺成员与绑定的先后**决定相对偏移的换算基准：先绑定再铺成员最直观。
     *
     * @param uuid 目标实体 UUID
     * @param offset 相对实体位置（脚底）的偏移
     * @param local true = 整组连偏移一起随实体朝向旋转（贴在身前/身侧）；false = 只跟随位置（世界朝向）
     */
    fun followEntity(uuid: UUID, offset: Vec3 = Vec3.ZERO, local: Boolean = false): ParticleGroup {
        pivot = offset.add(pivot)
        emit(AnimInstruction.BindPivot(cursorNow(), PivotRef.FollowEntity(uuid, offset, local)))
        return this
    }

    /**
     * 向该组添加一个粒子。
     * @param handle 粒子的句柄，可为 null（粒子因达到上限被拒绝时）
     */
    fun add(handle: ParticleHandle?) {
        if (handle == null) return
        manager.getEngine().getGroup(id)?.addMember(handle.id)
        armed = false // 成员变化后重发全量以刷新受控清单
    }

    /**
     * 绑定一个**可移动轴心**（黑洞中心、重力场中心、跟随投射物的法阵）：绑定一次即可，
     * 位置用 [updateAnchor] 逐 tick 更新（专用小包），客户端按相邻两个样本插值渲染。
     *
     * 与 [setPivot] 的区别正在这里：固定轴心要挪就得每 tick 再 `setPivot` 一次
     * （每 tick 一条绑定指令 + 立即替换，帧间是硬跳）；本方法只发位置。
     *
     * `Anchor.Movable` 的 [Orient.VELOCITY] 会让整组随运动方向转向（[Orient.WORLD] 只跟位置）；
     * 实体锚点请用 [followEntity]（那里按 UUID 由客户端本地解析，比逐 tick 报位置更省）。
     *
     * @param anchor 只接受 `Anchor.Fixed`（等价 [setPivot]）与 `Anchor.Movable`
     */
    fun anchor(anchor: Anchor): ParticleGroup {
        when (anchor) {
            is Anchor.Fixed -> {
                pivot = anchor.pos
                emit(AnimInstruction.BindPivot(cursorNow(), PivotRef.Fixed(anchor.pos)))
            }
            is Anchor.Movable -> {
                pivot = anchor.pos
                movableAnchor = true
                emit(AnimInstruction.BindPivot(cursorNow(), PivotRef.Movable(anchor.pos, anchor.velocity, anchor.orient)))
            }
            is Anchor.Entity -> throw IllegalArgumentException(
                "ParticleGroup.anchor 不接受实体锚点：请用 followEntity(uuid, offset, local)（客户端本地解析，零逐 tick 带宽）"
            )
        }
        return this
    }

    /**
     * 更新可移动轴心的位置（配合 [anchor] 使用）：[previous] / [current] 是服务端相邻的两个样本。
     *
     * 客户端按这对样本插值渲染，相位与 `track` 粒子一致；两条样本离得太远（瞬移）或断流之后
     * 第一条样本，都按跳变处理，不会在两点之间扫出一条假轨迹。
     *
     * @param previous 上一条样本（上一 tick 的位置）
     * @param current 本条样本（本 tick 的位置）
     * @param velocity 本 tick 的速度：只在轴心朝向为 `Orient.VELOCITY` 时用于整组转向
     */
    @JvmOverloads
    fun updateAnchor(previous: Vec3, current: Vec3, velocity: Vec3 = current.subtract(previous)): ParticleGroup {
        require(movableAnchor) {
            "updateAnchor 需要先用 anchor(Anchor.Movable(...)) 绑定可移动轴心"
        }
        pivot = current
        for (player in manager.getPlayers()) {
            PacketDistributor.sendToPlayer(player, ProgramAnchorPayload(
                id,
                previous.x, previous.y, previous.z,
                current.x, current.y, current.z,
                velocity.x, velocity.y, velocity.z,
            ))
        }
        return this
    }

    /** [updateAnchor] 的分量重载。 */
    fun updateAnchor(
        prevX: Number, prevY: Number, prevZ: Number,
        x: Number, y: Number, z: Number,
        vx: Number, vy: Number, vz: Number,
    ): ParticleGroup = updateAnchor(
        Vec3(prevX.toDouble(), prevY.toDouble(), prevZ.toDouble()),
        Vec3(x.toDouble(), y.toDouble(), z.toDouble()),
        Vec3(vx.toDouble(), vy.toDouble(), vz.toDouble()),
    )

    /**
     * 获取组内成员数量。
     * @return 粒子数量
     */
    fun size(): Int = manager.getEngine().getGroup(id)?.size() ?: 0

    // —— 时间线编排 ——

    /**
     * 把时间线游标向前推进 [ticks]：之后链式调用的动画方法都在新游标时刻触发。
     * 游标累积、不清零——连续两个动画共享同一时刻（如停转与淡出同刻）。
     *
     * **增量追加时读作「从现在起」**：程序已下发之后再录制的指令，其时刻按「录制那一刻 + 本会话已 delay 的时长」
     * 换算（见 [GroupClock]）。所以长寿组跑了一阵子之后 `delay(1).fadeOut(5)` 就是「1 tick 后开始、5 tick 淡完」，
     * 而不是因为游标落在过去而瞬间完成。全量重发（成员变化触发）会把时间轴重新从那一刻起算。
     */
    fun delay(ticks: Int): ParticleGroup {
        cursorMs += ticks.coerceAtLeast(0) * 50
        return this
    }

    private fun cursorNow(): Int = cursorMs

    /**
     * 录制一条指令并立即下发，返回它在程序时刻轴上的位置（供定时销毁对齐）。
     * 指令在发送时才按当前会话换算时刻，因此没发出去的指令（如组里还没有成员）不会被错误地提前换算。
     */
    private fun emit(ins: AnimInstruction): Int {
        val now = manager.level.gameTime
        if (!armed) clock.onProgramStart(now)
        val at = clock.programTime(ins.startMs, now)
        instructions.add(ins)
        flush(now)
        return at
    }

    /** 首次全量下发；其后增量追加。 */
    private fun flush(nowTick: Long) {
        val players = manager.getPlayers()
        // 锚点必须与 level.gameTime 同源：客户端用它对齐自己的 level.gameTime，
        // 消除双端时钟漂移（勿用进程级计数器——与存档 gameTime 不同源会让时间线整体错位）
        if (!armed) {
            val members = manager.getEngine().getGroup(id)?.memberIds()?.toList()
            if (members.isNullOrEmpty()) {
                LOGGER.warn("[ParticleDrawing] group {} has no members; animation program not sent", id)
                return
            }
            val batch = instructions.map { it.shiftStartMs(clock.shiftMs) }
            instructions.clear()
            for (player in players) {
                PacketDistributor.sendToPlayer(
                    player,
                    AnimationProgramPayload(id, members, nowTick, pivot, entityBindings.toList(), vars.toMap(), batch),
                )
            }
            armed = true
        } else if (instructions.isNotEmpty()) {
            val batch = instructions.map { it.shiftStartMs(clock.shiftMs) }
            instructions.clear()
            for (player in players) {
                PacketDistributor.sendToPlayer(player, AnimationProgramAppendPayload(id, batch))
            }
        }
        clock.onEmit(nowTick, cursorMs)
    }

    /** 排一次组销毁：把程序时刻换算成「从此刻起」的 tick 数，避免把销毁推后一整段已运行时长。 */
    private fun scheduleDestroy(programTimeMs: Int) {
        AnimationScheduler.schedule(clock.ticksFromNow(programTimeMs, manager.level.gameTime)) {
            manager.getEngine().destroyGroup(id, manager.getPlayers())
            stopProgramOnClient(destroyParticles = false)
        }
    }

    // —— 生命周期 ——

    /**
     * 淡入：整组透明度从 0 缓动到各自当前值。
     */
    fun fadeIn(durationTicks: Int, easing: EasingType = EasingType.EASE_OUT): ParticleGroup {
        emit(AnimInstruction.FadeIn(cursorMs, durationTicks * 50, easing))
        return this
    }

    /**
     * 淡出：整组透明度缓动到 0；[removeAfter] 为 true 时淡出结束（+250ms 余量）由服务端销毁整组，
     * 销毁时刻按「本指令的程序时刻 + 时长」从**当下**起算，与客户端口径一致。
     */
    fun fadeOut(durationTicks: Int, removeAfter: Boolean = true, easing: EasingType = EasingType.EASE_IN): ParticleGroup {
        val at = emit(AnimInstruction.FadeOut(cursorMs, durationTicks * 50, easing))
        if (removeAfter) scheduleDestroy(at + durationTicks * 50 + 250)
        return this
    }

    /**
     * 定时销毁整组（含所有粒子）。
     * @param ticks 从当前时刻起再等多少 tick 销毁（增量追加时同 [delay]，读作「从现在起」）
     */
    fun destroyAfter(ticks: Int): ParticleGroup {
        scheduleDestroy(clock.programTime(cursorMs, manager.level.gameTime) + ticks * 50)
        return this
    }

    /**
     * 停止本组全部持续型动画（无限模式的 spin / pulse）。
     * 受 delay 游标控制：`.spin(...).delay(100).stopContinuous()` 表示转 100 tick 后停。
     */
    fun stopContinuous(): ParticleGroup {
        emit(AnimInstruction.StopContinuous(cursorMs))
        return this
    }

    /**
     * 销毁整个粒子组及其所有粒子。
     */
    fun remove() {
        manager.getEngine().destroyGroup(id, manager.getPlayers())
        stopProgramOnClient(destroyParticles = false)
    }

    private fun stopProgramOnClient(destroyParticles: Boolean) {
        for (player in manager.getPlayers()) {
            PacketDistributor.sendToPlayer(player, work.nekow.particledrawing.core.network.StopAnimationProgramPayload(id, destroyParticles))
        }
    }

    // —— 一次性变换（有限时长指令） ——

    /**
     * 组平移。[delta] 只影响渲染位置（客户端 `pathOffset`），**不改轴心绑定**——
     * 轴心（arm 基准）只由 [setPivot] / [followEntity] 决定，所以「铺完成员先 move 一下」不会把成员的相对偏移算歪。
     */
    fun move(delta: Vec3, durationTicks: Int, easing: EasingType = EasingType.LINEAR): ParticleGroup {
        emit(AnimInstruction.Translate(cursorMs, delta, durationTicks * 50, easing))
        return this
    }

    /** [move] 的分量重载。 */
    fun move(x: Number, y: Number, z: Number, durationTicks: Int, easing: EasingType = EasingType.LINEAR): ParticleGroup {
        return move(Vec3(x.toDouble(), y.toDouble(), z.toDouble()), durationTicks, easing)
    }

    /**
     * **逐成员各自方向**的平移：每颗粒子沿自己「相对轴心的偏移」方向外移
     * `scale × |偏移|`（整组一个包，成员各飞各的）。
     *
     * 用于「球面/多面体碎裂时碎片各自沿自己的法线向外飞」：这种效果组级 [move] 表达不了
     * （整组只有一个位移向量），只能一片一个组，而组数直接等于 arm 日志行数与 arm 开销。
     *
     * 方向取**当前**偏移（跟着 [spin]/[rotate] 一起转），所以「边转边炸开」也是对的；
     * `scale = 1` 表示每颗沿自己的方向走到「偏移长度翻倍」的位置。
     *
     * @param scale 沿各自偏移方向的位移倍率（1 = 移到 2 倍偏移处）
     */
    fun moveAlongOffset(scale: Float, durationTicks: Int, easing: EasingType = EasingType.LINEAR): ParticleGroup {
        emit(AnimInstruction.MoveEach(cursorMs, scale, durationTicks * 50, easing))
        return this
    }

    /**
     * 绕**当前轴心**一次性旋转（轴心见 [setPivot] / [followEntity]）。
     * 想绕实体转就先 `followEntity(...)` 再调本方法——**调用顺序就是语义**，本方法不接受轴心参数。
     *
     * 与 [spin] **叠加**：多条旋转指令的角度累加，后一条不会把前一条的相位覆盖掉。
     * 于是「已经自转了一阵 → 再补一段一次性旋转 → 继续自转」能接得上（`durationTicks = 0` 即瞬时补相位）。
     */
    fun rotate(axis: Vec3, radians: Double, durationTicks: Int, easing: EasingType = EasingType.LINEAR): ParticleGroup {
        emit(AnimInstruction.RotateOnce(cursorMs, axis, radians, durationTicks * 50, easing))
        return this
    }

    /** [rotate] 的分量重载。 */
    fun rotate(x: Number, y: Number, z: Number, radians: Double, durationTicks: Int, easing: EasingType = EasingType.LINEAR): ParticleGroup {
        return rotate(Vec3(x.toDouble(), y.toDouble(), z.toDouble()), radians, durationTicks, easing)
    }

    /** 重着色到目标颜色。 */
    fun recolor(targetColor: Color, durationTicks: Int, easing: EasingType = EasingType.LINEAR): ParticleGroup {
        emit(AnimInstruction.Recolor(cursorMs, targetColor.r, targetColor.g, targetColor.b, targetColor.a, durationTicks * 50, easing))
        return this
    }

    /**
     * 相对**当前轴心**等比缩放：粒子到轴心的距离与视觉大小同乘 [ratio]（倍率语义，2f = 放大两倍）。
     * 半径 3 的圆 `scale(3f)` 之后半径就是 9 —— 组级「胀开 / 缩回」一个调用就够，客户端本地求值、零带宽。
     * durationTicks=0 表示瞬时跳变。
     *
     * **倍率是累积的**：本指令的起点是**执行那一刻**的当前倍率（不是恒定的 1），所以
     * `.scale(0.01f, 0).scale(100f, 3)` 会从 0.01 倍长回 1 倍；「先放大 1.5 倍、再缩回原尺寸」也接得上，
     * 中途不会被重置回 1。要直接给绝对目标用 [scaleTo]。
     */
    fun scale(ratio: Float, durationTicks: Int, easing: EasingType = EasingType.LINEAR): ParticleGroup {
        emit(AnimInstruction.ScaleBy(cursorMs, ratio, durationTicks * 50, easing))
        return this
    }

    /**
     * [scale] 的显式名字：**在当前倍率之上相乘**（`scaleBy(0.5f)` = 缩到一半，再来一次还是减半）。
     * 与 [scaleTo] 配对使用，读代码时不用猜这条指令的终点怎么算。
     */
    fun scaleBy(ratio: Float, durationTicks: Int, easing: EasingType = EasingType.LINEAR): ParticleGroup =
        scale(ratio, durationTicks, easing)

    /**
     * 把组级倍率缓动到**绝对目标** [target]（1 = 原始尺寸）：与 [scale] 只差终点怎么算 ——
     * 本方法的终点是写死的 [target]，起点同样是执行那一刻的当前倍率。
     *
     * 于是「固定结构从零尺寸展开」= 先 `scaleTo(0f, 0)` 铺成员、再 `scaleTo(1f, 6)` 长开；
     * 「任意时刻退场」= 直接 `scaleTo(0f, 8)`，无论当时是 1 倍还是 3 倍都不会先跳回 1。
     * `target = 0` 表示完全收起：客户端**不绘制**（不是缩到一个看不见但仍占用渲染的小尺寸）。
     */
    fun scaleTo(target: Float, durationTicks: Int, easing: EasingType = EasingType.LINEAR): ParticleGroup {
        require(target >= 0f) { "scaleTo 的目标倍率不能为负" }
        emit(AnimInstruction.ScaleTo(cursorMs, target, durationTicks * 50, easing))
        return this
    }

    // —— 持续运动 ——

    /**
     * 无限匀速旋转（绕**当前轴心**，同 [rotate]，与其它旋转指令叠加）；用 [stopContinuous] 停止。
     *
     * 轴心是活的：先 [followEntity] 再本方法，就是「跟着实体转」——护盾一类「跟随持有者 + 自转」的写法。
     */
    fun spin(axis: Vec3, radiansPerTick: Double): ParticleGroup {
        emit(AnimInstruction.Spin(cursorMs, axis, radiansPerTick / 50))
        return this
    }

    /** 折线路径移动：从当前基准出发依次经过 [points]，[easing] 作用于全程进度。同 [move]，不改轴心绑定。 */
    fun movePath(points: List<Vec3>, durationTicks: Int, easing: EasingType = EasingType.LINEAR): ParticleGroup {
        require(points.isNotEmpty()) { "movePath 至少需要一个途经点" }
        emit(AnimInstruction.MovePath(cursorMs, points, durationTicks * 50, easing))
        return this
    }

    /**
     * 呼吸脉冲：1× ↔ [peakRatio]× 往复（同样作用于粒子到轴心的距离与视觉大小）；[cycles] 负数无限。
     */
    fun pulse(peakRatio: Float, halfPeriodTicks: Int, cycles: Int = -1): ParticleGroup {
        emit(AnimInstruction.Pulse(cursorMs, peakRatio, halfPeriodTicks * 50, cycles))
        return this
    }

    // —— 实体句柄 + 表达式指令（上限能力） ——

    /**
     * 定义实体句柄：把 [uuid] 以 [handle] 名写进程序的实体注册表（下发顺序 = 句柄序号）。
     * 公式内通过 `get_entity_<prop>(<handle>)` 被动取值——用到什么取什么，
     * 属性表见 `EntityProp` / `WorldProp` 枚举；世界属性无需登记，直接 `get_world_<prop>()`。
     *
     * handle 必须是合法公式标识符，且不得与内建名（i/n/t/PI/E、x/y/z/r/g/b/a/vx/vy/vz/sc/glow/light）
     * 或已有变量重名；违反立即抛异常。
     */
    fun defineEntity(handle: String, uuid: UUID): ParticleGroup {
        require(HANDLE_REGEX.matches(handle)) { "实体句柄名 '$handle' 不是合法标识符" }
        require(handle !in RESERVED_NAMES) { "实体句柄名 '$handle' 与内建名冲突" }
        requireFreeHandle(handle)
        entityBindings.add(EntityBinding(handle, uuid))
        armed = false // 注册表变化需重发全量
        return this
    }

    /** 设置程序静态变量（编译进公式环境的常量）。 */
    fun setVariable(name: String, value: Double): ParticleGroup {
        require(entityBindings.none { it.handle == name }) { "变量名 '$name' 与实体句柄冲突" }
        vars[name] = value
        return this
    }

    /**
     * 表达式指令：每粒子每 tick 求值 [code]（专用标量公式：i/n/t、[x,y,z]=... 等旧式语法，
     * 与 .pdraw 函数对象的 this 脚本语言不同）。
     * 输出 [x,y,z] 为世界绝对坐标；可用 i/n/t、全套标量数学函数、get_* 被动输入、程序变量。
     * 一旦出现即接管位置/颜色/缩放的最终解释权；FADE 因子仍叠加其上。
     */
    fun expression(code: String): ParticleGroup {
        lintGetters(code)
        emit(AnimInstruction.Expression(cursorMs, code))
        return this
    }

    /**
     * 运行时热更程序变量（对已激活程序生效）：value 为标量公式字符串，
     * 可引用其它程序变量（如 `group.setVariableLive("rad", "speed * 2")`）或直接给常量。
     * 注：该路径不注入 t/i/n，公式不能引用它们。
     */
    fun setVariableLive(name: String, value: String) {
        lintGetters(value)
        for (player in manager.getPlayers()) {
            PacketDistributor.sendToPlayer(player, work.nekow.particledrawing.core.network.SetProgramVarPayload(id, name, value))
        }
    }

    /**
     * 运行时热更程序变量，并**在 [ticks] tick 内缓动**到目标值（不是立即赋常量）。
     *
     * 变量常被当作空间端点用（光束末端、场中心）：立即赋值会让整段几何瞬移，
     * 本方法让客户端从当前值缓动过去——端点是「扫」过去的，与相邻样本插值同一个目标（高刷下连续）。
     *
     * [value] 仍是标量公式字符串（与 [setVariableLive] 同一套求值环境，不注入 t/i/n），
     * 在收到那一刻求出目标值；`ticks = 0` 等价于立即赋值。
     */
    @JvmOverloads
    fun setVariableInterpolated(
        name: String,
        value: String,
        ticks: Int,
        easing: EasingType = EasingType.LINEAR,
    ): ParticleGroup {
        require(ticks >= 0) { "setVariableInterpolated 的时长不能为负" }
        lintGetters(value)
        val payload = work.nekow.particledrawing.core.network.SetProgramVarEasePayload(
            id, name, value, ticks * 50, easing,
        )
        for (player in manager.getPlayers()) {
            PacketDistributor.sendToPlayer(player, payload)
        }
        return this
    }

    override fun toString() = "ParticleGroup{$id size=${size()}}"

    companion object {
        private val LOGGER = org.apache.logging.log4j.LogManager.getLogger("ParticleDrawing")
    }
}
