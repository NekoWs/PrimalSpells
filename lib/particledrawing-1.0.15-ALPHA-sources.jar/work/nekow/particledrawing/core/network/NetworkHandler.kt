package work.nekow.particledrawing.core.network

import net.neoforged.bus.api.SubscribeEvent
import net.neoforged.fml.common.EventBusSubscriber
import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent
import net.neoforged.neoforge.network.registration.PayloadRegistrar
import work.nekow.particledrawing.ParticleDrawing

/**
 * 网络包注册处理器：注册所有 `playToClient` 数据包。
 */
@EventBusSubscriber(modid = ParticleDrawing.MODID)
@Suppress("unused")
object NetworkHandler {

    @SubscribeEvent
    @JvmStatic
    fun register(event: RegisterPayloadHandlersEvent) {
        // 载荷集合/字段变化即提升版本：新版客户端与服务端不会误配
        val registrar: PayloadRegistrar = event.registrar("8")

        registrar.playToClient(ParticleSpawnPayload.TYPE, ParticleSpawnPayload.STREAM_CODEC, ClientPayloadHandler::handleSpawn)
        registrar.playToClient(ParticleSpawnBatchPayload.TYPE, ParticleSpawnBatchPayload.STREAM_CODEC, ClientPayloadHandler::handleSpawnBatch)
        registrar.playToClient(ParticleUpdatePayload.TYPE, ParticleUpdatePayload.STREAM_CODEC, ClientPayloadHandler::handleUpdate)
        registrar.playToClient(ParticleDestroyPayload.TYPE, ParticleDestroyPayload.STREAM_CODEC, ClientPayloadHandler::handleDestroy)
        registrar.playToClient(AnimationProgramPayload.TYPE, AnimationProgramPayload.STREAM_CODEC, ClientPayloadHandler::handleProgram)
        registrar.playToClient(AnimationProgramAppendPayload.TYPE, AnimationProgramAppendPayload.STREAM_CODEC, ClientPayloadHandler::handleProgramAppend)
        registrar.playToClient(SetProgramVarPayload.TYPE, SetProgramVarPayload.STREAM_CODEC, ClientPayloadHandler::handleSetProgramVar)
        registrar.playToClient(SetProgramVarEasePayload.TYPE, SetProgramVarEasePayload.STREAM_CODEC, ClientPayloadHandler::handleSetProgramVarEase)
        registrar.playToClient(ProgramAnchorPayload.TYPE, ProgramAnchorPayload.STREAM_CODEC, ClientPayloadHandler::handleProgramAnchor)
        registrar.playToClient(StopAnimationProgramPayload.TYPE, StopAnimationProgramPayload.STREAM_CODEC, ClientPayloadHandler::handleStopProgram)
        registrar.playToClient(ParticleVelocityPayload.TYPE, ParticleVelocityPayload.STREAM_CODEC, ClientPayloadHandler::handleVelocity)
        registrar.playToClient(ParticleVelocityBatchPayload.TYPE, ParticleVelocityBatchPayload.STREAM_CODEC, ClientPayloadHandler::handleVelocityBatch)
        registrar.playToClient(ParticleForcePayload.TYPE, ParticleForcePayload.STREAM_CODEC, ClientPayloadHandler::handleForce)
        registrar.playToClient(ParticleForceBatchPayload.TYPE, ParticleForceBatchPayload.STREAM_CODEC, ClientPayloadHandler::handleForceBatch)
        registrar.playToClient(ParticleTrackPayload.TYPE, ParticleTrackPayload.STREAM_CODEC, ClientPayloadHandler::handleTrack)
        registrar.playToClient(ParticleTrackBatchPayload.TYPE, ParticleTrackBatchPayload.STREAM_CODEC, ClientPayloadHandler::handleTrackBatch)
        registrar.playToClient(ParticleAttachPayload.TYPE, ParticleAttachPayload.STREAM_CODEC, ClientPayloadHandler::handleAttach)
        registrar.playToClient(ParticleRotationPayload.TYPE, ParticleRotationPayload.STREAM_CODEC, ClientPayloadHandler::handleRotation)
        registrar.playToClient(ParticleTranslatePayload.TYPE, ParticleTranslatePayload.STREAM_CODEC, ClientPayloadHandler::handleTranslate)
        registrar.playToClient(ParticleSetPositionPayload.TYPE, ParticleSetPositionPayload.STREAM_CODEC, ClientPayloadHandler::handleSetPosition)
        registrar.playToClient(ParticleLightLevelPayload.TYPE, ParticleLightLevelPayload.STREAM_CODEC, ClientPayloadHandler::handleLightLevel)
        registrar.playToClient(ParticleTexturePayload.TYPE, ParticleTexturePayload.STREAM_CODEC, ClientPayloadHandler::handleTexture)
        registrar.playToClient(PlayAnimationPayload.TYPE, PlayAnimationPayload.STREAM_CODEC, ClientPayloadHandler::handlePlayAnimation)
        registrar.playToClient(PlayAnimationDataPayload.TYPE, PlayAnimationDataPayload.STREAM_CODEC, ClientPayloadHandler::handlePlayAnimationData)
        registrar.playToClient(VariableUpdatePayload.TYPE, VariableUpdatePayload.STREAM_CODEC, ClientPayloadHandler::handleVariableUpdate)
        registrar.playToClient(StopAnimationPayload.TYPE, StopAnimationPayload.STREAM_CODEC, ClientPayloadHandler::handleStopAnimation)

        // 特效 API：按 key 播放 + 可移动锚点 + 播放时钟 + 资源按需下发
        registrar.playToClient(PlayEffectPayload.TYPE, PlayEffectPayload.STREAM_CODEC, ClientPayloadHandler::handlePlayEffect)
        registrar.playToClient(AnchorUpdateBatchPayload.TYPE, AnchorUpdateBatchPayload.STREAM_CODEC, ClientPayloadHandler::handleAnchorUpdates)
        registrar.playToClient(ClockSyncPayload.TYPE, ClockSyncPayload.STREAM_CODEC, ClientPayloadHandler::handleClockSync)
        registrar.playToClient(EffectDataPayload.TYPE, EffectDataPayload.STREAM_CODEC, ClientPayloadHandler::handleEffectData)
        registrar.playToServer(EffectRequestPayload.TYPE, EffectRequestPayload.STREAM_CODEC, ServerPayloadHandler::handleEffectRequest)

        // 运行时发射器：声明一次 + 变更时更新（发射在客户端逐渲染帧发生）
        registrar.playToClient(EmitterSpawnPayload.TYPE, EmitterSpawnPayload.STREAM_CODEC, ClientPayloadHandler::handleEmitterSpawn)
        registrar.playToClient(EmitterUpdatePayload.TYPE, EmitterUpdatePayload.STREAM_CODEC, ClientPayloadHandler::handleEmitterUpdate)
        registrar.playToClient(EmitterStopPayload.TYPE, EmitterStopPayload.STREAM_CODEC, ClientPayloadHandler::handleEmitterStop)

        // 动画文件同步（配置阶段）：客户端请求 → 服务器下发文件块 → 完成信号
        registrar.configurationToServer(AnimationSyncRequestPayload.TYPE, AnimationSyncRequestPayload.STREAM_CODEC, ServerPayloadHandler::handleSyncRequest)
        registrar.configurationToClient(AnimationSyncBeginPayload.TYPE, AnimationSyncBeginPayload.STREAM_CODEC, ClientPayloadHandler::handleSyncBegin)
        registrar.configurationToClient(AnimationSyncFilePayload.TYPE, AnimationSyncFilePayload.STREAM_CODEC, ClientPayloadHandler::handleSyncFile)
        registrar.configurationToClient(AnimationSyncDonePayload.TYPE, AnimationSyncDonePayload.STREAM_CODEC, ClientPayloadHandler::handleSyncDone)
    }
}
