package work.nekow.particledrawing.core.client

import net.minecraft.client.Minecraft
import net.minecraft.resources.Identifier
import net.minecraft.world.phys.Vec3
import work.nekow.particledrawing.animation.AnimationLoader
import work.nekow.particledrawing.animation.AnimationProgress
import work.nekow.particledrawing.animation.ClientAnimationPlayer
import work.nekow.particledrawing.animation.ParticleAnimation
import work.nekow.particledrawing.animation.PlaybackClock
import work.nekow.particledrawing.animation.ProcessClock
import work.nekow.particledrawing.animation.TrackPr
import work.nekow.particledrawing.animation.timelineLength
import work.nekow.particledrawing.animation.PdrawcReader
import work.nekow.particledrawing.api.Anchor
import work.nekow.particledrawing.api.EffectOptions
import work.nekow.particledrawing.core.network.PlayEffectPayload
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.floor

/**
 * 客户端动画管理器：本地播放服务端下发的 .pdrawc 动画。
 * 普通粒子按 game tick 推进（20Hz）；函数对象 process 按渲染帧推进（[frameTick]），派生粒子按帧同步。
 */
object ClientAnimationManager {

    private class Entry(
        val player: ClientAnimationPlayer,
        val particleUuids: MutableMap<String, UUID>,
        val animation: ParticleAnimation,
        // 播放原点（世界坐标）：摄像机预览姿态需加此偏移才与粒子同处一个世界
        val origin: Vec3,
        // 当前已生成（在场）的状态 id 集合：st 门控的生成/回收以它做差分
        val liveIds: HashSet<String> = HashSet(),
        // 特效锚点解析器（null = 固定 origin 路径）
        val anchor: EffectAnchorResolver? = null,
        // 特效播放时钟（null = 按 gameTime 推进）
        val clock: PlaybackClock? = null,
        // 生效的 loop（特效可覆盖动画自身 loop）
        val loop: Boolean = true,
        // 音频资产 → 播放器（按资产 id 索引；播放头进出区间时出声/暂停）
        val audioPlayers: MutableMap<String, AudioStreamPlayer> = HashMap(),
        // 渲染帧 process 时刻的单调游标（防止 partialTick 与播放头口径不一致时往回跳）
        val processClock: ProcessClock = ProcessClock(),
    )

    private val entries = ConcurrentHashMap<UUID, Entry>()

    // 特效资源缓存：key → .pdrawc 字节（服务端下发后驻留，重复播放不再请求）
    private val effectCache = ConcurrentHashMap<Identifier, ByteArray>()

    // 缓存缺失的待播特效：收到 EffectDataPayload 后再真正开播
    private val pendingEffectPlays = ConcurrentHashMap<UUID, PlayEffectPayload>()

    /** 一次播放的调试信息快照。 */
    data class DebugInfo(
        val animId: UUID,
        val particleCount: Int,
        val currentMs: Int,
        val maxMs: Int,
        val frameCount: Long,
        val lastAdvanceMillis: Double,
        val avgAdvanceMillis: Double,
    )

    /** 收集当前所有播放中动画的调试信息。 */
    @JvmStatic
    fun debugInfo(): List<DebugInfo> = entries.map { (id, e) ->
        DebugInfo(
            animId = id,
            particleCount = e.player.particleCount,
            currentMs = e.player.currentMsValue,
            maxMs = e.player.maxMsValue,
            frameCount = e.player.frameCount,
            lastAdvanceMillis = e.player.lastAdvanceNanos / 1_000_000.0,
            avgAdvanceMillis = e.player.avgAdvanceNanos / 1_000_000.0,
        )
    }

    /** 当前播放中的动画数量。 */
    @JvmStatic
    fun activeAnimationCount(): Int = entries.size

    /** 一次摄像机匹配结果（/pdraw camera 使用）。 */
    data class CameraTarget(
        val animationId: UUID,
        val cameraId: String,
        val cameraName: String,
        val pose: ClientAnimationPlayer.CameraPose,
        val origin: Vec3,
    )

    /**
     * 在所有播放中的动画里按 id 或 name 匹配一个摄像机，并返回其在当前 tick 的姿态与播放原点。
     * 无匹配或姿态求值失败时返回 null。
     */
    @JvmStatic
    fun findCamera(camIdOrName: String): CameraTarget? {
        for ((animId, e) in entries) {
            val cam = e.animation.cameras.firstOrNull { it.id == camIdOrName || it.name == camIdOrName } ?: continue
            val pose = e.player.cameraPoseAt(cam.id, e.player.currentMsValue.toDouble()) ?: continue
            return CameraTarget(animId, cam.id, cam.name, pose, e.origin)
        }
        return null
    }

    /** 列出所有播放中动画的摄像机 id 与 name（供 /pdraw camera 参数补全）。 */
    @JvmStatic
    fun listCameras(): List<String> {
        val out = LinkedHashSet<String>()
        for ((_, e) in entries) {
            for (cam in e.animation.cameras) {
                out.add(cam.id)
                out.add(cam.name)
            }
        }
        return out.toList()
    }

    /** 开始本地播放一个动画（解析 .pdrawc 字节并验签，失败则拒绝播放）。 */
    @JvmStatic
    fun play(animationId: UUID, data: ByteArray, origin: Vec3, startGameTick: Long) {
        val animation = try {
            AnimationLoader.parse(data)
        } catch (_: Exception) {
            return
        }
        play(animationId, animation, origin, startGameTick)
    }

    /** 开始本地播放一个代码生成的 [ParticleAnimation]（结构化载荷，不验签）。 */
    @JvmStatic
    fun play(animationId: UUID, animation: ParticleAnimation, origin: Vec3, startGameTick: Long) {
        // 服务端在维度切换/重生/重连后会重发同一播放：先清理旧条目与其粒子，再重建
        if (entries.containsKey(animationId)) stopInternal(animationId)

        // 播放前预加载内嵌贴图
        preloadTextures(animation)

        // 服务端权威进度：以当前维度 gameTime 计算起始帧
        val currentGameTick = Minecraft.getInstance().level?.gameTime ?: startGameTick
        val player = ClientAnimationPlayer(animation, origin, startGameTick, currentGameTick)
        val uuids = HashMap<String, UUID>()
        val liveIds = HashSet<String>()
        for (state in player.currentStates()) {
            // st 门控：未出场粒子不生成（隐藏 = 渲染管线中不存在）
            if (!state.visible) continue
            val uuid = UUID.randomUUID()
            uuids[state.id] = uuid
            liveIds.add(state.id)
            ClientParticleEngine.instance()?.let { spawnState(it, uuid, state) }
        }
        entries[animationId] = Entry(player, uuids, animation, origin, liveIds)
        initAudioPlayers(animationId, animation)
    }

    /** 为一次播放的音频资产建立播放器（解码失败/无资产时为空）。 */
    private fun initAudioPlayers(animId: UUID, animation: ParticleAnimation) {
        val entry = entries[animId] ?: return
        for (a in animation.audioAssets) {
            val ap = AudioStreamPlayer(a)
            if (ap.available()) entry.audioPlayers[a.id] = ap
            else ap.close()
        }
    }

    /** 收到 PlayEffectPayload：缓存命中直接开播，否则请求服务端下发字节并挂起。 */
    @JvmStatic
    fun playEffect(payload: PlayEffectPayload) {
        val cached = effectCache[payload.key]
        if (cached == null) {
            pendingEffectPlays[payload.playbackId] = payload
            Minecraft.getInstance().connection?.send(
                work.nekow.particledrawing.core.network.EffectRequestPayload(payload.key)
            )
            return
        }
        startEffect(payload.playbackId, cached, payload.key, payload.anchor, payload.options, payload.startGameTick)
    }

    /** 收到服务端下发的特效字节：验签缓存，并开播所有等待该 key 的挂起播放。 */
    @JvmStatic
    fun onEffectData(key: Identifier, data: ByteArray) {
        if (!PdrawcReader.verify(data)) return
        effectCache[key] = data
        val it = pendingEffectPlays.entries.iterator()
        while (it.hasNext()) {
            val (id, payload) = it.next()
            if (payload.key == key) {
                it.remove()
                startEffect(id, data, key, payload.anchor, payload.options, payload.startGameTick)
            }
        }
    }

    /** 纯客户端本地播放入口（ClientEffects 使用）。 */
    @JvmStatic
    fun playLocal(playbackId: UUID, animation: ParticleAnimation, anchor: Anchor, options: EffectOptions) {
        val startGameTick = Minecraft.getInstance().level?.gameTime ?: 0L
        playAnchored(playbackId, animation, anchor, options, startGameTick)
    }

    /** 更新可移动锚点（锚点更新包逐条调用）。 */
    @JvmStatic
    fun updateAnchor(playbackId: UUID, pos: Vec3, velocity: Vec3) {
        entries[playbackId]?.anchor?.updateMovable(pos, velocity)
    }

    /** 应用服务端权威时钟同步（seek/暂停/变速）。 */
    @JvmStatic
    fun applyClockSync(playbackId: UUID, position: Double, playing: Boolean, speed: Double) {
        entries[playbackId]?.clock?.let {
            it.position = position
            it.playing = playing
            it.speed = speed
        }
    }

    /** 跳转到时间轴毫秒位置（纯本地）。 */
    @JvmStatic
    fun seekLocal(playbackId: UUID, ms: Double) {
        entries[playbackId]?.clock?.position = ms
    }

    @JvmStatic
    fun pauseLocal(playbackId: UUID) {
        entries[playbackId]?.clock?.playing = false
    }

    @JvmStatic
    fun resumeLocal(playbackId: UUID) {
        entries[playbackId]?.clock?.playing = true
    }

    @JvmStatic
    fun setSpeedLocal(playbackId: UUID, speed: Double) {
        entries[playbackId]?.clock?.speed = speed
    }

    @JvmStatic
    fun isActive(playbackId: UUID): Boolean = entries.containsKey(playbackId)

    private fun startEffect(
        playbackId: UUID,
        data: ByteArray,
        key: Identifier,
        anchor: Anchor,
        options: EffectOptions,
        startGameTick: Long,
    ) {
        val animation = try {
            AnimationLoader.parse(data)
        } catch (_: Exception) {
            return
        }
        playAnchored(playbackId, animation, anchor, options, startGameTick)
    }

    /**
     * 锚定播放：播放器输出本地坐标（origin=ZERO），渲染层每 tick 用锚点解析器映射到世界坐标。
     * 播放器时间轴由 [PlaybackClock] 驱动，支持从指定 tick 开始、暂停、变速与任意 seek。
     */
    private fun playAnchored(
        playbackId: UUID,
        animation: ParticleAnimation,
        anchor: Anchor,
        options: EffectOptions,
        startGameTick: Long,
    ) {
        if (entries.containsKey(playbackId)) stopInternal(playbackId)
        preloadTextures(animation)

        val loop = options.loop() ?: animation.loop
        val maxMs = animation.timelineLength()
        val initialMs = AnimationProgress.msAt(options.startTick().toLong(), maxMs, loop)
        val currentGameTick = Minecraft.getInstance().level?.gameTime ?: startGameTick
        val player = ClientAnimationPlayer(animation, Vec3.ZERO, startGameTick, currentGameTick, initialMs)
        val resolver = EffectAnchorResolver(anchor, options.scale())
        // startTick 是 game tick、speed 是倍速，时钟内部统一按毫秒。
        val clock = PlaybackClock(options.startTick() * 50, playing = true, speed = options.speed() * 50)

        val uuids = HashMap<String, UUID>()
        val liveIds = HashSet<String>()
        for (state in player.currentStates()) {
            if (!state.visible) continue
            val uuid = UUID.randomUUID()
            uuids[state.id] = uuid
            liveIds.add(state.id)
            ClientParticleEngine.instance()?.let { spawnState(it, uuid, state, resolver) }
        }
        entries[playbackId] = Entry(player, uuids, animation, Vec3.ZERO, liveIds, resolver, clock, loop)
        initAudioPlayers(playbackId, animation)
    }

    /**
     * 客户端世界卸载（切换维度/重生/退出世界）时清理全部本地播放，之后等服务端重发重建。
     */
    @JvmStatic
    fun onClientLevelUnload() {
        if (entries.isEmpty()) {
            // 即使没有播放条目，也解除可能残留的摄像机预览（姿态属于旧世界）
            CameraController.detach()
            return
        }
        for (id in entries.keys) stopInternal(id)
        CameraController.detach()
    }

    /** 重载所有正在播放动画的内嵌贴图与已登记的程序化贴图（/pdraw reload 使用）。 */
    @JvmStatic
    fun reloadTextures() {
        TextureCache.clear()
        for ((_, entry) in entries) {
            preloadTextures(entry.animation)
        }
        // 程序化贴图（registerTexture 登记的）也一并重载
        ClientTextureSyncManager.reloadAll()
    }

    /** 每客户端 tick 推进所有动画并同步渲染。 */
    @JvmStatic
    fun tick() {
        // 玩家死亡/重生阶段退出摄像机预览，否则相机会固定在远离重生点的动画姿态上。
        if (CameraController.isActive()) {
            val mc = Minecraft.getInstance()
            val player = mc.player
            if (player == null || player.isDeadOrDying) CameraController.detach()
        }
        // 服务端权威进度时钟：维度 gameTime
        val level = Minecraft.getInstance().level ?: return
        val gameTick = level.gameTime
        val toStop = mutableListOf<UUID>()
        for ((animId, entry) in entries) {
            val alive = if (entry.clock != null) {
                entry.clock.advance()
                entry.player.tickExternal(floor(entry.clock.position).toInt())
            } else {
                entry.player.tick(gameTick)
            }
            if (alive) {
                entry.anchor?.resolveEntity(level)
                // 静态动画（粒子状态恒定）跳过每刻的渲染同步；锚定播放即使静态也必须同步（锚点会动）
                if (!entry.player.isStatic() || entry.anchor != null) sync(entry)
                syncAudio(entry)
            } else {
                toStop.add(animId)
            }
        }
        for (id in toStop) stopInternal(id)
        updateCameraPreview()
    }

    /**
     * 每渲染帧推进函数对象 process：目标时刻 = 当前权威毫秒 + partialTick 的帧内毫秒，
     * 经 [ProcessClock] 单调化。process 每帧执行；frameSync=true 的派生粒子按帧同步，
     * 普通粒子与其余派生粒子由游戏 tick 推进。
     *
     * partialTick 与播放头不是同一套时钟，frozen 帧、暂停恢复、tickrate 变化都可能给出倒退值；
     * 只有播放头本身回退（循环回卷 / seek）才跟着倒退。
     */
    @JvmStatic
    fun frameTick(partialTick: Float) {
        if (entries.isEmpty()) return
        val p = if (partialTick.isFinite()) partialTick.coerceIn(0f, 1f).toDouble() else 0.0
        for ((_, entry) in entries) {
            val player = entry.player
            if (player.isStatic() || player.isFinished()) continue
            val step = entry.clock?.speed ?: 50.0
            val t = entry.processClock.next(player.currentMsValue, p, step, player.maxMsValue)
            player.advanceFrame(t)
            syncDerivedFrame(entry)
        }
    }

    /**
     * 直写桥接粒子时是否关闭 tick 间插值（`xo/yo/zo` 与 `x/y/z` 写同值）。
     *
     * 派生粒子的位置由脚本 process 逐渲染帧整体重写，插值会把相邻两幅图形混成重影，因此一律关闭；
     * 普通粒子的位置来自 tick 量化的轨道求值，保留插值才能按渲染帧率平滑。
     */
    @JvmStatic
    fun snapDirectWrite(derived: Boolean): Boolean = derived

    /** 每渲染帧同步 frameSync=true 的派生粒子；其余粒子由 [sync] 按游戏 tick 同步。 */
    private fun syncDerivedFrame(entry: Entry) {
        val engine = ClientParticleEngine.instance() ?: return
        val currentIds = HashSet<String>()
        for (state in entry.player.currentStates()) {
            if (!state.derived || !entry.player.isFrameSyncDerived(state.id)) continue
            currentIds.add(state.id)
            var uuid = entry.particleUuids[state.id]
            val live = state.id in entry.liveIds
            when {
                uuid == null -> {
                    if (state.visible) {
                        uuid = UUID.randomUUID()
                        entry.particleUuids[state.id] = uuid
                        spawnState(engine, uuid, state, entry.anchor)
                        entry.liveIds.add(state.id)
                    }
                }
                !state.visible && live -> {
                    engine.destroyParticles(arrayOf(uuid))
                    entry.liveIds.remove(state.id)
                }
                state.visible && !live -> {
                    spawnState(engine, uuid, state, entry.anchor)
                    entry.liveIds.add(state.id)
                }
                state.visible && live -> {
                    val pos = entry.anchor?.apply(state.pos) ?: state.pos
                    engine.updateParticleDirectArray(
                        uuid, pos, state.color, state.scale, state.glowing, state.lightLevel, snap = true,
                        billboard = state.billboard, spin = state.spin, spinLocal = state.spinLocal,
                    )
                }
            }
        }
        // 已消失的帧级同步派生粒子：销毁桥接粒子并清理索引
        val deadIds = entry.particleUuids.keys.filter { entry.player.isFrameSyncDerived(it) && it !in currentIds }
        if (deadIds.isNotEmpty()) {
            engine.destroyParticles(deadIds.map { entry.particleUuids[it]!! }.toTypedArray())
            for (id in deadIds) {
                entry.particleUuids.remove(id)
                entry.liveIds.remove(id)
            }
        }
    }

    /** 刷新「切换到摄像机」预览姿态；绑定的播放已不存在时自动退出预览。 */
    private fun updateCameraPreview() {
        val animId = CameraController.activeAnimationId() ?: run { CameraController.updatePose(null); return }
        val entry = entries[animId] ?: run { CameraController.detach(); return }
        val camId = CameraController.activeCameraId() ?: return
        val pose = entry.player.cameraPoseAt(camId, entry.player.currentMsValue.toDouble())
        CameraController.updatePose(pose)
    }

    /** 更新某次播放的变量。 */
    @JvmStatic
    fun updateVariable(animationId: UUID, name: String, value: String) {
        entries[animationId]?.player?.updateVariable(name, value)
    }

    /** 停止一次或全部播放。 */
    @JvmStatic
    fun stop(animationId: UUID?) {
        if (animationId == null) {
            for (id in entries.keys) stopInternal(id)
        } else {
            stopInternal(animationId)
        }
    }

    private fun sync(entry: Entry) {
        // 回卷标记仅用于重置；普通粒子的 xo 保留上一 tick 位置，原版渲染在 xo→x 间线性插值。
        // 派生粒子例外：位置由 process 逐渲染帧整体重写，插值会把相邻两幅迹线混成重影，一律 snap
        // （见 [snapDirectWrite]）；这里只处理未开启帧级同步的派生粒子。
        entry.player.consumeJustLooped()
        val engine = ClientParticleEngine.instance() ?: return
        val currentIds = HashSet<String>()
        for (state in entry.player.currentStates()) {
            if (state.derived && entry.player.isFrameSyncDerived(state.id)) continue
            currentIds.add(state.id)
            var uuid = entry.particleUuids[state.id]
            val live = state.id in entry.liveIds
            when {
                // 新出现的状态：首次可见时创建 uuid 并生成桥接粒子
                uuid == null -> {
                    if (state.visible) {
                        uuid = UUID.randomUUID()
                        entry.particleUuids[state.id] = uuid
                        spawnState(engine, uuid, state, entry.anchor)
                        entry.liveIds.add(state.id)
                    }
                }
                // 出场窗口结束 → 回收；循环回卷后再次满足 st 时重新生成
                !state.visible && live -> {
                    engine.destroyParticles(arrayOf(uuid))
                    entry.liveIds.remove(state.id)
                }
                // 刚到达 st → 生成
                state.visible && !live -> {
                    spawnState(engine, uuid, state, entry.anchor)
                    entry.liveIds.add(state.id)
                }
                state.visible && live -> {
                    val pos = entry.anchor?.apply(state.pos) ?: state.pos
                    ClientParticleEngine.instance()?.updateParticleDirectArray(
                        uuid, pos, state.color, state.scale, state.glowing, state.lightLevel,
                        // 派生粒子按帧重写的图形不做 tick 间插值
                        snap = snapDirectWrite(state.derived),
                        billboard = state.billboard, spin = state.spin, spinLocal = state.spinLocal,
                    )
                }
            }
        }
        // 已不在当前状态中的粒子：销毁桥接粒子并清理索引（帧级同步派生粒子除外）
        val deadIds = entry.particleUuids.keys.filter { !entry.player.isFrameSyncDerived(it) && it !in currentIds }
        if (deadIds.isNotEmpty()) {
            engine.destroyParticles(deadIds.map { entry.particleUuids[it]!! }.toTypedArray())
            for (id in deadIds) {
                entry.particleUuids.remove(id)
                entry.liveIds.remove(id)
            }
        }
    }

    private fun stopInternal(animationId: UUID) {
        val entry = entries.remove(animationId) ?: return
        if (CameraController.activeAnimationId() == animationId) CameraController.detach()
        ClientParticleEngine.instance()?.destroyParticles(entry.particleUuids.values.toTypedArray())
        for (ap in entry.audioPlayers.values) ap.close()
    }

    /** 音频播放位置与内容位置的漂移上限（毫秒）：超过就按内容位置 seek 回来。 */
    private const val AUDIO_DRIFT_SEEK_MS = 150.0

    /**
     * 每 tick 同步音频：按内容本地毫秒判断是否出声，算出淡入淡出包络后的音量、声像与倍速；
     * 漂移超阈值时按内容位置 seek。
     */
    private fun syncAudio(entry: Entry) {
        if (entry.audioPlayers.isEmpty()) return
        val player = entry.player
        val t = player.currentMsValue.toDouble()
        for (a in entry.animation.audioAssets) {
            val ap = entry.audioPlayers[a.id] ?: continue
            val owner = "a:" + a.id
            val speedProp = player.audioProp(owner, TrackPr.SPEED, a.speed, t)
            val rate = audioSpeedOf(speedProp).coerceIn(0.25, 4.0)
            // 未钳制的内容位置决定是否在窗口内，钳制后的用于查表与淡入淡出
            val localRaw = (t - a.st) * rate
            val local = localRaw.coerceIn(0.0, a.durMs.toDouble())
            val inWindow = localRaw >= 0.0 && localRaw < a.durMs
            var fade = 1.0
            val fadeIn = player.audioProp(owner, TrackPr.FADE_IN, a.fadeIn.toDouble(), t)
            val fadeOut = player.audioProp(owner, TrackPr.FADE_OUT, a.fadeOut.toDouble(), t)
            val dur = a.durMs.toDouble()
            if (fadeIn > 0) fade = minOf(fade, local / fadeIn)
            if (fadeOut > 0 && dur > 0) fade = minOf(fade, (dur - local) / fadeOut)
            fade = fade.coerceIn(0.0, 1.0)
            val gain = player.audioProp(owner, TrackPr.VOL, a.vol, t).coerceIn(0.0, 2.0) * fade
            val pan = player.audioProp(owner, TrackPr.PAN, a.pan, t).coerceIn(-1.0, 1.0)
            var seek: Double? = null
            if (inWindow && Math.abs(ap.positionMs() - local) > AUDIO_DRIFT_SEEK_MS) seek = local
            ap.update(inWindow, seek, gain.toFloat().coerceIn(0f, 2f), pan.toFloat(), rate.toFloat())
        }
    }

    /** 倍速兜底：非有限值或 <=0 一律按 1。 */
    private fun audioSpeedOf(speed: Double): Double = if (speed.isFinite() && speed > 0.0) speed else 1.0

    private fun spawnState(
        engine: ClientParticleEngine,
        uuid: UUID,
        state: ClientAnimationPlayer.ParticleState,
        resolver: EffectAnchorResolver? = null,
    ) {
        val pos = resolver?.apply(state.pos) ?: state.pos
        engine.spawnParticle(
            uuid, pos.x, pos.y, pos.z,
            state.color.r, state.color.g, state.color.b, state.color.a,
            state.scale[0], -1, null, state.glowing, state.lightLevel, state.uv,
            state.billboard, state.spin, state.spinLocal, state.additive, state.scale,
        )
    }

    private fun preloadTextures(animation: ParticleAnimation) {
        for (texName in animation.textures) {
            val bytes = animation.texData[texName] ?: continue
            try { TextureCache.load(texName, bytes) } catch (_: Exception) {}
        }
    }
}

