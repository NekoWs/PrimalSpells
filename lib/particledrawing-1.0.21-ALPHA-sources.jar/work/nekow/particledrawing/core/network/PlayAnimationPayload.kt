package work.nekow.particledrawing.core.network

import net.minecraft.network.FriendlyByteBuf
import net.minecraft.network.codec.StreamCodec
import net.minecraft.network.protocol.common.custom.CustomPacketPayload
import net.minecraft.resources.Identifier
import java.util.UUID

/**
 * 服务端下发「播放动画」：携带 .pdrawc 二进制播放文件全文、播放原点与服务端权威进度起点。
 *
 * @param animationId 该次播放的唯一 ID，变量更新与停止按它定位
 * @param originX/Y/Z 播放原点（世界坐标）
 * @param startGameTick 服务端权威进度时钟起点：播放开始时刻的服务端维度 gameTime；
 *                      客户端按 gameTime - startGameTick 计算当前帧，所有玩家一致
 * @param data .pdrawc 二进制字节（客户端解析时验签）
 */
@Suppress("unused")
data class PlayAnimationPayload(
    val animationId: UUID,
    val originX: Double, val originY: Double, val originZ: Double,
    val startGameTick: Long,
    val data: ByteArray,
) : CustomPacketPayload {

    companion object {
        @JvmField
        val TYPE = CustomPacketPayload.Type<PlayAnimationPayload>(
            Identifier.fromNamespaceAndPath("particledrawing", "play_animation")
        )

        @JvmField
        val STREAM_CODEC: StreamCodec<FriendlyByteBuf, PlayAnimationPayload> =
            object : StreamCodec<FriendlyByteBuf, PlayAnimationPayload> {
                override fun decode(buf: FriendlyByteBuf): PlayAnimationPayload {
                    val id = StreamCodecs.UUID_CODEC.decode(buf)
                    val ox = buf.readDouble()
                    val oy = buf.readDouble()
                    val oz = buf.readDouble()
                    val startGameTick = buf.readVarLong()
                    val data = buf.readByteArray()
                    return PlayAnimationPayload(id, ox, oy, oz, startGameTick, data)
                }

                override fun encode(buf: FriendlyByteBuf, p: PlayAnimationPayload) {
                    StreamCodecs.UUID_CODEC.encode(buf, p.animationId)
                    buf.writeDouble(p.originX)
                    buf.writeDouble(p.originY)
                    buf.writeDouble(p.originZ)
                    buf.writeVarLong(p.startGameTick)
                    buf.writeByteArray(p.data)
                }
            }
    }

    override fun type(): CustomPacketPayload.Type<out CustomPacketPayload> = TYPE
}