package work.nekow.particledrawing.core.client

import net.minecraft.client.Minecraft
import net.minecraft.world.entity.Entity
import net.minecraft.world.entity.LivingEntity
import net.minecraft.world.phys.Vec3
import net.neoforged.api.distmarker.Dist
import net.neoforged.bus.api.SubscribeEvent
import net.neoforged.fml.common.EventBusSubscriber
import work.nekow.particledrawing.ParticleDrawing
import work.nekow.particledrawing.animation.script.CompiledFunction
import work.nekow.particledrawing.animation.script.GetterRewriter
import work.nekow.particledrawing.animation.script.InputKey
import work.nekow.particledrawing.animation.script.compileFunctionObject
import work.nekow.particledrawing.animation.script.evaluate
import work.nekow.particledrawing.api.EntityProp
import work.nekow.particledrawing.api.WorldProp
import work.nekow.particledrawing.animation.program.AnimInstruction
import work.nekow.particledrawing.animation.program.EntityBinding
import work.nekow.particledrawing.animation.program.PivotRef
import work.nekow.particledrawing.core.easing.EasingType
import work.nekow.particledrawing.util.rotateAround
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.floor

// 客户端动画程序运行时：解释 AnimInstruction 指令流并直写渲染。
// 组级状态（pivot/pathOffset/pulseMul/fade 因子）+ 粒子级 rel 快照；旋转类指令按「快照 + 总角度」重算，无累积误差。
// 表达式模式每 tick×每粒子求值，输出世界绝对坐标。
@EventBusSubscriber(modid = ParticleDrawing.MODID, value = [Dist.CLIENT])
internal object ClientAnimationProgramManager {

    private val LOGGER = com.mojang.logging.LogUtils.getLogger()

    // —— 实体索引 ——

    private val entityByUuid = ConcurrentHashMap<UUID, Entity>()

    @SubscribeEvent
    @JvmStatic
    fun onEntityJoin(ev: net.neoforged.neoforge.event.entity.EntityJoinLevelEvent) {
        if (ev.level.isClientSide) entityByUuid[ev.entity.uuid] = ev.entity
    }

    @SubscribeEvent
    @JvmStatic
    fun onEntityLeave(ev: net.neoforged.neoforge.event.entity.EntityLeaveLevelEvent) {
        if (ev.level.isClientSide) entityByUuid.remove(ev.entity.uuid, ev.entity)
    }

    // 找实体：本地玩家 → 缓存（校验存活与维度，防冻结坐标）→ 全局注册表直查 → 渲染列表兜底。
    private fun findEntity(uuid: UUID): Entity? {
        val mc = Minecraft.getInstance()
        mc.player?.let { if (it.uuid == uuid) return it }
        entityByUuid[uuid]?.let { cached ->
            if (cached.isAlive && cached.level() === mc.level) return cached
            LOGGER.warn("[ParticleDrawing] 实体缓存失效，重新解析: {}", uuid)
            entityByUuid.remove(uuid, cached)
        }
        val level = mc.level ?: return null
        // 实体全局注册表 O(1) 直查（覆盖尚未进入渲染列表的实体，消除跟踪间隙）
        level.getEntity(uuid)?.let { entityByUuid[uuid] = it; return it }
        for (e in level.entitiesForRendering()) {
            if (e.uuid == uuid) { entityByUuid[uuid] = e; return e }
        }
        return null
    }

    // —— 数据模型 ——

    /** 粒子静态基态。 */
    private class PState(
        val baseR: Float, val baseG: Float, val baseB: Float, val baseA: Float,
        val baseScale: Float,
        var rel: Vec3,
    )

    /** 指令槽位：首用快照。 */
    private class Slot(val ins: AnimInstruction) {
        var applied = false
        var snapRel: Map<UUID, Vec3>? = null          // 旋转类：应用前各粒子 rel
        var snapPathOffset: Vec3 = Vec3.ZERO          // 平移类：应用前组位移
    }

    private class Program(
        val particleIds: List<UUID>,
        val anchorOffset: Long,
        /** 下发时刻的服务端 gameTime：把绝对时钟换算为「程序相对 tick」的原点。 */
        val startAnchor: Long,
        val states: MutableMap<UUID, PState>,
    ) {
        val slots = ArrayList<Slot>()
        // 轴心
        var pivotFixed: Vec3 = Vec3.ZERO
        var pivotEntity: EntityBinding? = null
        var pivotEntityOffset: Vec3 = Vec3.ZERO

        // 组级动画状态
        var pathOffset: Vec3 = Vec3.ZERO
        var pulseMul = 1f
        var scaleMul = 1f                              // ScaleBy 累积倍率
        var recolor: Recolor? = null
        var fadeInStart = -1L; var fadeInDur = 0; var fadeInEase = EasingType.EASE_OUT
        var fadeOutStart = -1L; var fadeOutDur = 0; var fadeOutEase = EasingType.EASE_IN
        var continuousFrozenMs: Long? = null

        // 实体注册表 / 变量 / 表达式
        val entityBindings = ArrayList<EntityBinding>()
        val vars = LinkedHashMap<String, Double>()
        var expressionCode: String? = null
        var expressionStartMs = 0L
        var compiled: CompiledFunction? = null

        /** 名字 -> 注册序号（公式 getter 参数解析用）。 */
        val handleIndexByName: Map<String, Int> by lazy {
            entityBindings.withIndex().associate { it.value.handle to it.index }
        }

        // 被动输入：编译期发现的「合成变量名 → 输入键」需求清单。
        // 每 tick 只采样被引用的值；速度按相邻 tick 位置差分，同 tick 内不重复计差。
        var extNames: Array<String> = emptyArray()
        var requiredKeys: List<InputKey> = emptyList()
        var latestInputs: Map<String, Double> = emptyMap()
        val prevPos = HashMap<UUID, Vec3>()
        var lastSampleGameTime = Long.MIN_VALUE

        /** 输入实体连续解析失败的采样次数（诊断用，成功解析即清零）。 */
        var missStreak = 0

        // 求值缓冲
        var extVals = DoubleArray(0)
        var regs = DoubleArray(0)
        var stack = DoubleArray(0)
        val out = DoubleArray(8)
    }

    private val programs = ConcurrentHashMap<UUID, Program>()

    // —— 协议入口 ——

    fun arm(
        programId: UUID,
        particleIds: List<UUID>,
        anchorGameTime: Long,
        initialPivot: Vec3,
        entitiesIn: List<EntityBinding>,
        varsIn: Map<String, Double>,
        instructions: List<AnimInstruction>,
    ) {
        val level = Minecraft.getInstance().level
        val p = Program(particleIds, anchorGameTime - (level?.gameTime ?: 0L), anchorGameTime, HashMap())
        p.pivotFixed = initialPivot
        p.entityBindings.addAll(entitiesIn)
        for ((k, v) in varsIn) p.vars[k] = v

        ClientParticleEngine.instance()?.let { engine ->
            for (id in particleIds) {
                val s = engine.snapshot(id) ?: continue
                p.states[id] = PState(s.r, s.g, s.b, s.a, s.scale, s.position.subtract(initialPivot))
            }
        }
        if (p.states.isEmpty()) {
            com.mojang.logging.LogUtils.getLogger().warn(
                "[ParticleDrawing] program {} armed with zero known particles ({} ids); client spawn packets missing?",
                programId, particleIds.size,
            )
        } else {
            com.mojang.logging.LogUtils.getLogger().info(
                "[ParticleDrawing] program {} armed: {} particles, {} instructions, anchorOffset={}",
                programId, p.states.size, p.slots.size + (if (p.expressionCode != null) 1 else 0), p.anchorOffset,
            )
        }
        for (ins in instructions) addInstruction(p, ins)
        programs[programId] = p
    }

    fun append(programId: UUID, instructions: List<AnimInstruction>) {
        val p = programs[programId] ?: return
        for (ins in instructions) addInstruction(p, ins)
    }

    /**
     * 热更程序变量：value 为公式，求值环境 = 其余变量 + 被动输入当前值。
     * 公式里的 get_* 调用先重写为合成变量再求值；未知名在此处记日志并放弃本次热更。
     */
    fun setVariable(programId: UUID, name: String, expr: String) {
        val p = programs[programId] ?: return
        if (name !in p.vars && name.length > 64) return
        val rw = try {
            GetterRewriter.rewrite(expr, p.handleIndexByName, p.entityBindings.size)
        } catch (e: IllegalArgumentException) {
            com.mojang.logging.LogUtils.getLogger().warn(
                "[ParticleDrawing] setVariable {}:{} getter 解析失败: {}", programId, name, e.message,
            )
            return
        }
        val scope = HashMap<String, Any>(p.vars)
        scope.putAll(p.latestInputs)
        val v = try {
            evaluate(rw.code, scope)
        } catch (_: Exception) { null } ?: return
        val hadCode = p.expressionCode != null
        p.vars[name] = v
        // 变量名集合可能扩大：表达式指令的 externals 布局需随之重建
        if (hadCode) recompileExpression(p) else prepareExpressionBuffers(p)
    }

    fun stop(programId: UUID, destroyParticles: Boolean) {
        val p = programs.remove(programId) ?: return
        if (destroyParticles) ClientParticleEngine.instance()?.destroyParticles(p.particleIds.toTypedArray())
    }

    /** 维度卸载 / 断线清理。 */
    @JvmStatic
    fun clearAll() { programs.clear(); entityByUuid.clear() }

    private fun addInstruction(p: Program, ins: AnimInstruction) {
        if (ins is AnimInstruction.Expression) {
            // 表达式唯一化：后到覆盖先到
            p.expressionCode = ins.code
            p.expressionStartMs = ins.startMs.toLong()
            recompileExpression(p)
            return
        }
        p.slots.add(Slot(ins))
        prepareExpressionBuffers(p)
    }

    // —— 输入采样与编译缓冲 ——

    /**
     * 编译表达式：先把 get_* 调用重写为合成外部变量（同时发现输入需求），再走纯标量快路径。
     * 未知名/未登记句柄在此抛错——程序不生效并记日志（服务端绑定处无法预知公式语义）。
     */
    private fun recompileExpression(p: Program) {
        val code = p.expressionCode ?: return
        val rw = try {
            GetterRewriter.rewrite(code, p.handleIndexByName, p.entityBindings.size)
        } catch (e: IllegalArgumentException) {
            LOGGER.error(
                "[ParticleDrawing] 表达式编译失败（getter 解析）: {}", e.message,
            )
            p.compiled = null
            p.requiredKeys = emptyList()
            p.extNames = emptyArray()
            return
        }
        // externals 布局 = 合成输入名 + 程序变量名（变量值随每 tick 快照注入，公式可直接引用）
        val extAll = rw.extNames + p.vars.keys
        p.extNames = extAll.toTypedArray()
        p.requiredKeys = rw.keys
        p.compiled = compileFunctionObject(rw.code, emptyList(), extAll)
        prepareExpressionBuffers(p)
    }

    private fun prepareExpressionBuffers(p: Program) {
        if (p.expressionCode == null || p.compiled == null) return
        p.extVals = DoubleArray(p.extNames.size)
        val cf = p.compiled ?: return
        p.regs = cf.allocRegs()
        p.stack = cf.allocStack()
    }

    /** 按 [extNames] 名字序注入当前输入值；缺失值落 0——槽位永不错位。 */
    private fun fillExternal(p: Program) {
        val src = p.latestInputs
        for ((i, name) in p.extNames.withIndex()) p.extVals[i] = src[name] ?: 0.0
    }

    /**
     * 每 tick 刷新程序的被动输入快照（同名同 tick 只采一次）。
     * 只采样 [Program.requiredKeys] 引用的值；实体缺失时相关 getter 全部读 0；
     * 速度按相邻 tick 位置差分，首 tick 与闪现后为 0。
     */
    private fun refreshInputs(p: Program, gameTime: Long) {
        if (p.requiredKeys.isEmpty()) {
            // 无被动输入：快照仅含程序变量（公式引用变量靠它注入）
            p.latestInputs = if (p.vars.isEmpty()) emptyMap() else HashMap(p.vars)
            return
        }
        if (gameTime == p.lastSampleGameTime) return
        val level = Minecraft.getInstance().level ?: return
        p.lastSampleGameTime = gameTime

        // 先解析本程序引用到的实体并做速度差分（每实体一次）
        val usedIndices = HashSet<Int>()
        for (key in p.requiredKeys) if (key is InputKey.Entity) usedIndices.add(key.handleIndex)
        val entities = HashMap<Int, Entity?>()
        val vels = HashMap<Int, Vec3>()
        val newPrev = HashMap<UUID, Vec3>()
        val missing = ArrayList<String>()
        for (idx in usedIndices) {
            val binding = p.entityBindings.getOrNull(idx) ?: continue
            val e = findEntity(binding.uuid)
            if (e == null) missing.add(binding.handle)
            entities[idx] = e
            val pos = e?.position()
            if (pos != null) {
                newPrev[binding.uuid] = pos
                val prev = p.prevPos[binding.uuid]
                vels[idx] = if (prev != null) pos.subtract(prev) else Vec3.ZERO
            }
        }
        if (missing.isEmpty()) {
            p.missStreak = 0
        } else {
            p.missStreak++
            if (p.missStreak % 60 == 0) {
                LOGGER.warn(
                    "[ParticleDrawing] 程序输入实体连续 {} 次无法解析（相关 getter 读 0）: slots={}",
                    p.missStreak, missing,
                )
            }
        }
        p.prevPos.clear()
        p.prevPos.putAll(newPrev)

        val m = HashMap<String, Double>(p.extNames.size)
        for ((i, key) in p.requiredKeys.withIndex()) {
            val name = p.extNames.getOrNull(i) ?: continue
            m[name] = when (key) {
                is InputKey.Entity ->
                    sampleEntityProp(entities[key.handleIndex] ?: continue, key.prop, vels[key.handleIndex] ?: Vec3.ZERO)
                is InputKey.World -> sampleWorldProp(level, key.prop)
            }
        }
        m.putAll(p.vars) // 变量值并入快照，fillExternal 按名注入
        p.latestInputs = m
    }

    /** 实体属性取值（枚举穷举）；实体缺失由调用方短路为 0。 */
    private fun sampleEntityProp(e: Entity, prop: EntityProp, vel: Vec3): Double = when (prop) {
        EntityProp.X -> e.x
        EntityProp.Y -> e.y
        EntityProp.Z -> e.z
        EntityProp.POS -> 0.0 // 整取形态在重写期已展开为三分量，不会到达此处
        EntityProp.EXISTS -> 1.0
        EntityProp.YAW -> e.yRot.toDouble()
        EntityProp.PITCH -> e.xRot.toDouble()
        EntityProp.DIR_X -> e.getViewVector(1f).x
        EntityProp.DIR_Y -> e.getViewVector(1f).y
        EntityProp.DIR_Z -> e.getViewVector(1f).z
        EntityProp.VEL_X -> vel.x
        EntityProp.VEL_Y -> vel.y
        EntityProp.VEL_Z -> vel.z
        EntityProp.HP -> (e as? LivingEntity)?.health?.toDouble() ?: 0.0
        EntityProp.HP_MAX -> (e as? LivingEntity)?.maxHealth?.toDouble() ?: 0.0
        EntityProp.GROUND -> if (e.onGround()) 1.0 else 0.0
        EntityProp.SNEAKING -> if (e.isShiftKeyDown()) 1.0 else 0.0
        EntityProp.ON_FIRE -> if (e.isOnFire()) 1.0 else 0.0
        EntityProp.SWIMMING -> if (e.isSwimming()) 1.0 else 0.0
        EntityProp.SPRINTING -> if (e.isSprinting()) 1.0 else 0.0
    }

    /** 世界属性取值（26.2 时钟 API：getOverworldClockTime 即旧 day time 域）。 */
    private fun sampleWorldProp(level: net.minecraft.client.multiplayer.ClientLevel, prop: WorldProp): Double {
        val clock = level.overworldClockTime
        return when (prop) {
            WorldProp.DAY_TIME -> (clock % 24000L).toDouble()
            WorldProp.GAME_TIME -> clock.toDouble()
            WorldProp.RAIN -> level.getRainLevel(1f).toDouble()
            WorldProp.THUNDER -> level.getThunderLevel(1f).toDouble()
            WorldProp.MOON_PHASE -> (clock / 24000L % 8L + 8L).toDouble()
        }
    }

    // —— 每 tick 主循环 ——

    /** 由本地玩家 game tick 事件调用（真 20Hz、实体移动后）。 */
    @JvmStatic
    fun tick() {
        val level = Minecraft.getInstance().level ?: return
        val engine = ClientParticleEngine.instance() ?: return
        val nowClient = level.gameTime

        for ((programId, p) in programs.toList()) {
            // 统一到「程序相对毫秒」域：
            // clientGameTime + anchorOffset ≈ 服务端绝对 gameTime；再减程序起点、×50 = 相对毫秒。
            // 指令 startMs 与公式变量 t 均为该相对域，量纲一致、与存档时长无关。
            val now = (nowClient + p.anchorOffset - p.startAnchor) * 50
            refreshInputs(p, nowClient)

            if (p.expressionCode != null) {
                expressionFrame(p, engine, now)
                continue
            }
            sugarFrame(p, engine, now)
        }
    }

    // —— 表达式模式 ——

    private fun expressionFrame(p: Program, engine: ClientParticleEngine, now: Long) {
        val cf = p.compiled ?: return
        if (p.regs.size != cf.regCount) prepareExpressionBuffers(p)
        val local = (now - p.expressionStartMs).coerceAtLeast(0).toDouble()
        fillExternal(p)

        val n = p.particleIds.size.toDouble()
        val fadeIn = fadeFactor(p.fadeInStart, p.fadeInDur, p.fadeInEase, now, default = 1f)
        val fadeOut = fadeFactor(p.fadeOutStart, p.fadeOutDur, p.fadeOutEase, now, default = 0f)

        for ((index, uuid) in p.particleIds.withIndex()) {
            val st = p.states[uuid] ?: continue
            cf.eval(index.toDouble(), n, local, p.regs, p.stack, p.extVals)
            val o = p.out
            readAttrs(p.regs, o)
            val alpha = (o[3].toFloat() * fadeIn * (1f - fadeOut)).coerceIn(0f, 1f)
            val scl = (o[4].toFloat() * st.baseScale).coerceAtLeast(0.001f)
            engine.applyProgramFrame(
                uuid, Vec3(o[0], o[1], o[2]),
                o[5].toFloat(), o[6].toFloat(), o[7].toFloat(),
                alpha, scl,
            )
        }
    }

    private fun readAttrs(regs: DoubleArray, out: DoubleArray) {
        out[0] = regs[3]; out[1] = regs[4]; out[2] = regs[5]   // x y z
        out[3] = regs[9]                                        // a
        out[4] = regs[13]                                       // sc
        out[5] = regs[6]; out[6] = regs[7]; out[7] = regs[8]   // r g b
    }

    // —— 结构化糖指令模式 ——

    private fun sugarFrame(p: Program, engine: ClientParticleEngine, now: Long) {
        val pivot = resolvePivot(p) ?: return

        for (slot in p.slots) applySlot(p, slot, now)

        val fadeIn = fadeFactor(p.fadeInStart, p.fadeInDur, p.fadeInEase, now, default = 1f)
        val fadeOut = fadeFactor(p.fadeOutStart, p.fadeOutDur, p.fadeOutEase, now, default = 0f)
        val rc = p.recolor
        val kR = if (rc == null) 1f else eased(rc.ease, progress(now - rc.startMs, rc.durationMs))

        for ((uuid, st) in p.states) {
            val r: Float; val g: Float; val b: Float; val aBase: Float
            if (rc != null) {
                val from = rc.from[uuid]
                if (from != null) {
                    r = lerp(from[0], rc.r, kR); g = lerp(from[1], rc.g, kR)
                    b = lerp(from[2], rc.b, kR); aBase = lerp(from[3], rc.a, kR)
                } else { r = st.baseR; g = st.baseG; b = st.baseB; aBase = st.baseA }
            } else { r = st.baseR; g = st.baseG; b = st.baseB; aBase = st.baseA }

            val alpha = (aBase * fadeIn * (1f - fadeOut)).coerceIn(0f, 1f)
            val scale = (st.baseScale * p.scaleMul * p.pulseMul).coerceAtLeast(0.001f)
            engine.applyProgramFrame(uuid, pivot.add(p.pathOffset).add(st.rel), r, g, b, alpha, scale)
        }
    }

    /** 组级重着色的首用快照与目标。 */
    private class Recolor(
        val startMs: Long, val durationMs: Int, val ease: EasingType,
        val r: Float, val g: Float, val b: Float, val a: Float,
        val from: Map<UUID, FloatArray>,
    )

    private fun resolvePivot(p: Program): Vec3? {
        val ch = p.pivotEntity ?: return p.pivotFixed
        val e = findEntity(ch.uuid) ?: return null
        return e.position().add(p.pivotEntityOffset)
    }

    private fun applySlot(p: Program, slot: Slot, now: Long) {
        val ins = slot.ins
        val start = ins.startMs.toLong()
        if (now < start) return

        if (!slot.applied) {
            slot.applied = true
            when (ins) {
                is AnimInstruction.RotateOnce, is AnimInstruction.Spin ->
                    slot.snapRel = p.states.mapValues { it.value.rel }
                is AnimInstruction.Translate, is AnimInstruction.MovePath ->
                    slot.snapPathOffset = p.pathOffset
                else -> {}
            }
        }
        val local = now - start

        when (ins) {
            is AnimInstruction.BindPivot -> when (val ref = ins.pivot) {
                is PivotRef.Fixed -> { p.pivotFixed = ref.pos; p.pivotEntity = null; p.pivotEntityOffset = Vec3.ZERO }
                is PivotRef.FollowEntity -> { p.pivotEntity = EntityBinding("__pivot__", ref.uuid); p.pivotEntityOffset = ref.offset }
            }

            is AnimInstruction.FadeIn -> { p.fadeInStart = start; p.fadeInDur = ins.durationMs; p.fadeInEase = ins.easing }
            is AnimInstruction.FadeOut -> { p.fadeOutStart = start; p.fadeOutDur = ins.durationMs; p.fadeOutEase = ins.easing }

            is AnimInstruction.Recolor -> {
                if (p.recolor == null) {
                    p.recolor = Recolor(start, ins.durationMs, ins.easing,
                        ins.r, ins.g, ins.b, ins.a,
                        p.states.mapValues { floatArrayOf(it.value.baseR, it.value.baseG, it.value.baseB, it.value.baseA) })
                }
            }

            is AnimInstruction.ScaleBy -> {
                val k = eased(ins.easing, progress(local, ins.durationMs))
                p.scaleMul = 1f + (ins.ratio - 1f) * k
            }

            is AnimInstruction.Translate -> {
                p.pathOffset = slot.snapPathOffset.add(ins.delta.scale(eased(ins.easing, progress(local, ins.durationMs)).toDouble()))
            }

            is AnimInstruction.RotateOnce -> {
                val angle = ins.radians * eased(ins.easing, progress(local, ins.durationMs))
                rotateToSnapshot(p, slot, ins.axis, angle)
            }

            is AnimInstruction.Spin -> {
                val effective = if (p.continuousFrozenMs != null)
                    (p.continuousFrozenMs!! - start).coerceAtLeast(0)
                else (now - start).coerceAtLeast(0)
                rotateToSnapshot(p, slot, ins.axis, ins.radiansPerMs * effective.toDouble())
            }

            is AnimInstruction.Pulse -> {
                if (p.continuousFrozenMs != null) return
                val half = ins.halfPeriodMs.coerceAtLeast(1)
                val phase = (local % (half * 2L)).toFloat() / half
                val tri = if (phase <= 1f) phase else 2f - phase
                p.pulseMul = 1f + (ins.peakRatio - 1f) * tri
            }

            is AnimInstruction.MovePath -> {
                val k = eased(ins.easing, progress(local, ins.durationMs))
                p.pathOffset = slot.snapPathOffset.add(samplePath(ins.points, k).subtract(ins.points.first()))
            }

            is AnimInstruction.StopContinuous ->
                if (p.continuousFrozenMs == null || p.continuousFrozenMs!! > now) p.continuousFrozenMs = now

            is AnimInstruction.Expression -> {} // 表达式由 addInstruction 分流，不进入糖指令槽
        }
    }

    private fun rotateToSnapshot(p: Program, slot: Slot, axis: Vec3, angleTotal: Double) {
        val snaps = slot.snapRel ?: return
        val nAxis = axis.normalize()
        for ((uuid, base) in snaps) {
            val st = p.states[uuid] ?: continue
            st.rel = base.rotateAround(nAxis, angleTotal)
        }
    }

    private fun samplePath(points: List<Vec3>, t: Float): Vec3 {
        if (points.isEmpty()) return Vec3.ZERO
        if (points.size == 1) return points[0]
        val ft = t.coerceIn(0f, 1f) * (points.size - 1)
        val i = floor(ft.toDouble()).toInt().coerceIn(0, points.size - 2)
        val f = ft - i
        val a = points[i]; val b = points[i + 1]
        return Vec3(a.x + (b.x - a.x) * f, a.y + (b.y - a.y) * f, a.z + (b.z - a.z) * f)
    }

    private fun fadeFactor(start: Long, dur: Int, ease: EasingType, now: Long, default: Float): Float =
        if (start < 0) default else eased(ease, progress(now - start, dur))

    private fun progress(local: Long, durationMs: Int): Float {
        if (durationMs <= 0) return 1f
        return (local.toFloat() / durationMs).coerceIn(0f, 1f)
    }

    private fun eased(easing: EasingType, t: Float): Float = easing.evaluate(t.coerceIn(0f, 1f))

    private fun lerp(a: Float, b: Float, t: Float): Float = a + (b - a) * t
}
