package work.nekow.particledrawing.core.server

import net.minecraft.network.protocol.common.custom.CustomPacketPayload
import net.minecraft.server.level.ServerPlayer
import net.minecraft.world.phys.Vec3
import net.neoforged.neoforge.network.PacketDistributor
import work.nekow.particledrawing.api.Color
import work.nekow.particledrawing.config.ParticleDrawingConfig
import work.nekow.particledrawing.core.easing.EasingType
import work.nekow.particledrawing.core.network.ParticleDestroyPayload
import work.nekow.particledrawing.core.network.ParticleLightLevelPayload
import work.nekow.particledrawing.core.network.ParticleRotationPayload
import work.nekow.particledrawing.core.network.ParticleSetPositionPayload
import work.nekow.particledrawing.core.network.ParticleSpawnPayload
import work.nekow.particledrawing.core.network.ParticleTrackPayload
import work.nekow.particledrawing.core.network.ParticleTranslatePayload
import work.nekow.particledrawing.core.network.ParticleUpdatePayload
import work.nekow.particledrawing.core.network.ParticleVelocityPayload
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import org.apache.logging.log4j.LogManager
import org.apache.logging.log4j.Logger

private val LOGGER: Logger = LogManager.getLogger("ParticleDrawing")

// 服务端权威粒子引擎，每个维度一个实例（经 getOrCreate 获取），负责粒子与粒子组的生命周期与网络同步。
@Suppress("unused")
class ServerParticleEngine(
    val dimensionId: UUID
) {

    private val particles: MutableMap<UUID, ParticleData> = ConcurrentHashMap()
    private val groups: MutableMap<UUID, ParticleGroupData> = ConcurrentHashMap()

    // 粒子 -> 已同步的玩家集合；玩家 -> 已同步的粒子集合（用于每玩家粒子数限制与可见性重检）
    private val visibleTo: MutableMap<UUID, MutableSet<UUID>> = ConcurrentHashMap()
    private val playerParticles: MutableMap<UUID, MutableSet<UUID>> = ConcurrentHashMap()
    private var visibilityTickCounter = 0
    private var lastCapacityWarnNanos = 0L

    /** 生成粒子并广播到视野内可见的玩家；达到维度上限时返回 null。 */
    @Suppress("DataFlowIssue")
    fun spawnParticle(position: Vec3, color: Color,
                      scale: Float, lifetime: Int, groupId: UUID?,
                      glowing: Boolean, lightLevel: Int, offsetFromPivot: Vec3?,
                      playersInDimension: Collection<ServerPlayer>): ParticleData? {
        val maxTotal = ParticleDrawingConfig.SERVER.maxParticlesPerDimension.get()
        if (particles.size >= maxTotal) {
            warnWhenOverCapacity()
            return null
        }

        val id = UUID.randomUUID()
        val data = ParticleData.create(id, position, color, scale,
            lifetime, groupId, glowing, lightLevel, offsetFromPivot)
        particles[id] = data

        if (groupId != null) {
            groups[groupId]?.addMember(id)
        }

        val payload = ParticleSpawnPayload(
            id, position.x, position.y, position.z,
            color.r, color.g, color.b, color.a,
            scale, lifetime, groupId, glowing, lightLevel
        )

        broadcastSpawn(playersInDimension, position, id, payload)
        return data
    }

    /**
     * 更新粒子属性（位置、颜色、缩放）并广播。
     *
     * @param id 粒子 ID
     * @param position 新位置
     * @param color 新颜色
     * @param scale 新缩放
     * @param updatePos 是否更新位置
     * @param updateColor 是否更新颜色
     * @param updateScale 是否更新缩放
     * @param durationTicks 过渡持续 tick 数
     * @param easing 缓动类型
     * @param playersInDimension 维度内的玩家列表
     */
    fun updateParticle(id: UUID, position: Vec3, color: Color, scale: Float,
                       updatePos: Boolean, updateColor: Boolean, updateScale: Boolean,
                       durationTicks: Int, easing: EasingType,
                       playersInDimension: Collection<ServerPlayer>) {
        val data = particles[id] ?: return

        if (updatePos) data.setPosition(position)
        if (updateColor) data.setColor(color)
        if (updateScale) data.setScale(scale)

        val payload: ParticleUpdatePayload = when {
            updatePos && updateColor && updateScale -> ParticleUpdatePayload.full(id,
                position.x, position.y, position.z,
                color.r, color.g, color.b, color.a,
                scale, durationTicks, easing)
            updatePos -> ParticleUpdatePayload.positionOnly(id,
                position.x, position.y, position.z, durationTicks, easing)
            updateColor -> ParticleUpdatePayload.colorOnly(id,
                color.r, color.g, color.b, color.a, durationTicks, easing)
            else -> ParticleUpdatePayload.scaleOnly(id, scale, durationTicks, easing)
        }

        sendToVisible(playersInDimension, data.position(), payload)
    }

    /**
     * 设置粒子的速度向量并广播。
     * @param id 粒子 ID
     * @param velocity 速度向量（blocks/tick）
     * @param playersInDimension 维度内的玩家列表
     */
    fun setVelocity(id: UUID, velocity: Vec3, playersInDimension: Collection<ServerPlayer>) {
        val data = particles[id] ?: return
        data.setVelocity(velocity)

        val payload = ParticleVelocityPayload(id, velocity.x, velocity.y, velocity.z)
        sendToVisible(playersInDimension, data.position(), payload)
    }

    /**
     * 直设粒子位置并广播（无缓动）：客户端用 partialTick 在上一位置与本位置之间插值。
     * 供「每 tick 跟随一个非实体点」的粒子（如投射物本体）使用。
     */
    fun trackParticle(id: UUID, position: Vec3, playersInDimension: Collection<ServerPlayer>) {
        val data = particles[id] ?: return
        data.setPosition(position)

        val payload = ParticleTrackPayload(id, position.x, position.y, position.z)
        sendToVisible(playersInDimension, data.position(), payload)
    }

    /**
     * 设置粒子的旋转（绕轴心做圆弧运动）并广播。
     * @param id 粒子 ID
     * @param pivot 旋转轴心（绝对世界坐标）
     * @param offset 粒子相对轴心的偏移向量
     * @param rot 目标欧拉角（弧度，X→Y→Z）
     */
    fun rotateParticle(id: UUID, pivot: Vec3, offset: Vec3, rot: DoubleArray,
                       durationTicks: Int, easing: EasingType,
                       playersInDimension: Collection<ServerPlayer>) {
        val data = particles[id] ?: return
        val payload = ParticleRotationPayload.of(id, pivot, offset, rot, durationTicks, easing)
        sendToVisible(playersInDimension, data.position(), payload)
    }

    /**
     * 设置粒子的平移（绕轴心叠加世界空间增量）并广播。
     * @param id 粒子 ID
     * @param pivot 旋转轴心（绝对世界坐标）
     * @param offset 粒子相对轴心的偏移向量
     * @param delta 目标平移增量
     */
    fun translateParticle(id: UUID, pivot: Vec3, offset: Vec3, delta: Vec3,
                          durationTicks: Int, easing: EasingType,
                          playersInDimension: Collection<ServerPlayer>) {
        val data = particles[id] ?: return
        val payload = ParticleTranslatePayload.of(id, pivot, offset, delta, durationTicks, easing)
        sendToVisible(playersInDimension, data.position(), payload)
    }

    /**
     * 设置粒子的位置（组 set 位置轨道）并广播：缓动未旋转偏移，保留旋转。
     * @param id 粒子 ID
     * @param pivot 旋转轴心（绝对世界坐标）
     * @param offset 目标未旋转偏移（相对轴心）
     */
    fun setPosition(id: UUID, pivot: Vec3, offset: Vec3,
                    durationTicks: Int, easing: EasingType,
                    playersInDimension: Collection<ServerPlayer>) {
        val data = particles[id] ?: return
        val payload = ParticleSetPositionPayload.of(id, pivot, offset, durationTicks, easing)
        sendToVisible(playersInDimension, data.position(), payload)
    }

    /**
     * 动态修改粒子的发光光照等级并广播。
     * @param id 粒子 ID
     * @param lightLevel 目标光照等级 (0-15)
     * @param playersInDimension 维度内的玩家列表
     */
    fun setLightLevel(id: UUID, lightLevel: Int, playersInDimension: Collection<ServerPlayer>) {
        val data = particles[id] ?: return
        data.setLightLevel(lightLevel)

        val payload = ParticleLightLevelPayload(id, data.lightLevel())
        sendToVisible(playersInDimension, data.position(), payload)
    }

    /**
     * 链式调用更新粒子属性。
     *
     * 用法:
     * ```
     * engine.update(particleId)
     *     .position(x, y, z)
     *     .color(Color.BLUE)
     *     .easing(EasingType.EASE_OUT, 10)
     *     .send(players)
     * ```
     *
     * @param id 要更新的粒子 ID
     */
    inner class UpdateBuilder(private val id: UUID) {
        private var pos: Vec3? = null
        private var col: Color? = null
        private var scl: Float? = null
        private var lvl: Int? = null
        private var dur: Int = 0
        private var ease: EasingType = EasingType.LINEAR

        fun position(x: Double, y: Double, z: Double): UpdateBuilder {
            pos = Vec3(x, y, z); return this
        }
        fun position(v: Vec3): UpdateBuilder { pos = v; return this }
        fun color(c: Color): UpdateBuilder { col = c; return this }
        fun scale(s: Float): UpdateBuilder { scl = s; return this }
        fun lightLevel(level: Int): UpdateBuilder { lvl = level; return this }
        fun easing(e: EasingType, durationTicks: Int): UpdateBuilder { ease = e; dur = durationTicks; return this }
        fun duration(ticks: Int): UpdateBuilder { dur = ticks; return this }

        fun send(players: Collection<ServerPlayer>) {
            val data = particles[id] ?: return
            val p = pos ?: data.position()
            val c = col ?: data.color()
            val s = scl ?: data.scale()
            if (lvl != null) {
                setLightLevel(id, lvl!!, players)
            }
            updateParticle(id, p, c, s,
                updatePos = pos != null,
                updateColor = col != null,
                updateScale = scl != null,
                durationTicks = dur, easing = ease,
                playersInDimension = players)
        }
    }

    /**
     * 创建粒子的链式更新构建器。
     *
     * @param id 要更新的粒子 ID
     * @return 更新构建器实例
     */
    fun update(id: UUID) = UpdateBuilder(id)

    /**
     * 销毁单个粒子并通知所有维度内玩家。
     *
     * @param id 粒子 ID
     * @param playersInDimension 维度内的玩家列表
     */
    fun destroyParticle(id: UUID, playersInDimension: Collection<ServerPlayer>) {
        val data = particles.remove(id) ?: return

        val groupId = data.groupId
        if (groupId != null) {
            groups[groupId]?.removeMember(id)
        }

        val payload = ParticleDestroyPayload.single(id)
        sendToTracked(playersInDimension, listOf(id), payload)
        untrackParticle(id)
    }

    /**
     * 销毁整个粒子组及其所有成员。
     *
     * @param groupId 组 ID
     * @param playersInDimension 维度内的玩家列表
     */
    fun destroyGroup(groupId: UUID, playersInDimension: Collection<ServerPlayer>) {
        val group = groups.remove(groupId) ?: return

        val ids = ArrayList(group.memberIds())
        for (id in ids) {
            particles.remove(id)
        }

        val payload = ParticleDestroyPayload.group(groupId, ids)
        sendToTracked(playersInDimension, ids, payload)
        untrackParticles(ids)
    }

    /**
     * 每 tick 更新：推进生命周期、移除过期粒子。
     *
     * @param playersInDimension 维度内的玩家列表
     */
    fun tick(playersInDimension: Collection<ServerPlayer>) {
        val it = particles.entries.iterator()
        while (it.hasNext()) {
            val entry = it.next()
            val data = entry.value
            val vel = data.velocity()
            if (vel.x != 0.0 || vel.y != 0.0 || vel.z != 0.0) {
                data.setPosition(data.position().add(vel))
            }
            data.tick()
            if (data.isExpired()) {
                val groupId = data.groupId
                if (groupId != null) {
                    groups[groupId]?.removeMember(entry.key)
                }
                val payload = ParticleDestroyPayload.single(entry.key)
                sendToTracked(playersInDimension, listOf(entry.key), payload)
                untrackParticle(entry.key)
                it.remove()
            }
        }

        groups.entries.removeIf { it.value.isEmpty() }

        // 周期性可见性重检：补发新进入范围的粒子、回收已越界的粒子
        visibilityTickCounter++
        if (visibilityTickCounter >= ParticleDrawingConfig.SERVER.visibilityCheckInterval.get().coerceAtLeast(1)) {
            visibilityTickCounter = 0
            recheckVisibility(playersInDimension)
        }

        // 清理已离开维度的玩家追踪记录
        pruneStalePlayers(playersInDimension)
    }

    /** @return 当前活跃粒子总数 */
    fun particleCount(): Int = particles.size
    /** @return 当前组总数 */
    fun groupCount(): Int = groups.size

    /** @return 指定 ID 的组，不存在则返回 null */
    fun getGroup(groupId: UUID): ParticleGroupData? = groups[groupId]

    /**
     * 创建粒子组。
     *
     * @param groupId 组 ID
     * @param pivot 组轴心
     * @return 创建的组数据
     */
    @Suppress("unused")
    fun createGroup(groupId: UUID, pivot: Vec3): ParticleGroupData {
        val group = ParticleGroupData.create(groupId, pivot)
        groups[groupId] = group
        return group
    }

    /** @return 指定 ID 的粒子数据，不存在则返回 null */
    fun getParticle(id: UUID): ParticleData? = particles[id]

    /**
     * 设置粒子相对轴心的偏移。
     *
     * @param id 粒子 ID
     * @param offset 偏移向量
     */
    fun setOffsetFromPivot(id: UUID, offset: Vec3) {
        particles[id]?.setOffsetFromPivot(offset)
    }

    /**
     * 清除维度内所有粒子和组，分批发送销毁通知。
     *
     * @param playersInDimension 维度内的玩家列表
     * @return 清除的粒子数量
     */
    fun clearAll(playersInDimension: Collection<ServerPlayer>): Int {
        val count = particles.size

        if (particles.isNotEmpty()) {
            val allIds = particles.keys.toTypedArray()
            val batchSize = 1000

            var offset = 0
            while (offset < allIds.size) {
                val end = (offset + batchSize).coerceAtMost(allIds.size)
                val batch = allIds.copyOfRange(offset, end)
                val payload = ParticleDestroyPayload(batch, null)

                sendToTracked(playersInDimension, batch.toList(), payload)
                offset += batchSize
            }
        }

        particles.clear()
        groups.clear()
        playerParticles.clear()
        visibleTo.clear()
        return count
    }

    private fun track(playerId: UUID, particleId: UUID) {
        playerParticles.computeIfAbsent(playerId) { ConcurrentHashMap.newKeySet() }.add(particleId)
        visibleTo.computeIfAbsent(particleId) { ConcurrentHashMap.newKeySet() }.add(playerId)
    }

    private fun untrackParticle(particleId: UUID) {
        val playerIds = visibleTo.remove(particleId) ?: return
        for (playerId in playerIds) {
            playerParticles[playerId]?.remove(particleId)
        }
    }

    private fun untrackParticles(particleIds: Collection<UUID>) {
        for (particleId in particleIds) untrackParticle(particleId)
    }

    private fun broadcastSpawn(players: Collection<ServerPlayer>, position: Vec3,
                               particleId: UUID, payload: CustomPacketPayload) {
        val maxPerPlayer = ParticleDrawingConfig.SERVER.maxParticlesPerPlayer.get()

        for (player in players) {
            if (!ParticleVisibilityManager.isWithinViewDistance(player, position)) continue

            val trackedCount = playerParticles[player.uuid]?.size ?: 0
            if (trackedCount >= maxPerPlayer) continue

            PacketDistributor.sendToPlayer(player, payload)
            track(player.uuid, particleId)
        }
    }

    private fun recheckVisibility(players: Collection<ServerPlayer>) {
        if (players.isEmpty()) return
        val maxPerPlayer = ParticleDrawingConfig.SERVER.maxParticlesPerPlayer.get()

        for (player in players) {
            val tracked = playerParticles[player.uuid] ?: continue

            val toRemove = ArrayList<UUID>()
            for (particleId in tracked) {
                val data = particles[particleId]
                if (data == null || !ParticleVisibilityManager.isWithinViewDistance(player, data.position())) {
                    toRemove.add(particleId)
                }
            }
            for (particleId in toRemove) {
                tracked.remove(particleId)
                visibleTo[particleId]?.remove(player.uuid)
                PacketDistributor.sendToPlayer(player, ParticleDestroyPayload.single(particleId))
            }

            var count = tracked.size
            if (count < maxPerPlayer) {
                for ((particleId, data) in particles) {
                    if (count >= maxPerPlayer) break
                    if (tracked.contains(particleId)) continue
                    if (!ParticleVisibilityManager.isWithinViewDistance(player, data.position())) continue

                    PacketDistributor.sendToPlayer(player, spawnPayload(data))
                    track(player.uuid, particleId)
                    count++
                }
            }
        }
    }

    private fun spawnPayload(data: ParticleData): ParticleSpawnPayload {
        return ParticleSpawnPayload(
            data.id,
            data.position().x, data.position().y, data.position().z,
            data.color().r, data.color().g, data.color().b, data.color().a,
            data.scale(), data.lifetime(), data.groupId, data.glowing(), data.lightLevel()
        )
    }

    private fun pruneStalePlayers(players: Collection<ServerPlayer>) {
        if (players.isEmpty()) {
            playerParticles.clear()
            visibleTo.clear()
            return
        }
        val active = HashSet<UUID>(players.size)
        for (player in players) active.add(player.uuid)

        val it = playerParticles.keys.iterator()
        while (it.hasNext()) {
            val playerId = it.next()
            if (playerId !in active) {
                val ids = playerParticles.remove(playerId)
                if (ids != null) {
                    for (particleId in ids) {
                        visibleTo[particleId]?.remove(playerId)
                    }
                }
            }
        }
    }

    private fun warnWhenOverCapacity() {
        val now = System.nanoTime()
        if (now - lastCapacityWarnNanos > 1_000_000_000L) {
            lastCapacityWarnNanos = now
            LOGGER.warn("Particle limit reached in dimension {}: cannot spawn more than {} particles",
                dimensionId, ParticleDrawingConfig.SERVER.maxParticlesPerDimension.get())
        }
    }

    private fun sendToVisible(players: Collection<ServerPlayer>, position: Vec3,
                              payload: CustomPacketPayload) {
        for (player in players) {
            if (ParticleVisibilityManager.isWithinViewDistance(player, position)) {
                PacketDistributor.sendToPlayer(player, payload)
            }
        }
    }

    /**
     * 仅向已追踪了指定粒子的玩家发送数据包。
     *
     * 组变换与运动指令等数据包携带世界坐标（轴心），必须只发给实际拥有这些粒子的玩家，
     * 否则会向不可见这些粒子的玩家泄露坐标信息（无政府服务器可利用此获取他人位置）。
     */
    private fun sendToTracked(players: Collection<ServerPlayer>, particleIds: Collection<UUID>, payload: CustomPacketPayload) {
        val recipients = HashSet<UUID>()
        for (id in particleIds) {
            visibleTo[id]?.let { recipients.addAll(it) }
        }
        if (recipients.isEmpty()) return

        for (player in players) {
            if (player.uuid in recipients) {
                PacketDistributor.sendToPlayer(player, payload)
            }
        }
    }

    companion object {
        /** 全局维度引擎映射表 */
        private val DIMENSION_ENGINES: MutableMap<UUID, ServerParticleEngine> = ConcurrentHashMap()

        /**
         * 获取或创建指定维度的引擎实例。
         *
         * @param dimensionId 维度 ID
         * @return 引擎实例
         */
        @JvmStatic
        fun getOrCreate(dimensionId: UUID): ServerParticleEngine {
            return DIMENSION_ENGINES.computeIfAbsent(dimensionId) { ServerParticleEngine(it) }
        }

        /** @return 指定维度的引擎，不存在则返回 null */
        @JvmStatic
        fun get(dimensionId: UUID): ServerParticleEngine? = DIMENSION_ENGINES[dimensionId]

        /** 清除指定维度的引擎实例 */
        @JvmStatic
        fun clearDimension(dimensionId: UUID) {
            DIMENSION_ENGINES.remove(dimensionId)
        }
    }
}
